# Licence inventory

| Component | Licence | Commercial use | Notes |
|---|---|---|---|
| PdfBox-Android 2.0.27.0 (port of Apache PDFBox) | Apache-2.0 | Yes | Text/graphics extraction, PDFBox rendering fallback |
| Tesseract OCR 5 / Tesseract4Android 4.8.0 | Apache-2.0 | Yes | On-device OCR (native) |
| Leptonica (bundled by Tesseract4Android) | BSD-2-Clause style | Yes | Image processing for Tesseract |
| tessdata_best `ara.traineddata`, tessdata_fast `eng.traineddata` | Apache-2.0 | Yes | Downloaded at build time |
| AndroidX (Core, Activity, Lifecycle, Navigation, Room, WorkManager, DataStore, DocumentFile, Hilt) | Apache-2.0 | Yes | |
| Jetpack Compose, Material 3, Material Icons | Apache-2.0 | Yes | |
| Dagger / Hilt | Apache-2.0 | Yes | |
| Kotlin stdlib, kotlinx.coroutines | Apache-2.0 | Yes | |
| Google Play Billing Library 8 | Android SDK License | Yes | Required for Play subscriptions |
| Android `PdfRenderer` (PDFium) | Platform API (BSD/Apache in AOSP) | Yes | Part of Android, not bundled |

## Fonts

**No font files are bundled or redistributed.** Generated documents reference fonts *by name*:
the original font family when it can be identified from the PDF, otherwise a configurable
substitute (default Calibri for Latin, Arial for Arabic). The viewing application (Word,
WPS, LibreOffice…) renders with installed fonts. The conversion report states which fonts
were preserved, kept by name without verification, or substituted.

## Why not ML Kit for OCR?

Google ML Kit's on-device Text Recognition v2 supports Latin, Chinese, Devanagari, Japanese
and Korean scripts but **not Arabic**, so it cannot meet the Arabic requirement. Tesseract's
LSTM Arabic model runs fully offline under Apache-2.0.
