# PDFBox-Android loads resources and some classes reflectively.
-keep class com.tom_roush.pdfbox.** { *; }
-keep class com.tom_roush.fontbox.** { *; }
-keep class com.tom_roush.harmony.** { *; }
-dontwarn com.gemalto.jp2.**
-dontwarn org.bouncycastle.**
-dontwarn javax.xml.**

# Tesseract JNI callbacks
-keep class com.googlecode.tesseract.android.** { *; }
-keep class com.googlecode.leptonica.android.** { *; }

# Keep line numbers for crash reports without exposing names
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
