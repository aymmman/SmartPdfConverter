Tesseract models are downloaded here by the GitHub workflow (see README).
