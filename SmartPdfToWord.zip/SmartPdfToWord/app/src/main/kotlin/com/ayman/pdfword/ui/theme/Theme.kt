@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.ayman.pdfword.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Brand: Word-like deep blue with a warm amber accent.
private val Blue10 = Color(0xFF001A43)
private val Blue20 = Color(0xFF002E6E)
private val Blue30 = Color(0xFF0F3F96)
private val Blue40 = Color(0xFF1546A0)
private val Blue80 = Color(0xFFB0C6FF)
private val Blue90 = Color(0xFFDAE2FF)
private val Amber40 = Color(0xFF8A5100)
private val Amber80 = Color(0xFFFFB86B)
private val Amber90 = Color(0xFFFFDCBE)
private val Teal40 = Color(0xFF006A62)
private val Teal80 = Color(0xFF6FD8CB)

private val Light = lightColorScheme(
    primary = Blue40, onPrimary = Color.White, primaryContainer = Blue90, onPrimaryContainer = Blue10,
    secondary = Teal40, onSecondary = Color.White, secondaryContainer = Color(0xFFC9EFE8), onSecondaryContainer = Color(0xFF00201C),
    tertiary = Amber40, onTertiary = Color.White, tertiaryContainer = Amber90, onTertiaryContainer = Color(0xFF2C1600),
    background = Color(0xFFF7F9FC), onBackground = Color(0xFF181C22),
    surface = Color(0xFFF7F9FC), onSurface = Color(0xFF181C22),
    surfaceVariant = Color(0xFFE0E2EC), onSurfaceVariant = Color(0xFF44474F),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF1F3F9), surfaceContainer = Color(0xFFEBEEF4),
    surfaceContainerHigh = Color(0xFFE5E8EE), surfaceContainerHighest = Color(0xFFDFE2E8),
    outline = Color(0xFF74777F), outlineVariant = Color(0xFFC4C6D0),
    error = Color(0xFFBA1A1A), errorContainer = Color(0xFFFFDAD6),
)

private val Dark = darkColorScheme(
    primary = Blue80, onPrimary = Blue20, primaryContainer = Blue30, onPrimaryContainer = Blue90,
    secondary = Teal80, onSecondary = Color(0xFF003731), secondaryContainer = Color(0xFF005048), onSecondaryContainer = Color(0xFFC9EFE8),
    tertiary = Amber80, onTertiary = Color(0xFF4A2800), tertiaryContainer = Color(0xFF693C00), onTertiaryContainer = Amber90,
    background = Color(0xFF0F1420), onBackground = Color(0xFFE1E2E9),
    surface = Color(0xFF0F1420), onSurface = Color(0xFFE1E2E9),
    surfaceVariant = Color(0xFF44474F), onSurfaceVariant = Color(0xFFC4C6D0),
    surfaceContainerLowest = Color(0xFF0A0E18), surfaceContainerLow = Color(0xFF171C27), surfaceContainer = Color(0xFF1B202B),
    surfaceContainerHigh = Color(0xFF262A36), surfaceContainerHighest = Color(0xFF303541),
    outline = Color(0xFF8E9099), outlineVariant = Color(0xFF44474F),
)

private val AppTypography = Typography().let { t ->
    t.copy(
        headlineMedium = t.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = t.labelLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp),
    )
}

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun PdfWordTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        typography = AppTypography,
        shapes = AppShapes,
        content = content,
    )
}
