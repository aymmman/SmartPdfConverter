package com.ayman.pdfword.ui.setup

import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ayman.pdfword.core.ConversionMode
import com.ayman.pdfword.data.ImportedPdf
import com.ayman.pdfword.data.JobRepository
import com.ayman.pdfword.data.RequestOptions
import com.ayman.pdfword.data.billing.BillingManager
import com.ayman.pdfword.data.settings.ImageQuality
import com.ayman.pdfword.data.settings.OcrLanguages
import com.ayman.pdfword.data.settings.OcrMode
import com.ayman.pdfword.data.settings.SettingsRepository
import com.ayman.pdfword.engine.PdfImportException
import com.ayman.pdfword.engine.PdfInfo
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SetupUiState(
    val loading: Boolean = true,
    val error: PdfImportException.Reason? = null,
    val needsPassword: Boolean = false,
    val wrongPassword: Boolean = false,
    val info: PdfInfo? = null,
    val mode: ConversionMode = ConversionMode.EDITABLE,
    val ocrMode: OcrMode = OcrMode.AUTO,
    val ocrLanguages: OcrLanguages = OcrLanguages.ARABIC_ENGLISH,
    val imageQuality: ImageQuality = ImageQuality.BALANCED,
    val pageFrom: Int = 1,
    val pageTo: Int = 1,
    val latinFont: String = "Calibri",
    val arabicFont: String = "Arial",
    val highAccuracyOcr: Boolean = false,
    val isPro: Boolean = false,
    val starting: Boolean = false,
) {
    val maxPages: Int get() = if (isPro) BillingManager.PRO_MAX_PAGES else BillingManager.FREE_MAX_PAGES
    val selectedPages: Int get() = (pageTo - pageFrom + 1).coerceAtLeast(0)
    val overLimit: Boolean get() = selectedPages > maxPages
    val rangeValid: Boolean get() = info != null && pageFrom in 1..info.pageCount && pageTo in pageFrom..info.pageCount
}

@HiltViewModel
class SetupViewModel @Inject constructor(
    savedState: SavedStateHandle,
    private val jobs: JobRepository,
    private val settings: SettingsRepository,
    private val billing: BillingManager,
) : ViewModel() {

    private val _state = MutableStateFlow(SetupUiState())
    val state: StateFlow<SetupUiState> = _state.asStateFlow()
    private val _started = Channel<String>(Channel.BUFFERED)
    val started = _started.receiveAsFlow()

    private var imported: ImportedPdf? = null
    private var launched = false

    init {
        val uriArg: String? = savedState["uri"]
        val retryArg: String? = savedState["retry"]
        viewModelScope.launch {
            val s = settings.current()
            val pro = billing.isPro.value
            _state.update {
                it.copy(
                    mode = if (pro) s.defaultMode else ConversionMode.EDITABLE, ocrMode = s.ocrMode, ocrLanguages = s.ocrLanguages,
                    imageQuality = s.imageQuality, latinFont = s.defaultLatinFont, arabicFont = s.defaultArabicFont, isPro = pro,
                )
            }
            try {
                val imp = when {
                    !retryArg.isNullOrBlank() -> jobs.cloneJob(retryArg) ?: throw PdfImportException(PdfImportException.Reason.UNREADABLE)
                    !uriArg.isNullOrBlank() -> jobs.import(Uri.parse(uriArg))
                    else -> throw PdfImportException(PdfImportException.Reason.UNREADABLE)
                }
                imported = imp
                if (imp.needsPassword) _state.update { it.copy(loading = false, needsPassword = true) }
                else onInfo(imp.info!!)
            } catch (e: PdfImportException) {
                _state.update { it.copy(loading = false, error = e.reason) }
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = PdfImportException.Reason.UNREADABLE) }
            }
        }
        viewModelScope.launch { billing.isPro.collect { p -> _state.update { it.copy(isPro = p) } } }
    }

    private fun onInfo(info: PdfInfo) {
        _state.update { it.copy(loading = false, needsPassword = false, wrongPassword = false, info = info, pageFrom = 1, pageTo = info.pageCount.coerceAtMost(it.maxPages)) }
    }

    fun submitPassword(pw: String) {
        val imp = imported ?: return
        _state.update { it.copy(loading = true) }
        viewModelScope.launch {
            try { onInfo(jobs.unlock(imp, pw)) } catch (e: PdfImportException) {
                _state.update { it.copy(loading = false, needsPassword = true, wrongPassword = true) }
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = PdfImportException.Reason.CORRUPT) }
            }
        }
    }

    fun setMode(m: ConversionMode) = _state.update { it.copy(mode = m) }
    fun setOcrMode(m: OcrMode) = _state.update { it.copy(ocrMode = m) }
    fun setOcrLanguages(l: OcrLanguages) = _state.update { it.copy(ocrLanguages = l) }
    fun setQuality(q: ImageQuality) = _state.update { it.copy(imageQuality = q) }
    fun setRange(from: Int, to: Int) = _state.update { it.copy(pageFrom = from, pageTo = to) }
    fun setLatinFont(f: String) = _state.update { it.copy(latinFont = f) }
    fun setArabicFont(f: String) = _state.update { it.copy(arabicFont = f) }
    fun setHighAccuracy(v: Boolean) = _state.update { it.copy(highAccuracyOcr = v) }

    fun start() {
        val st = _state.value
        val imp = imported ?: return
        val info = st.info ?: return
        if (!st.rangeValid || st.overLimit || st.starting) return
        _state.update { it.copy(starting = true) }
        viewModelScope.launch {
            val s = settings.current()
            val req = jobs.buildRequest(
                imp, info, s,
                RequestOptions(
                    mode = if (st.isPro) st.mode else ConversionMode.EDITABLE,
                    ocrMode = st.ocrMode, ocrLanguages = st.ocrLanguages, pageFrom = st.pageFrom, pageTo = st.pageTo,
                    imageQuality = st.imageQuality, latinFont = st.latinFont, arabicFont = st.arabicFont,
                    highAccuracyOcr = st.isPro && st.highAccuracyOcr,
                ),
            )
            jobs.start(req)
            launched = true
            _started.send(imp.jobId)
        }
    }

    override fun onCleared() {
        // A file picked but never converted is removed right away.
        if (!launched) imported?.let { jobs.discard(it.jobId) }
        super.onCleared()
    }
}
