package com.ayman.pdfword.ui.home

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ayman.pdfword.data.JobRepository
import com.ayman.pdfword.data.RequestOptions
import com.ayman.pdfword.data.billing.BillingManager
import com.ayman.pdfword.data.db.ConversionEntity
import com.ayman.pdfword.data.settings.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface HomeEvent {
    data class BatchQueued(val queued: Int, val skipped: Int) : HomeEvent
}

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val jobs: JobRepository,
    private val settings: SettingsRepository,
    billing: BillingManager,
) : ViewModel() {

    val history: StateFlow<List<ConversionEntity>> = jobs.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val isPro: StateFlow<Boolean> = billing.isPro

    private val _events = Channel<HomeEvent>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    fun delete(id: String) { viewModelScope.launch { jobs.delete(id) } }

    /** Pro: converts several PDFs with the default settings, one after another. */
    fun startBatch(uris: List<Uri>) {
        viewModelScope.launch {
            val s = settings.current()
            var queued = 0; var skipped = 0
            for (uri in uris) {
                val imported = runCatching { jobs.import(uri) }.getOrNull()
                val info = imported?.info
                if (imported == null || info == null) { imported?.let { jobs.discard(it.jobId) }; skipped++; continue }
                val pages = info.pageCount.coerceAtMost(BillingManager.PRO_MAX_PAGES)
                val req = jobs.buildRequest(
                    imported, info, s,
                    RequestOptions(s.defaultMode, s.ocrMode, s.ocrLanguages, 1, pages, s.imageQuality, s.defaultLatinFont, s.defaultArabicFont, highAccuracyOcr = false),
                )
                jobs.start(req)
                queued++
            }
            _events.send(HomeEvent.BatchQueued(queued, skipped))
        }
    }
}
