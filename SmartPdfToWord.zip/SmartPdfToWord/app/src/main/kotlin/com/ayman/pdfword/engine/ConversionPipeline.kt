package com.ayman.pdfword.engine

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.ayman.pdfword.core.ConversionOptions
import com.ayman.pdfword.core.DocumentAssembler
import com.ayman.pdfword.core.doc.DocModel
import com.ayman.pdfword.core.docx.DocxWriter
import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.ImageInput
import com.ayman.pdfword.core.model.PageInput
import com.ayman.pdfword.core.model.PageKind
import com.ayman.pdfword.core.ocr.OcrNormalizer
import com.ayman.pdfword.core.raster.RasterAnalysis
import com.ayman.pdfword.core.report.ConversionReport
import com.ayman.pdfword.data.settings.ConversionRequest
import com.ayman.pdfword.data.settings.ImageQuality
import com.ayman.pdfword.data.settings.OcrMode
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImage
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.IdentityHashMap
import java.util.zip.ZipFile
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max
import kotlin.math.roundToInt

enum class Stage { PREPARING, EXTRACTING, OCR, LAYOUT, WRITING, SAVING }

data class ProgressInfo(val stage: Stage, val page: Int, val totalPages: Int)

data class ConversionOutcome(val output: File, val report: ConversionReport, val model: DocModel)

class ConversionFailedException(val code: String, message: String? = null, cause: Throwable? = null) : Exception(message, cause)

@Singleton
class ConversionPipeline @Inject constructor(
    @ApplicationContext private val context: Context,
    private val sessions: SessionStore,
) {
    private val tag = "ConversionPipeline" // never log document contents
    private val mutex = kotlinx.coroutines.sync.Mutex()

    /** Runs jobs strictly one at a time; queued jobs wait here without failing each other. */
    suspend fun runExclusive(req: ConversionRequest, onProgress: suspend (ProgressInfo) -> Unit): ConversionOutcome =
        mutex.lockAndRun { run(req, onProgress) }

    private suspend fun <T> kotlinx.coroutines.sync.Mutex.lockAndRun(block: suspend () -> T): T {
        lock()
        try { return block() } finally { unlock() }
    }

    suspend fun run(req: ConversionRequest, onProgress: suspend (ProgressInfo) -> Unit): ConversionOutcome = withContext(Dispatchers.Default) {
        val files = JobFiles(context, req.jobId)
        if (!files.source.exists()) throw ConversionFailedException("source_missing")
        onProgress(ProgressInfo(Stage.PREPARING, 0, 0))
        val options = ConversionOptions(
            mode = req.mode,
            defaultLatinFont = req.defaultLatinFont,
            defaultArabicFont = req.defaultArabicFont,
            fontRules = ConversionRequest.parseFontRules(req.fontRules),
            detectHeadersFooters = req.detectHeadersFooters,
            keepImages = req.keepImages,
        )
        val doc = try { PdfSource.open(files.source, sessions.password(req.jobId)) } catch (e: PdfImportException) {
            throw ConversionFailedException(e.reason.name.lowercase(), e.message, e)
        }
        doc.use { pdf ->
            val from = (req.pageFrom - 1).coerceIn(0, pdf.numberOfPages - 1)
            val to = (req.pageTo - 1).coerceIn(from, pdf.numberOfPages - 1)
            val total = to - from + 1
            val assembler = DocumentAssembler(options, req.sourceName, total)
            val ocr = OcrEngine(context)
            val ocrLangsUsable = ocr.isAvailable(req.ocrLanguages.tesseract)
            if (req.ocrMode != OcrMode.OFF && !ocrLangsUsable) assembler.warn("OCR language data is not installed in this build; scanned pages are kept as images.")
            val imageCache = IdentityHashMap<COSBase, String>()
            try {
                PageRasterizer(files.source, pdf, pdf.isEncrypted).use { raster ->
                    for ((n, i) in (from..to).withIndex()) {
                        currentCoroutineContext().ensureActive()
                        onProgress(ProgressInfo(Stage.EXTRACTING, n + 1, total))
                        try {
                            processPage(pdf, i, req, files, raster, ocr, ocrLangsUsable, assembler, imageCache, n + 1, total, onProgress, highDpi = req.highAccuracyOcr)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (oom: OutOfMemoryError) {
                            System.gc()
                            try {
                                processPage(pdf, i, req, files, raster, ocr, ocrLangsUsable, assembler, imageCache, n + 1, total, onProgress, highDpi = false, lowMemory = true)
                            } catch (e2: Throwable) {
                                if (e2 is CancellationException) throw e2
                                assembler.addFailedPage(i, 595f, 842f, "not enough memory")
                            }
                        } catch (e: Exception) {
                            Log.w(tag, "page ${i + 1} failed: ${e.javaClass.simpleName}")
                            val p = pdf.getPage(i)
                            val g = PageGeometry(p)
                            assembler.addFailedPage(i, g.displayWidth, g.displayHeight, e.javaClass.simpleName)
                        }
                    }
                }
            } finally {
                ocr.close()
            }
            onProgress(ProgressInfo(Stage.LAYOUT, total, total))
            val (model, report) = assembler.finish()
            if (report.pagesProcessed == 0) throw ConversionFailedException("no_pages")

            onProgress(ProgressInfo(Stage.WRITING, total, total))
            val output = writeDocx(model, files, req.sourceName, emptyMap())
            sessions.putModel(req.jobId, model)
            return@withContext ConversionOutcome(output, report, model)
        }
    }

    /** Writes the DOCX to a temporary file and only renames it into place once complete and valid. */
    fun writeDocx(model: DocModel, files: JobFiles, sourceName: String, overrides: Map<String, String>, replace: File? = null): File {
        val out = replace ?: files.outputFor(sourceName)
        val part = File(out.parentFile, out.name + ".part")
        try {
            part.outputStream().buffered(1 shl 16).use { DocxWriter(model, overrides).write(it) }
            ZipFile(part).use { z ->
                if (z.getEntry("word/document.xml") == null || z.getEntry("[Content_Types].xml") == null) throw ConversionFailedException("invalid_docx")
            }
            if (replace != null && replace.exists()) replace.delete()
            if (!part.renameTo(out)) { part.copyTo(out, overwrite = true); part.delete() }
            return out
        } catch (e: Exception) {
            part.delete()
            throw if (e is ConversionFailedException) e else ConversionFailedException("write_failed", e.message, e)
        }
    }

    private suspend fun processPage(
        pdf: PDDocument, index: Int, req: ConversionRequest, files: JobFiles, raster: PageRasterizer, ocr: OcrEngine,
        ocrUsable: Boolean, assembler: DocumentAssembler, imageCache: IdentityHashMap<COSBase, String>,
        pageNo: Int, total: Int, onProgress: suspend (ProgressInfo) -> Unit, highDpi: Boolean, lowMemory: Boolean = false,
    ) {
        val quality = if (lowMemory) ImageQuality.SMALL else req.imageQuality
        val images = ArrayList<ImageInput>()
        var imgCounter = 0
        val extractor = PdfPageExtractor(pdf)
        val raw = extractor.extract(index) { pdImage, box ->
            if (!req.keepImages) return@extract
            val path = encodePdfImage(pdImage, files, index, imgCounter++, quality, imageCache)
            if (path != null) images += ImageInput(box, path, if (path.endsWith(".png")) "image/png" else "image/jpeg", 0, 0)
        }
        val pageW = raw.width
        val pageH = raw.height
        val pageArea = pageW * pageH
        val imageCover = (raw.imageBoxes.sumOf { (it.area.toDouble()) } / pageArea).toFloat().coerceAtMost(1f)
        val meaningful = raw.meaningfulChars
        val vectorHeavy = raw.graphics.size > 300 && meaningful < 15
        val kind = when {
            meaningful < 15 && (imageCover > 0.45f || vectorHeavy) -> PageKind.SCANNED
            meaningful < 15 && raw.imageBoxes.isEmpty() && raw.graphics.isEmpty() -> PageKind.EMPTY
            imageCover > 0.3f -> PageKind.HYBRID
            else -> PageKind.TEXT
        }
        val invisibleLayer = raw.totalChars > 0 && raw.invisibleChars > 0.8f * raw.totalChars
        val needsOcr = when (req.ocrMode) {
            OcrMode.OFF -> false
            OcrMode.ALWAYS -> true
            OcrMode.AUTO -> kind == PageKind.SCANNED || (raw.totalChars >= 15 && raw.textQuality < 0.6f)
        }
        val warnings = ArrayList<String>()
        var glyphs = raw.glyphs
        val segments = raw.segments.toMutableList()
        var ocrApplied = false
        var ocrConfidence: Float? = null
        var keepImages: List<ImageInput> = images

        if (needsOcr && ocrUsable) {
            onProgress(ProgressInfo(Stage.OCR, pageNo, total))
            val dpi = when { lowMemory -> 200; highDpi -> 400; else -> 300 }
            val (bitmap, scale) = raster.renderPage(index, dpi, pageW, pageH)
            try {
                val words = ocr.recognize(bitmap, req.ocrLanguages.tesseract, 1f / scale)
                if (words.isNotEmpty()) {
                    glyphs = OcrNormalizer.toGlyphs(words)
                    ocrApplied = true
                    ocrConfidence = words.map { it.confidence }.average().toFloat()
                    // Table rulings from the scan (only meaningful when the page has no vector rulings).
                    if (raw.segments.size < 4) segments += rulingsFromBitmap(bitmap, scale)
                    // The full-page scan is replaced by recognised text; smaller images stay.
                    keepImages = images.filter { it.box.area < 0.8f * pageArea }
                } else warnings += "OCR found no text on this page"
            } finally {
                bitmap.recycle()
            }
        } else if (needsOcr && kind == PageKind.SCANNED) {
            warnings += "Scanned page kept as an image (OCR unavailable or disabled)"
        }
        if (kind == PageKind.SCANNED && !ocrApplied && req.keepImages && images.isEmpty()) {
            // Vector-only page without a text layer: keep it visible as a picture.
            val (bmp, scale) = raster.renderPage(index, 150, pageW, pageH)
            val path = saveBitmap(bmp, File(files.mediaDir, "page_${index}.jpg"), quality)
            bmp.recycle()
            keepImages = listOf(ImageInput(Box(0f, 0f, pageW, pageH), path, "image/jpeg", (pageW * scale).toInt(), (pageH * scale).toInt()))
        }
        if (raw.rotatedDropped > 0) warnings += "${raw.rotatedDropped} characters of rotated text were not converted"

        val input = PageInput(
            index = index, width = pageW, height = pageH, glyphs = glyphs, segments = segments,
            fills = raw.fills, graphics = raw.graphics, images = keepImages, kind = kind,
            ocrApplied = ocrApplied, ocrMeanConfidence = ocrConfidence, textQuality = raw.textQuality,
            rotatedGlyphsDropped = raw.rotatedDropped, invisibleTextLayer = invisibleLayer, warnings = warnings,
        )
        onProgress(ProgressInfo(Stage.LAYOUT, pageNo, total))
        val figures = ArrayList<ImageInput>()
        if (req.keepImages && !ocrApplied) {
            for ((k, region) in assembler.figureRegions(input).withIndex()) {
                val (bmp, scale) = raster.renderRegion(index, region, if (lowMemory) 150 else 220, pageW, pageH)
                val path = saveBitmap(bmp, File(files.mediaDir, "fig_${index}_$k.png"), ImageQuality.HIGH, forcePng = true)
                figures += ImageInput(region, path, "image/png", bmp.width, bmp.height, fromVectorFigure = true)
                bmp.recycle()
            }
        }
        assembler.addPage(input, figures)
    }

    private fun rulingsFromBitmap(bitmap: Bitmap, pxPerPt: Float): List<com.ayman.pdfword.core.model.Segment> {
        // Analyse at ~150 dpi: plenty for lines and 4x cheaper than the OCR resolution.
        val factor = (150f / 72f) / pxPerPt
        val w = max(1, (bitmap.width * factor).roundToInt())
        val h = max(1, (bitmap.height * factor).roundToInt())
        val small = if (factor < 0.95f) Bitmap.createScaledBitmap(bitmap, w, h, true) else bitmap
        try {
            val px = IntArray(small.width * small.height)
            small.getPixels(px, 0, small.width, 0, 0, small.width, small.height)
            val gray = ByteArray(px.size)
            for (k in px.indices) {
                val c = px[k]
                gray[k] = ((((c shr 16) and 0xFF) * 30 + ((c shr 8) and 0xFF) * 59 + (c and 0xFF) * 11) / 100).toByte()
            }
            val ptPerPx = 1f / (pxPerPt * (small.width.toFloat() / bitmap.width))
            return RasterAnalysis.detectRulings(gray, small.width, small.height, ptPerPx)
        } finally {
            if (small !== bitmap) small.recycle()
        }
    }

    private fun encodePdfImage(
        pdImage: PDImage, files: JobFiles, pageIndex: Int, n: Int, quality: ImageQuality, cache: IdentityHashMap<COSBase, String>,
    ): String? {
        val key: COSBase? = (pdImage as? PDImageXObject)?.cosObject
        if (key != null) cache[key]?.let { return it }
        val w = pdImage.width; val h = pdImage.height
        if (w <= 0 || h <= 0) return null
        if (w.toLong() * h > 40_000_000L) return null // pathological sizes
        val bmp = try { pdImage.image } catch (e: Throwable) { if (e is OutOfMemoryError) System.gc(); null } ?: return null
        val path = try {
            val alpha = bmp.hasAlpha()
            saveBitmap(bmp, File(files.mediaDir, "img_${pageIndex}_$n.${if (alpha) "png" else "jpg"}"), quality, forcePng = alpha)
        } finally { bmp.recycle() }
        if (key != null) cache[key] = path
        return path
    }

    private fun saveBitmap(src: Bitmap, file: File, quality: ImageQuality, forcePng: Boolean = false): String {
        val longest = max(src.width, src.height)
        val scaled = if (longest > quality.maxPixels) {
            val s = quality.maxPixels.toFloat() / longest
            Bitmap.createScaledBitmap(src, max(1, (src.width * s).roundToInt()), max(1, (src.height * s).roundToInt()), true)
        } else src
        try {
            file.outputStream().buffered().use { out ->
                if (forcePng || file.name.endsWith(".png")) scaled.compress(Bitmap.CompressFormat.PNG, 100, out)
                else scaled.compress(Bitmap.CompressFormat.JPEG, quality.jpegQuality, out)
            }
        } finally {
            if (scaled !== src) scaled.recycle()
        }
        return file.absolutePath
    }
}
