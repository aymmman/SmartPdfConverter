@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.ayman.pdfword.ui.progress

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import com.ayman.pdfword.R
import com.ayman.pdfword.data.JobRepository
import com.ayman.pdfword.data.db.ConversionEntity
import com.ayman.pdfword.data.db.JobStatus
import com.ayman.pdfword.data.db.jobStatus
import com.ayman.pdfword.engine.Stage
import com.ayman.pdfword.ui.components.PrivacyBadge
import com.ayman.pdfword.work.ConversionScheduler
import com.ayman.pdfword.work.ConversionWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class ProgressViewModel @Inject constructor(
    savedState: SavedStateHandle,
    private val jobs: JobRepository,
    scheduler: ConversionScheduler,
) : ViewModel() {
    val jobId: String = savedState["jobId"] ?: ""
    val entity: StateFlow<ConversionEntity?> = jobs.observe(jobId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val work: StateFlow<WorkInfo?> = scheduler.observe(jobId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    fun cancel() = jobs.cancel(jobId)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(onDone: (String) -> Unit, onBack: () -> Unit, vm: ProgressViewModel = hiltViewModel()) {
    val entity by vm.entity.collectAsStateWithLifecycle()
    val work by vm.work.collectAsStateWithLifecycle()
    val status = entity?.jobStatus

    LaunchedEffect(status) { if (status == JobStatus.SUCCEEDED) onDone(vm.jobId) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(entity?.sourceName ?: "") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back)) } },
        )
    }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            when (status) {
                JobStatus.FAILED, JobStatus.CANCELLED -> {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(
                        if (status == JobStatus.CANCELLED) stringResource(R.string.status_cancelled) else stringResource(errorText(entity?.errorMessage)),
                        style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(20.dp))
                    OutlinedButton(onClick = onBack) { Text(stringResource(R.string.back)) }
                }
                else -> {
                    val progress = work?.progress
                    val stage = progress?.getString(ConversionWorker.KEY_STAGE)?.let { runCatching { Stage.valueOf(it) }.getOrNull() }
                    val page = progress?.getInt(ConversionWorker.KEY_PAGE, 0) ?: 0
                    val total = progress?.getInt(ConversionWorker.KEY_TOTAL, 0) ?: 0
                    CircularProgressIndicator(modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(24.dp))
                    Text(stageText(stage, status), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    if (total > 0) {
                        Text(stringResource(R.string.page_progress, page, total), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(progress = { (page.toFloat() / total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(stringResource(R.string.background_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    PrivacyBadge()
                    Spacer(Modifier.height(24.dp))
                    OutlinedButton(onClick = vm::cancel) { Text(stringResource(R.string.cancel)) }
                }
            }
        }
    }
}

@Composable
private fun stageText(stage: Stage?, status: JobStatus?): String = when {
    status == JobStatus.QUEUED && stage == null -> stringResource(R.string.stage_queued)
    stage == Stage.EXTRACTING -> stringResource(R.string.stage_extracting)
    stage == Stage.OCR -> stringResource(R.string.stage_ocr)
    stage == Stage.LAYOUT -> stringResource(R.string.stage_layout)
    stage == Stage.WRITING -> stringResource(R.string.stage_writing)
    stage == Stage.SAVING -> stringResource(R.string.stage_saving)
    else -> stringResource(R.string.stage_preparing)
}

fun errorText(code: String?): Int = when (code) {
    "password_required", "wrong_password" -> R.string.err_password
    "not_pdf" -> R.string.err_not_pdf
    "corrupt" -> R.string.err_corrupt
    "out_of_memory" -> R.string.err_memory
    "no_pages" -> R.string.err_no_pages
    "source_missing" -> R.string.err_source_missing
    "write_failed", "invalid_docx" -> R.string.err_write
    else -> R.string.err_unexpected
}
