@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.ayman.pdfword.ui.pro

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.pdfword.R
import com.ayman.pdfword.data.billing.BillingManager
import com.ayman.pdfword.ui.components.SectionCard
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class ProViewModel @Inject constructor(val billing: BillingManager) : ViewModel() {
    init { billing.start() }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProScreen(onBack: () -> Unit, vm: ProViewModel = hiltViewModel()) {
    val isPro by vm.billing.isPro.collectAsStateWithLifecycle()
    val product by vm.billing.product.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var unavailable by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.billing.refresh() }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.pro_title)) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back)) } },
        )
    }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Filled.Star, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
            Text(stringResource(R.string.pro_headline), style = MaterialTheme.typography.headlineSmall)
            SectionCard {
                listOf(
                    R.string.pro_f_batch, R.string.pro_f_layout, R.string.pro_f_ocr, R.string.pro_f_pages, R.string.pro_f_rules, R.string.pro_f_noads,
                ).forEach { f ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(10.dp))
                        Text(stringResource(f), style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
            SectionCard(title = stringResource(R.string.free_plan)) {
                Text(stringResource(R.string.free_plan_desc, BillingManager.FREE_MAX_PAGES), style = MaterialTheme.typography.bodyMedium)
            }
            if (isPro) {
                Text(stringResource(R.string.pro_active), color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.titleMedium)
            } else {
                Button(
                    onClick = {
                        val activity = context.findActivity()
                        unavailable = activity == null || !vm.billing.launchPurchase(activity)
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                ) {
                    Text(product?.let { stringResource(R.string.subscribe_price, vm.billing.priceText() ?: "") } ?: stringResource(R.string.subscribe))
                }
                if (unavailable) Text(stringResource(R.string.billing_unavailable), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text(stringResource(R.string.subscription_terms), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
