package com.ayman.pdfword

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.ayman.pdfword.data.billing.BillingManager
import com.ayman.pdfword.engine.JobFiles
import com.ayman.pdfword.work.ConversionWorker
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class PdfWordApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var billing: BillingManager

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().setWorkerFactory(workerFactory).build()

    override fun onCreate() {
        super.onCreate()
        PDFBoxResourceLoader.init(applicationContext)
        ConversionWorker.ensureChannel(this)
        // Remove leftovers from interrupted jobs (documents never linger in cache).
        Thread { runCatching { JobFiles.cleanup(this) } }.start()
        billing.start()
    }
}
