package com.ayman.pdfword.data

import android.content.Context
import android.net.Uri
import com.ayman.pdfword.data.db.ConversionDao
import com.ayman.pdfword.data.db.ConversionEntity
import com.ayman.pdfword.data.db.JobStatus
import com.ayman.pdfword.data.settings.AppSettings
import com.ayman.pdfword.data.settings.ConversionRequest
import com.ayman.pdfword.engine.JobFiles
import com.ayman.pdfword.engine.PdfImportException
import com.ayman.pdfword.engine.PdfInfo
import com.ayman.pdfword.engine.PdfSource
import com.ayman.pdfword.engine.SessionStore
import com.ayman.pdfword.work.ConversionScheduler
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

data class ImportedPdf(val jobId: String, val info: PdfInfo?, val needsPassword: Boolean, val name: String, val size: Long)

@Singleton
class JobRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dao: ConversionDao,
    private val scheduler: ConversionScheduler,
    private val sessions: SessionStore,
) {
    fun observeAll(): Flow<List<ConversionEntity>> = dao.observeAll()
    fun observe(id: String): Flow<ConversionEntity?> = dao.observe(id)
    suspend fun get(id: String) = dao.get(id)

    /** Copies the PDF into a new private job folder and inspects it. */
    suspend fun import(uri: Uri): ImportedPdf = withContext(Dispatchers.IO) {
        val jobId = UUID.randomUUID().toString()
        val files = JobFiles(context, jobId)
        try {
            val (name, size) = PdfSource.importUri(context, uri, files.source)
            try {
                val info = PdfSource.probe(files.source, name, size, null)
                ImportedPdf(jobId, info, false, name, size)
            } catch (e: PdfImportException) {
                if (e.reason == PdfImportException.Reason.PASSWORD_REQUIRED) ImportedPdf(jobId, null, true, name, size)
                else throw e
            }
        } catch (e: Exception) {
            files.deleteWorkFiles()
            throw e
        }
    }

    /** Re-imports the source of an earlier job (for "retry with other settings"). */
    suspend fun cloneJob(previousId: String): ImportedPdf? = withContext(Dispatchers.IO) {
        val prev = dao.get(previousId) ?: return@withContext null
        val oldReq = runCatching { ConversionRequest.fromJson(prev.requestJson) }.getOrNull() ?: return@withContext null
        val src = File(oldReq.sourcePath)
        if (!src.exists()) return@withContext null
        val jobId = UUID.randomUUID().toString()
        val files = JobFiles(context, jobId)
        src.copyTo(files.source, overwrite = true)
        val pw = sessions.password(previousId)
        try {
            val info = PdfSource.probe(files.source, oldReq.sourceName, oldReq.sourceSize, pw)
            if (pw != null) sessions.setPassword(jobId, pw)
            ImportedPdf(jobId, info, false, oldReq.sourceName, oldReq.sourceSize)
        } catch (e: PdfImportException) {
            if (e.reason == PdfImportException.Reason.PASSWORD_REQUIRED || e.reason == PdfImportException.Reason.WRONG_PASSWORD)
                ImportedPdf(jobId, null, true, oldReq.sourceName, oldReq.sourceSize)
            else { files.deleteWorkFiles(); null }
        }
    }

    suspend fun unlock(imported: ImportedPdf, password: String): PdfInfo = withContext(Dispatchers.IO) {
        val files = JobFiles(context, imported.jobId)
        val info = PdfSource.probe(files.source, imported.name, imported.size, password)
        sessions.setPassword(imported.jobId, password)
        info
    }

    fun sourcePath(jobId: String): String = JobFiles(context, jobId).source.absolutePath

    suspend fun start(request: ConversionRequest) {
        dao.upsert(
            ConversionEntity(
                id = request.jobId, sourceName = request.sourceName, sourceSize = request.sourceSize,
                pageCount = request.pageTo - request.pageFrom + 1, mode = request.mode.name,
                status = JobStatus.QUEUED.name, requestJson = request.toJson(), createdAt = System.currentTimeMillis(),
            )
        )
        scheduler.enqueue(request.jobId)
    }

    fun cancel(jobId: String) = scheduler.cancel(jobId)

    fun discard(jobId: String) {
        sessions.forget(jobId)
        JobFiles(context, jobId).deleteWorkFiles()
    }

    suspend fun delete(jobId: String) = withContext(Dispatchers.IO) {
        dao.get(jobId)?.outputPath?.let { File(it).delete() }
        discard(jobId)
        dao.delete(jobId)
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        for (e in dao.all()) { e.outputPath?.let { File(it).delete() }; sessions.forget(e.id) }
        dao.clear()
        JobFiles.clearAll(context)
    }

    fun buildRequest(imported: ImportedPdf, info: PdfInfo, s: AppSettings, overrides: RequestOptions): ConversionRequest =
        ConversionRequest(
            jobId = imported.jobId, sourcePath = sourcePath(imported.jobId), sourceName = info.name, sourceSize = info.size,
            pageCount = info.pageCount, mode = overrides.mode, ocrMode = overrides.ocrMode, ocrLanguages = overrides.ocrLanguages,
            pageFrom = overrides.pageFrom, pageTo = overrides.pageTo, imageQuality = overrides.imageQuality,
            keepImages = s.keepImages, detectHeadersFooters = s.detectHeadersFooters, defaultLatinFont = overrides.latinFont,
            defaultArabicFont = overrides.arabicFont, fontRules = s.fontRules, highAccuracyOcr = overrides.highAccuracyOcr,
            outputTreeUri = s.outputTreeUri,
        )
}

data class RequestOptions(
    val mode: com.ayman.pdfword.core.ConversionMode,
    val ocrMode: com.ayman.pdfword.data.settings.OcrMode,
    val ocrLanguages: com.ayman.pdfword.data.settings.OcrLanguages,
    val pageFrom: Int,
    val pageTo: Int,
    val imageQuality: com.ayman.pdfword.data.settings.ImageQuality,
    val latinFont: String,
    val arabicFont: String,
    val highAccuracyOcr: Boolean,
)
