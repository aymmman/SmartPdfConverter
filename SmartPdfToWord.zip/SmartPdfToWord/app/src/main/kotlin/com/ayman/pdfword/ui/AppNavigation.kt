package com.ayman.pdfword.ui

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.ayman.pdfword.IncomingAction
import com.ayman.pdfword.data.db.JobStatus
import com.ayman.pdfword.data.db.jobStatus
import com.ayman.pdfword.ui.home.HomeScreen
import com.ayman.pdfword.ui.pro.ProScreen
import com.ayman.pdfword.ui.progress.ProgressScreen
import com.ayman.pdfword.ui.result.ResultScreen
import com.ayman.pdfword.ui.review.ReviewScreen
import com.ayman.pdfword.ui.settings.SettingsScreen
import com.ayman.pdfword.ui.setup.SetupScreen
import kotlinx.coroutines.flow.StateFlow

private object Routes {
    const val HOME = "home"
    const val SETUP = "setup?uri={uri}&retry={retry}"
    const val PROGRESS = "progress/{jobId}"
    const val RESULT = "result/{jobId}"
    const val REVIEW = "review/{jobId}"
    const val SETTINGS = "settings"
    const val PRO = "pro"

    fun setupForUri(uri: Uri) = "setup?uri=${Uri.encode(uri.toString())}"
    fun setupRetry(jobId: String) = "setup?retry=$jobId"
}

@Composable
fun AppNavigation(incoming: StateFlow<IncomingAction?>, onIncomingHandled: () -> Unit) {
    val nav = rememberNavController()
    val pending by incoming.collectAsStateWithLifecycle()

    LaunchedEffect(pending) {
        when (val a = pending) {
            is IncomingAction.OpenPdf -> nav.navigate(Routes.setupForUri(a.uri))
            is IncomingAction.OpenJob -> nav.navigate("progress/${a.jobId}")
            null -> return@LaunchedEffect
        }
        onIncomingHandled()
    }

    NavHost(navController = nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onPdfPicked = { nav.navigate(Routes.setupForUri(it)) },
                onOpenJob = { e ->
                    if (e.jobStatus == JobStatus.RUNNING || e.jobStatus == JobStatus.QUEUED) nav.navigate("progress/${e.id}")
                    else nav.navigate("result/${e.id}")
                },
                onSettings = { nav.navigate(Routes.SETTINGS) },
                onPro = { nav.navigate(Routes.PRO) },
            )
        }
        composable(
            Routes.SETUP,
            arguments = listOf(
                navArgument("uri") { type = NavType.StringType; nullable = true; defaultValue = null },
                navArgument("retry") { type = NavType.StringType; nullable = true; defaultValue = null },
            ),
        ) {
            SetupScreen(
                onBack = { nav.popBackStack() },
                onStarted = { id -> nav.navigate("progress/$id") { popUpTo(Routes.HOME) } },
                onPro = { nav.navigate(Routes.PRO) },
            )
        }
        composable(Routes.PROGRESS, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) {
            ProgressScreen(
                onDone = { id -> nav.navigate("result/$id") { popUpTo(Routes.HOME) } },
                onBack = { nav.popBackStack() },
            )
        }
        composable(Routes.RESULT, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) {
            ResultScreen(
                onBack = { nav.popBackStack() },
                onReview = { id -> nav.navigate("review/$id") },
                onRetry = { id -> nav.navigate(Routes.setupRetry(id)) },
            )
        }
        composable(Routes.REVIEW, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) {
            ReviewScreen(onBack = { nav.popBackStack() })
        }
        composable(Routes.SETTINGS) { SettingsScreen(onBack = { nav.popBackStack() }, onPro = { nav.navigate(Routes.PRO) }) }
        composable(Routes.PRO) { ProScreen(onBack = { nav.popBackStack() }) }
    }
}
