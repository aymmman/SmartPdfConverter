@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.ayman.pdfword.ui.review

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.ayman.pdfword.R
import com.ayman.pdfword.core.doc.ParagraphBlock
import com.ayman.pdfword.core.doc.TableBlock
import com.ayman.pdfword.data.JobRepository
import com.ayman.pdfword.data.settings.ConversionRequest
import com.ayman.pdfword.engine.ConversionPipeline
import com.ayman.pdfword.engine.JobFiles
import com.ayman.pdfword.engine.SessionStore
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

data class ReviewItem(val id: String, val page: Int, val text: String, val confidence: Int)

@HiltViewModel
class ReviewViewModel @Inject constructor(
    savedState: SavedStateHandle,
    @ApplicationContext private val context: Context,
    private val sessions: SessionStore,
    private val jobs: JobRepository,
    private val pipeline: ConversionPipeline,
) : ViewModel() {
    private val jobId: String = savedState["jobId"] ?: ""
    val items: List<ReviewItem>
    private val _saving = MutableStateFlow(false)
    val saving = _saving.asStateFlow()
    private val _done = Channel<Boolean>(Channel.BUFFERED)
    val done = _done.receiveAsFlow()

    init {
        val model = sessions.model(jobId)
        val edits = sessions.edits(jobId)
        val list = ArrayList<ReviewItem>()
        model?.pages?.forEach { page ->
            page.parts.flatMap { it.blocks }.forEach { b ->
                when (b) {
                    is ParagraphBlock -> if (b.needsReview) list += ReviewItem(b.id, page.pageIndex + 1, edits[b.id] ?: b.text, (b.confidence ?: 0f).toInt())
                    is TableBlock -> b.cells.flatMap { it.paragraphs }.filter { it.needsReview }
                        .forEach { p -> list += ReviewItem(p.id, page.pageIndex + 1, edits[p.id] ?: p.text, (p.confidence ?: 0f).toInt()) }
                    else -> {}
                }
            }
        }
        items = list
    }

    fun save(changes: Map<String, String>) {
        val model = sessions.model(jobId) ?: return
        _saving.value = true
        viewModelScope.launch {
            val ok = runCatching {
                changes.forEach { (id, text) -> sessions.setEdit(jobId, id, text) }
                val entity = jobs.get(jobId) ?: error("missing")
                val req = ConversionRequest.fromJson(entity.requestJson)
                val out = File(entity.outputPath ?: error("missing"))
                withContext(Dispatchers.IO) {
                    pipeline.writeDocx(model, JobFiles(context, jobId), req.sourceName, sessions.edits(jobId), replace = out)
                }
            }.isSuccess
            _saving.value = false
            _done.send(ok)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(onBack: () -> Unit, vm: ReviewViewModel = hiltViewModel()) {
    val edits = androidx.compose.runtime.remember { mutableStateMapOf<String, String>() }
    val saving by vm.saving.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.done.collect { onBack() } }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.review_title)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back)) } },
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = { vm.save(edits.toMap()) }, enabled = !saving,
                    modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp).height(52.dp),
                ) { Text(stringResource(R.string.save_and_export)) }
            }
        },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Text(stringResource(R.string.review_desc), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(vm.items, key = { it.id }) { item ->
                Column {
                    Text(stringResource(R.string.review_item_header, item.page, item.confidence), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary)
                    OutlinedTextField(
                        value = edits[item.id] ?: item.text,
                        onValueChange = { edits[item.id] = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                    )
                }
            }
        }
    }
}
