package com.ayman.pdfword.di

import android.content.Context
import androidx.room.Room
import androidx.work.WorkManager
import com.ayman.pdfword.data.db.AppDatabase
import com.ayman.pdfword.data.db.ConversionDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun database(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "pdfword.db")
            .fallbackToDestructiveMigration(dropAllTables = true)
            .build()

    @Provides
    fun conversionDao(db: AppDatabase): ConversionDao = db.conversions()

    @Provides
    fun workManager(@ApplicationContext context: Context): WorkManager = WorkManager.getInstance(context)
}
