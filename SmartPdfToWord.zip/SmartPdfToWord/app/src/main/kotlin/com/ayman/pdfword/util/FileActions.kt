package com.ayman.pdfword.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.ayman.pdfword.BuildConfig
import com.ayman.pdfword.R
import com.ayman.pdfword.work.ConversionWorker
import java.io.File

object FileActions {
    private fun uriFor(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)

    fun open(context: Context, file: File) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriFor(context, file), ConversionWorker.DOCX_MIME)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, R.string.no_word_app, Toast.LENGTH_LONG).show()
        }
    }

    fun share(context: Context, file: File) {
        val intent = Intent(Intent.ACTION_SEND)
            .setType(ConversionWorker.DOCX_MIME)
            .putExtra(Intent.EXTRA_STREAM, uriFor(context, file))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, context.getString(R.string.share)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun copyTo(context: Context, file: File, dest: Uri): Boolean = runCatching {
        context.contentResolver.openOutputStream(dest, "wt")?.use { out -> file.inputStream().use { it.copyTo(out) } } != null
    }.getOrDefault(false)
}
