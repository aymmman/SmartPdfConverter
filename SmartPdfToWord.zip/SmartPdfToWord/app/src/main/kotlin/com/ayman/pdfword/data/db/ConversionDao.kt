package com.ayman.pdfword.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversionDao {
    @Query("SELECT * FROM conversions ORDER BY createdAt DESC LIMIT 200")
    fun observeAll(): Flow<List<ConversionEntity>>

    @Query("SELECT * FROM conversions WHERE id = :id")
    fun observe(id: String): Flow<ConversionEntity?>

    @Query("SELECT * FROM conversions WHERE id = :id")
    suspend fun get(id: String): ConversionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ConversionEntity)

    @Query("UPDATE conversions SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE conversions SET status = :status, finishedAt = :finishedAt, outputPath = :outputPath, outputSize = :outputSize, reportJson = :reportJson, errorMessage = :error, ocrPages = :ocrPages, tables = :tables, reviewItems = :reviewItems, exportedUri = :exportedUri WHERE id = :id")
    suspend fun finish(
        id: String, status: String, finishedAt: Long, outputPath: String?, outputSize: Long?, reportJson: String?,
        error: String?, ocrPages: Int, tables: Int, reviewItems: Int, exportedUri: String?,
    )

    @Query("DELETE FROM conversions WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM conversions")
    suspend fun clear()

    @Query("SELECT * FROM conversions")
    suspend fun all(): List<ConversionEntity>
}
