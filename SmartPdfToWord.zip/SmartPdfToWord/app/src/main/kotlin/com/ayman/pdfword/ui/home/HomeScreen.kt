@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.ayman.pdfword.ui.home

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.pdfword.R
import com.ayman.pdfword.data.db.ConversionEntity
import com.ayman.pdfword.data.db.JobStatus
import com.ayman.pdfword.data.db.jobStatus
import com.ayman.pdfword.ui.components.IconBubble
import com.ayman.pdfword.ui.components.PrivacyBadge
import com.ayman.pdfword.ui.components.formatDate
import com.ayman.pdfword.ui.components.formatSize

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onPdfPicked: (Uri) -> Unit,
    onOpenJob: (ConversionEntity) -> Unit,
    onSettings: () -> Unit,
    onPro: () -> Unit,
    vm: HomeViewModel = hiltViewModel(),
) {
    val history by vm.history.collectAsStateWithLifecycle()
    val isPro by vm.isPro.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current

    val pickOne = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onPdfPicked(uri) }
    val pickMany = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) vm.startBatch(uris) }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) {
        vm.events.collect { e ->
            when (e) {
                is HomeEvent.BatchQueued -> snackbar.showSnackbar(context.getString(R.string.batch_queued, e.queued, e.skipped))
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(stringResource(R.string.app_name), fontWeight = FontWeight.SemiBold) },
                actions = {
                    if (!isPro) IconButton(onClick = onPro) { Icon(Icons.Filled.Star, contentDescription = stringResource(R.string.pro_title), tint = MaterialTheme.colorScheme.tertiary) }
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings)) }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                HeroCard(
                    onSelect = { pickOne.launch(arrayOf("application/pdf")) },
                    onBatch = { if (isPro) pickMany.launch(arrayOf("application/pdf")) else onPro() },
                    isPro = isPro,
                )
            }
            item { Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { PrivacyBadge() } }
            item {
                Text(
                    stringResource(R.string.recent_conversions),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp, start = 4.dp),
                )
            }
            if (history.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.no_history),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(4.dp),
                    )
                }
            }
            items(history, key = { it.id }) { item ->
                HistoryRow(item, onClick = { onOpenJob(item) }, onDelete = { vm.delete(item.id) })
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun HeroCard(onSelect: () -> Unit, onBatch: () -> Unit, isPro: Boolean) {
    val c = MaterialTheme.colorScheme
    Surface(shape = MaterialTheme.shapes.extraLarge, color = c.primary) {
        Column(
            Modifier
                .background(Brush.linearGradient(listOf(c.primary, c.primary.copy(alpha = 0.85f), c.secondary.copy(alpha = 0.9f))))
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(stringResource(R.string.hero_title), style = MaterialTheme.typography.headlineMedium, color = c.onPrimary)
            Text(stringResource(R.string.hero_subtitle), style = MaterialTheme.typography.bodyMedium, color = c.onPrimary.copy(alpha = 0.9f))
            Button(
                onClick = onSelect,
                modifier = Modifier.fillMaxWidth().height(60.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.onPrimary, contentColor = c.primary),
                shape = RoundedCornerShape(18.dp),
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text(stringResource(R.string.select_pdf), style = MaterialTheme.typography.titleMedium)
            }
            OutlinedButton(
                onClick = onBatch,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = c.onPrimary),
            ) {
                Icon(Icons.Filled.List, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.batch_convert) + if (isPro) "" else "  ·  PRO")
            }
        }
    }
}

@Composable
private fun HistoryRow(item: ConversionEntity, onClick: () -> Unit, onDelete: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val (icon, tint, bg) = when (item.jobStatus) {
        JobStatus.SUCCEEDED -> Triple(Icons.Filled.CheckCircle, c.secondary, c.secondaryContainer)
        JobStatus.FAILED -> Triple(Icons.Filled.Warning, c.error, c.errorContainer)
        JobStatus.CANCELLED -> Triple(Icons.Filled.Info, c.onSurfaceVariant, c.surfaceVariant)
        else -> Triple(Icons.Filled.Refresh, c.primary, c.primaryContainer)
    }
    Surface(
        shape = MaterialTheme.shapes.large,
        color = c.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBubble(icon, tint, bg)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.sourceName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val status = when (item.jobStatus) {
                    JobStatus.QUEUED -> stringResource(R.string.status_queued)
                    JobStatus.RUNNING -> stringResource(R.string.status_running)
                    JobStatus.SUCCEEDED -> stringResource(R.string.status_done)
                    JobStatus.FAILED -> stringResource(R.string.status_failed)
                    JobStatus.CANCELLED -> stringResource(R.string.status_cancelled)
                }
                Text(
                    "$status · ${stringResource(R.string.pages_count, item.pageCount)} · ${formatSize(item.sourceSize)}",
                    style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant,
                )
                Text(formatDate(item.createdAt), style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
                if (item.jobStatus == JobStatus.SUCCEEDED && (item.ocrPages > 0 || item.tables > 0)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                        if (item.tables > 0) AssistChip(onClick = onClick, label = { Text(stringResource(R.string.chip_tables, item.tables)) })
                        if (item.ocrPages > 0) AssistChip(onClick = onClick, label = { Text(stringResource(R.string.chip_ocr, item.ocrPages)) })
                    }
                }
            }
            if (item.jobStatus != JobStatus.RUNNING && item.jobStatus != JobStatus.QUEUED) {
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete)) }
            }
        }
    }
}
