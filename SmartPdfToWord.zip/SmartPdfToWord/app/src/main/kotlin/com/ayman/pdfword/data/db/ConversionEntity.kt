package com.ayman.pdfword.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class JobStatus { QUEUED, RUNNING, SUCCEEDED, FAILED, CANCELLED }

@Entity(tableName = "conversions")
data class ConversionEntity(
    @PrimaryKey val id: String,
    val sourceName: String,
    val sourceSize: Long,
    val pageCount: Int,
    val mode: String,
    val status: String,
    val requestJson: String,
    val createdAt: Long,
    val finishedAt: Long? = null,
    val outputPath: String? = null,
    val outputSize: Long? = null,
    val exportedUri: String? = null,
    val reportJson: String? = null,
    val errorMessage: String? = null,
    val ocrPages: Int = 0,
    val tables: Int = 0,
    val reviewItems: Int = 0,
)

val ConversionEntity.jobStatus: JobStatus
    get() = runCatching { JobStatus.valueOf(status) }.getOrDefault(JobStatus.FAILED)
