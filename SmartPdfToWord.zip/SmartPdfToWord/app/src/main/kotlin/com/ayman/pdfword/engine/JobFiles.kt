package com.ayman.pdfword.engine

import android.content.Context
import java.io.File

/**
 * File layout for a job. Everything lives in app-private storage:
 *  cache/jobs/<id>/source.pdf   – private copy of the input (the original is never modified)
 *  cache/jobs/<id>/media/       – extracted images used while writing the DOCX
 *  files/outputs/<name>.docx    – finished documents (shared through FileProvider)
 */
class JobFiles(context: Context, val jobId: String) {
    val jobDir = File(context.cacheDir, "jobs/$jobId").apply { mkdirs() }
    val source = File(jobDir, "source.pdf")
    val mediaDir = File(jobDir, "media").apply { mkdirs() }
    val outputsDir = File(context.filesDir, "outputs").apply { mkdirs() }

    fun outputFor(sourceName: String): File {
        val base = sourceName.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_").take(80).ifBlank { "document" }
        var f = File(outputsDir, "$base.docx")
        var n = 2
        while (f.exists()) { f = File(outputsDir, "$base ($n).docx"); n++ }
        return f
    }

    fun deleteWorkFiles() { jobDir.deleteRecursively() }

    companion object {
        /** Removes stale job folders (e.g. after a crash) older than [maxAgeMs]. */
        fun cleanup(context: Context, maxAgeMs: Long = 6 * 60 * 60 * 1000L, keep: Set<String> = emptySet()) {
            val root = File(context.cacheDir, "jobs")
            val now = System.currentTimeMillis()
            root.listFiles()?.forEach { dir ->
                if (dir.name !in keep && now - dir.lastModified() > maxAgeMs) dir.deleteRecursively()
            }
        }

        fun clearAll(context: Context) { File(context.cacheDir, "jobs").deleteRecursively() }
    }
}
