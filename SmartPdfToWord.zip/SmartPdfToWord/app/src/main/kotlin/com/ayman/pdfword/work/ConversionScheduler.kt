package com.ayman.pdfword.work

import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/** Queues conversions; the pipeline itself runs one job at a time to keep memory use predictable. */
@Singleton
class ConversionScheduler @Inject constructor(private val workManager: WorkManager) {

    fun enqueue(jobId: String) {
        val request = OneTimeWorkRequestBuilder<ConversionWorker>()
            .setId(UUID.fromString(jobId))
            .setInputData(workDataOf(ConversionWorker.KEY_JOB_ID to jobId))
            .addTag(TAG)
            .build()
        workManager.enqueue(request)
    }

    fun observe(jobId: String): Flow<WorkInfo?> = workManager.getWorkInfoByIdFlow(UUID.fromString(jobId))

    fun cancel(jobId: String) { workManager.cancelWorkById(UUID.fromString(jobId)) }

    companion object {
        const val TAG = "conversion"
    }
}
