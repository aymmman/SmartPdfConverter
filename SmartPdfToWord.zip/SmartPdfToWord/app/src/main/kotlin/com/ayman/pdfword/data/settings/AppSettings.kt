package com.ayman.pdfword.data.settings

import com.ayman.pdfword.core.ConversionMode
import org.json.JSONObject

enum class OcrMode { AUTO, ALWAYS, OFF }
enum class OcrLanguages(val tesseract: String) { ARABIC_ENGLISH("ara+eng"), ARABIC("ara"), ENGLISH("eng") }
enum class ImageQuality(val maxPixels: Int, val jpegQuality: Int) {
    HIGH(3000, 92), BALANCED(2000, 85), SMALL(1200, 75)
}

/** User preferences (persisted in DataStore). */
data class AppSettings(
    val defaultMode: ConversionMode = ConversionMode.EDITABLE,
    val ocrMode: OcrMode = OcrMode.AUTO,
    val ocrLanguages: OcrLanguages = OcrLanguages.ARABIC_ENGLISH,
    val imageQuality: ImageQuality = ImageQuality.BALANCED,
    val keepImages: Boolean = true,
    val detectHeadersFooters: Boolean = true,
    val defaultLatinFont: String = "Calibri",
    val defaultArabicFont: String = "Arial",
    /** One rule per line: "Source font=Target font". */
    val fontRules: String = "",
    /** Persisted SAF tree URI for automatic saving, or empty. */
    val outputTreeUri: String = "",
    val deleteTempImmediately: Boolean = false,
)

/** Everything a single conversion job needs; stored as JSON with the job row. */
data class ConversionRequest(
    val jobId: String,
    val sourcePath: String,
    val sourceName: String,
    val sourceSize: Long,
    val pageCount: Int,
    val mode: ConversionMode,
    val ocrMode: OcrMode,
    val ocrLanguages: OcrLanguages,
    val pageFrom: Int,
    val pageTo: Int,
    val imageQuality: ImageQuality,
    val keepImages: Boolean,
    val detectHeadersFooters: Boolean,
    val defaultLatinFont: String,
    val defaultArabicFont: String,
    val fontRules: String,
    val highAccuracyOcr: Boolean,
    val outputTreeUri: String,
) {
    fun toJson(): String = JSONObject().apply {
        put("jobId", jobId); put("sourcePath", sourcePath); put("sourceName", sourceName); put("sourceSize", sourceSize)
        put("pageCount", pageCount); put("mode", mode.name); put("ocrMode", ocrMode.name); put("ocrLanguages", ocrLanguages.name)
        put("pageFrom", pageFrom); put("pageTo", pageTo); put("imageQuality", imageQuality.name); put("keepImages", keepImages)
        put("detectHeadersFooters", detectHeadersFooters); put("defaultLatinFont", defaultLatinFont); put("defaultArabicFont", defaultArabicFont)
        put("fontRules", fontRules); put("highAccuracyOcr", highAccuracyOcr); put("outputTreeUri", outputTreeUri)
    }.toString()

    companion object {
        fun fromJson(s: String): ConversionRequest {
            val o = JSONObject(s)
            return ConversionRequest(
                jobId = o.getString("jobId"), sourcePath = o.getString("sourcePath"), sourceName = o.getString("sourceName"),
                sourceSize = o.optLong("sourceSize"), pageCount = o.optInt("pageCount"),
                mode = ConversionMode.valueOf(o.optString("mode", "EDITABLE")),
                ocrMode = OcrMode.valueOf(o.optString("ocrMode", "AUTO")),
                ocrLanguages = OcrLanguages.valueOf(o.optString("ocrLanguages", "ARABIC_ENGLISH")),
                pageFrom = o.optInt("pageFrom", 1), pageTo = o.optInt("pageTo", o.optInt("pageCount")),
                imageQuality = ImageQuality.valueOf(o.optString("imageQuality", "BALANCED")),
                keepImages = o.optBoolean("keepImages", true), detectHeadersFooters = o.optBoolean("detectHeadersFooters", true),
                defaultLatinFont = o.optString("defaultLatinFont", "Calibri"), defaultArabicFont = o.optString("defaultArabicFont", "Arial"),
                fontRules = o.optString("fontRules", ""), highAccuracyOcr = o.optBoolean("highAccuracyOcr", false),
                outputTreeUri = o.optString("outputTreeUri", ""),
            )
        }

        /** Parses "Source=Target" lines into normalised-key rules for the font mapper. */
        fun parseFontRules(text: String): Map<String, String> = text.lines()
            .mapNotNull { line ->
                val i = line.indexOf('=')
                if (i <= 0) null else {
                    val src = line.substring(0, i).trim(); val dst = line.substring(i + 1).trim()
                    if (src.isEmpty() || dst.isEmpty()) null
                    else com.ayman.pdfword.core.font.FontMapper.normalizeKey(src) to dst
                }
            }.toMap()
    }
}
