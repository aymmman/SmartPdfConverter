package com.ayman.pdfword.data.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.ayman.pdfword.BuildConfig
import com.ayman.pdfword.data.settings.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Google Play Billing for the Pro subscription.
 *
 * Conversion itself never depends on the billing service: the last known
 * entitlement is cached locally so Pro keeps working offline. Debug builds
 * unlock Pro so every feature can be tested from a side-loaded APK.
 */
@Singleton
class BillingManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settings: SettingsRepository,
) : PurchasesUpdatedListener {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val livePro = MutableStateFlow<Boolean?>(null)
    private val _product = MutableStateFlow<ProductDetails?>(null)
    val product: StateFlow<ProductDetails?> = _product.asStateFlow()
    private val _billingAvailable = MutableStateFlow(false)
    val billingAvailable: StateFlow<Boolean> = _billingAvailable.asStateFlow()

    val isPro: StateFlow<Boolean> = combine(livePro, settings.proCached) { live, cached ->
        BuildConfig.DEBUG || (live ?: cached)
    }.stateIn(scope, SharingStarted.Eagerly, BuildConfig.DEBUG)

    private val client: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .enableAutoServiceReconnection()
        .build()

    fun start() {
        if (client.isReady) { refresh(); return }
        runCatching {
            client.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(result: BillingResult) {
                    _billingAvailable.value = result.responseCode == BillingClient.BillingResponseCode.OK
                    if (_billingAvailable.value) refresh()
                }

                override fun onBillingServiceDisconnected() {
                    _billingAvailable.value = false
                }
            })
        }
    }

    fun refresh() {
        if (!client.isReady) return
        val params = QueryProductDetailsParams.newBuilder().setProductList(
            listOf(
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(PRO_PRODUCT_ID)
                    .setProductType(BillingClient.ProductType.SUBS)
                    .build()
            )
        ).build()
        client.queryProductDetailsAsync(params) { result, details ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                _product.value = details.productDetailsList.firstOrNull()
            }
        }
        client.queryPurchasesAsync(
            QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
        ) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) handlePurchases(purchases)
        }
    }

    /** Returns false if the product is not available (e.g. not installed from Play). */
    fun launchPurchase(activity: Activity): Boolean {
        val details = _product.value ?: return false
        val offer = details.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: return false
        val params = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(
                listOf(
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .setOfferToken(offer)
                        .build()
                )
            ).build()
        return client.launchBillingFlow(activity, params).responseCode == BillingClient.BillingResponseCode.OK
    }

    fun priceText(): String? = _product.value?.subscriptionOfferDetails?.firstOrNull()
        ?.pricingPhases?.pricingPhaseList?.lastOrNull()?.formattedPrice

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) handlePurchases(purchases)
    }

    private fun handlePurchases(purchases: List<Purchase>) {
        val active = purchases.filter { PRO_PRODUCT_ID in it.products && it.purchaseState == Purchase.PurchaseState.PURCHASED }
        livePro.value = active.isNotEmpty()
        scope.launch { settings.setProCached(active.isNotEmpty()) }
        for (p in active) {
            if (!p.isAcknowledged) {
                val ack = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()
                client.acknowledgePurchase(ack) { }
            }
        }
    }

    companion object {
        /** Subscription product id to create in Google Play Console. */
        const val PRO_PRODUCT_ID = "pro_subscription"

        // Free-tier limits (honest, enforced before a job starts).
        const val FREE_MAX_PAGES = 50
        const val PRO_MAX_PAGES = 2000
    }
}
