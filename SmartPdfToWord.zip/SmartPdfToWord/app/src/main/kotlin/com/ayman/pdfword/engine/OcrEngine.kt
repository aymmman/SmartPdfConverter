package com.ayman.pdfword.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.ocr.OcrWord
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.Closeable
import java.io.File

/**
 * On-device OCR with Tesseract (LSTM models for Arabic and English).
 *
 * Google ML Kit's on-device text recognition does not support Arabic script, so
 * Tesseract is used for both languages. Models are bundled in assets/tessdata
 * (downloaded at build time) and copied to private storage on first use.
 */
class OcrEngine(private val context: Context) : Closeable {

    private var api: TessBaseAPI? = null
    private var loadedLangs: String? = null

    private val dataRoot = File(context.filesDir, "tesseract")
    private val tessdata = File(dataRoot, "tessdata")

    fun availableLanguages(): Set<String> {
        val bundled = runCatching { context.assets.list("tessdata")?.toList() }.getOrNull().orEmpty()
        return bundled.filter { it.endsWith(".traineddata") }.map { it.removeSuffix(".traineddata") }.toSet()
    }

    /** Copies the requested models from assets if needed. Returns the languages actually usable. */
    private fun prepare(langs: String): String? {
        val wanted = langs.split('+').filter { it.isNotBlank() }
        val available = availableLanguages()
        val usable = wanted.filter { it in available }
        if (usable.isEmpty()) return null
        tessdata.mkdirs()
        for (l in usable) {
            val target = File(tessdata, "$l.traineddata")
            if (target.exists() && target.length() > 0) continue
            val tmp = File(tessdata, "$l.traineddata.tmp")
            context.assets.open("tessdata/$l.traineddata").use { input -> tmp.outputStream().use { input.copyTo(it, 1 shl 16) } }
            tmp.renameTo(target)
        }
        return usable.joinToString("+")
    }

    fun isAvailable(langs: String): Boolean = langs.split('+').any { it in availableLanguages() }

    private fun ensure(langs: String): TessBaseAPI? {
        val usable = prepare(langs) ?: return null
        if (api != null && loadedLangs == usable) return api
        api?.recycle()
        val a = TessBaseAPI()
        if (!a.init(dataRoot.absolutePath, usable, TessBaseAPI.OEM_LSTM_ONLY)) {
            a.recycle()
            return null
        }
        a.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
        api = a
        loadedLangs = usable
        return a
    }

    /**
     * Recognises a rendered page. [pointsPerPixel] converts pixel boxes to page points;
     * [offsetX]/[offsetY] are added (for region crops).
     */
    fun recognize(bitmap: Bitmap, langs: String, pointsPerPixel: Float, offsetX: Float = 0f, offsetY: Float = 0f): List<OcrWord> {
        val a = ensure(langs) ?: return emptyList()
        a.setImage(bitmap)
        a.getUTF8Text() // runs recognition
        val iterator = a.getResultIterator() ?: return emptyList<OcrWord>().also { a.clear() }
        val lineRects = ArrayList<Rect>()
        val words = ArrayList<Triple<String, Rect, Float>>()
        try {
            iterator.begin()
            do {
                val r = iterator.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE)
                if (r != null && r.width() > 0 && r.height() > 0) lineRects += Rect(r)
            } while (iterator.next(TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE))
            iterator.begin()
            do {
                val text = iterator.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_WORD)
                val r = iterator.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_WORD)
                val conf = iterator.confidence(TessBaseAPI.PageIteratorLevel.RIL_WORD)
                if (!text.isNullOrBlank() && r != null && r.width() > 0 && r.height() > 0) words += Triple(text, Rect(r), conf)
            } while (iterator.next(TessBaseAPI.PageIteratorLevel.RIL_WORD))
        } finally {
            iterator.delete()
            a.clear()
        }
        return words.map { (text, r, conf) ->
            val cx = r.exactCenterX(); val cy = r.exactCenterY()
            var line = lineRects.indexOfFirst { it.contains(cx.toInt(), cy.toInt()) }
            if (line < 0) line = lineRects.indices.minByOrNull { kotlin.math.abs(lineRects[it].exactCenterY() - cy) } ?: 0
            OcrWord(
                text = text.trim(),
                box = Box(offsetX + r.left * pointsPerPixel, offsetY + r.top * pointsPerPixel, offsetX + r.right * pointsPerPixel, offsetY + r.bottom * pointsPerPixel),
                confidence = conf.coerceIn(0f, 100f),
                lineId = line,
                color = estimateInk(bitmap, r),
            )
        }
    }

    /** Average colour of the darkest pixels inside the word box (keeps red/blue text coloured). */
    private fun estimateInk(bitmap: Bitmap, r: Rect): Int {
        val x0 = r.left.coerceIn(0, bitmap.width - 1); val x1 = r.right.coerceIn(x0 + 1, bitmap.width)
        val y0 = r.top.coerceIn(0, bitmap.height - 1); val y1 = r.bottom.coerceIn(y0 + 1, bitmap.height)
        val stepX = maxOf(1, (x1 - x0) / 24); val stepY = maxOf(1, (y1 - y0) / 8)
        var rs = 0L; var gs = 0L; var bs = 0L; var n = 0
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val c = bitmap.getPixel(x, y)
                val rr = (c shr 16) and 0xFF; val gg = (c shr 8) and 0xFF; val bb = c and 0xFF
                if ((rr * 30 + gg * 59 + bb * 11) / 100 < 110) { rs += rr; gs += gg; bs += bb; n++ }
                x += stepX
            }
            y += stepY
        }
        if (n == 0) return 0
        val rr = (rs / n).toInt(); val gg = (gs / n).toInt(); val bb = (bs / n).toInt()
        // Near-grey ink is treated as black.
        return if (maxOf(rr, gg, bb) - minOf(rr, gg, bb) < 40) 0 else (rr shl 16) or (gg shl 8) or bb
    }

    fun stop() { runCatching { api?.stop() } }

    override fun close() {
        runCatching { api?.recycle() }
        api = null
    }
}
