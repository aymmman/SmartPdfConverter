package com.ayman.pdfword.engine

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import java.io.File
import java.io.IOException

class PdfImportException(val reason: Reason, message: String? = null) : Exception(message) {
    enum class Reason { NOT_PDF, UNREADABLE, EMPTY, PASSWORD_REQUIRED, WRONG_PASSWORD, CORRUPT }
}

data class PdfInfo(val name: String, val size: Long, val pageCount: Int, val encrypted: Boolean)

object PdfSource {

    /** Copies a picked document into the job folder after validating the PDF header. */
    fun importUri(context: Context, uri: Uri, target: File): Pair<String, Long> {
        val resolver = context.contentResolver
        var name = "document.pdf"
        var size = -1L
        runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    c.getString(0)?.let { name = it }
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
        }
        target.parentFile?.mkdirs()
        val input = try { resolver.openInputStream(uri) } catch (e: Exception) { null }
            ?: throw PdfImportException(PdfImportException.Reason.UNREADABLE)
        input.use { ins -> target.outputStream().use { ins.copyTo(it, 1 shl 16) } }
        if (target.length() == 0L) throw PdfImportException(PdfImportException.Reason.EMPTY)
        if (!looksLikePdf(target)) { target.delete(); throw PdfImportException(PdfImportException.Reason.NOT_PDF) }
        return name to (if (size > 0) size else target.length())
    }

    /** "%PDF-" must appear within the first 1 KB (some files carry a small preamble). */
    fun looksLikePdf(f: File): Boolean = f.inputStream().use { s ->
        val buf = ByteArray(1024)
        val n = s.read(buf)
        if (n <= 0) return false
        String(buf, 0, n, Charsets.ISO_8859_1).contains("%PDF-")
    }

    fun open(file: File, password: String?): PDDocument = try {
        PDDocument.load(file, password ?: "", MemoryUsageSetting.setupTempFileOnly())
    } catch (e: InvalidPasswordException) {
        throw PdfImportException(
            if (password.isNullOrEmpty()) PdfImportException.Reason.PASSWORD_REQUIRED else PdfImportException.Reason.WRONG_PASSWORD
        )
    } catch (e: IOException) {
        throw PdfImportException(PdfImportException.Reason.CORRUPT, e.message)
    }

    fun probe(file: File, name: String, size: Long, password: String?): PdfInfo {
        open(file, password).use { doc ->
            val pages = doc.numberOfPages
            if (pages <= 0) throw PdfImportException(PdfImportException.Reason.EMPTY)
            return PdfInfo(name, size, pages, doc.isEncrypted)
        }
    }
}
