package com.ayman.pdfword.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.ayman.pdfword.core.model.Box
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.rendering.PDFRenderer
import java.io.Closeable
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Renders pages or page regions to bitmaps. Uses the platform renderer (PDFium)
 * for speed and codec coverage, falling back to PDFBox for encrypted files.
 * Coordinates are display-space points (top-left origin, rotation applied).
 */
class PageRasterizer(file: File, private val doc: PDDocument, encrypted: Boolean) : Closeable {
    private val pfd: ParcelFileDescriptor? = if (!encrypted) runCatching { ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY) }.getOrNull() else null
    private val platform: PdfRenderer? = pfd?.let { runCatching { PdfRenderer(it) }.getOrNull() }
    private val pdfbox by lazy { PDFRenderer(doc) }
    private val lock = Any()

    /** Caps bitmap size so a single render stays well within memory limits. */
    private fun safeScale(widthPt: Float, heightPt: Float, dpi: Int, maxPixels: Long = 16_000_000L): Float {
        var s = dpi / 72f
        val px = widthPt * s * heightPt * s
        if (px > maxPixels) s *= kotlin.math.sqrt(maxPixels / px).toFloat()
        return s
    }

    fun renderPage(index: Int, dpi: Int, pageW: Float, pageH: Float): Pair<Bitmap, Float> =
        renderRegion(index, Box(0f, 0f, pageW, pageH), dpi, pageW, pageH)

    /** Returns the bitmap and the scale in pixels per point. */
    fun renderRegion(index: Int, region: Box, dpi: Int, pageW: Float, pageH: Float): Pair<Bitmap, Float> = synchronized(lock) {
        val r = Box(max(0f, region.x0), max(0f, region.top), min(pageW, region.x1), min(pageH, region.bottom))
        val s = safeScale(r.width, r.height, dpi)
        val wPx = max(1, (r.width * s).roundToInt())
        val hPx = max(1, (r.height * s).roundToInt())
        val renderer = platform
        if (renderer != null) {
            renderer.openPage(index).use { page ->
                // PDFium page size may differ slightly from the crop box; map proportionally.
                val sx = page.width / pageW
                val sy = page.height / pageH
                val bmp = Bitmap.createBitmap(wPx, hPx, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                val m = Matrix()
                m.setScale(s / sx, s / sy)
                m.postTranslate(-r.x0 * s, -r.top * s)
                page.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp to s
            }
        }
        // PDFBox fallback (encrypted documents): render whole page then crop.
        val full = pdfbox.renderImage(index, s)
        val x = (r.x0 * s).roundToInt().coerceIn(0, full.width - 1)
        val y = (r.top * s).roundToInt().coerceIn(0, full.height - 1)
        val w = wPx.coerceAtMost(full.width - x)
        val h = hPx.coerceAtMost(full.height - y)
        val cropped = if (x == 0 && y == 0 && w == full.width && h == full.height) full else Bitmap.createBitmap(full, x, y, w, h)
        if (cropped !== full) full.recycle()
        return cropped to s
    }

    override fun close() {
        runCatching { platform?.close() }
        runCatching { pfd?.close() }
    }
}
