package com.ayman.pdfword.ui.result

import org.json.JSONArray
import org.json.JSONObject

/** UI view of the engine's ConversionReport JSON. */
data class ReportUi(
    val totalPages: Int,
    val pagesProcessed: Int,
    val pagesFailed: List<Int>,
    val ocrPages: List<Int>,
    val ocrConfidence: Float?,
    val textQuality: Float?,
    val fontsPreserved: List<Pair<String, String>>,
    val fontsUnverified: List<Pair<String, String>>,
    val fontsSubstituted: List<Pair<String, String>>,
    val tables: Int,
    val borderlessTables: Int,
    val images: Int,
    val figures: Int,
    val uncertain: List<Pair<Int, String>>,
    val ocrWarnings: List<String>,
    val reviewItems: List<String>,
    val warnings: List<String>,
    val durationMs: Long,
    val mode: String,
) {
    companion object {
        private fun ints(a: JSONArray?) = if (a == null) emptyList() else (0 until a.length()).map { a.getInt(it) }
        private fun strings(a: JSONArray?) = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

        fun parse(json: String?): ReportUi? {
            if (json.isNullOrBlank()) return null
            return runCatching {
                val o = JSONObject(json)
                val fonts = o.optJSONArray("fonts") ?: JSONArray()
                val fp = ArrayList<Pair<String, String>>(); val fu = ArrayList<Pair<String, String>>(); val fs = ArrayList<Pair<String, String>>()
                for (i in 0 until fonts.length()) {
                    val f = fonts.getJSONObject(i)
                    val src = f.optString("source").substringAfter('+'); val used = f.optString("used")
                    when (f.optString("status")) {
                        "PRESERVED", "USER_RULE" -> fp += src to used
                        "KEPT_UNVERIFIED" -> fu += src to used
                        else -> fs += src to used
                    }
                }
                val up = o.optJSONArray("uncertainPages") ?: JSONArray()
                ReportUi(
                    totalPages = o.optInt("totalPages"), pagesProcessed = o.optInt("pagesProcessed"),
                    pagesFailed = ints(o.optJSONArray("pagesFailed")), ocrPages = ints(o.optJSONArray("ocrPages")),
                    ocrConfidence = if (o.isNull("averageOcrConfidence")) null else o.optDouble("averageOcrConfidence").toFloat(),
                    textQuality = if (o.isNull("textLayerQuality")) null else o.optDouble("textLayerQuality").toFloat(),
                    fontsPreserved = fp, fontsUnverified = fu, fontsSubstituted = fs,
                    tables = o.optInt("tablesDetected"), borderlessTables = o.optInt("borderlessTables"),
                    images = o.optInt("imagesDetected"), figures = o.optInt("figuresRasterized"),
                    uncertain = (0 until up.length()).map { up.getJSONObject(it).let { u -> u.optInt("page") to u.optString("reason") } },
                    ocrWarnings = strings(o.optJSONArray("ocrWarnings")), reviewItems = strings(o.optJSONArray("reviewItems")),
                    warnings = strings(o.optJSONArray("warnings")), durationMs = o.optLong("durationMs"), mode = o.optString("mode"),
                )
            }.getOrNull()
        }
    }
}
