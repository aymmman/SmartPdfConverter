package com.ayman.pdfword.engine

import com.ayman.pdfword.core.doc.DocModel
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * In-memory, per-process state that must never be written to disk:
 * PDF passwords and the reconstructed document model used by the review screen.
 */
@Singleton
class SessionStore @Inject constructor() {
    private val passwords = ConcurrentHashMap<String, String>()
    private val models = ConcurrentHashMap<String, DocModel>()
    private val edits = ConcurrentHashMap<String, MutableMap<String, String>>()

    fun setPassword(jobId: String, password: String?) { if (password.isNullOrEmpty()) passwords.remove(jobId) else passwords[jobId] = password }
    fun password(jobId: String): String? = passwords[jobId]
    fun clearPassword(jobId: String) { passwords.remove(jobId) }

    fun putModel(jobId: String, model: DocModel) { models[jobId] = model }
    fun model(jobId: String): DocModel? = models[jobId]

    fun edits(jobId: String): Map<String, String> = edits[jobId]?.toMap() ?: emptyMap()
    fun setEdit(jobId: String, paragraphId: String, text: String) { edits.getOrPut(jobId) { ConcurrentHashMap() }[paragraphId] = text }

    fun forget(jobId: String) { passwords.remove(jobId); models.remove(jobId); edits.remove(jobId) }
}
