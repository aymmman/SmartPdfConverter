package com.ayman.pdfword.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ayman.pdfword.core.ConversionMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext private val context: Context) {

    private object K {
        val mode = stringPreferencesKey("mode")
        val ocrMode = stringPreferencesKey("ocr_mode")
        val ocrLangs = stringPreferencesKey("ocr_langs")
        val imageQuality = stringPreferencesKey("image_quality")
        val keepImages = booleanPreferencesKey("keep_images")
        val headersFooters = booleanPreferencesKey("headers_footers")
        val latinFont = stringPreferencesKey("latin_font")
        val arabicFont = stringPreferencesKey("arabic_font")
        val fontRules = stringPreferencesKey("font_rules")
        val outputTree = stringPreferencesKey("output_tree")
        val deleteTemp = booleanPreferencesKey("delete_temp")
        val proCached = booleanPreferencesKey("pro_cached")
        val proCheckedAt = longPreferencesKey("pro_checked_at")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            defaultMode = p[K.mode]?.let { runCatching { ConversionMode.valueOf(it) }.getOrNull() } ?: ConversionMode.EDITABLE,
            ocrMode = p[K.ocrMode]?.let { runCatching { OcrMode.valueOf(it) }.getOrNull() } ?: OcrMode.AUTO,
            ocrLanguages = p[K.ocrLangs]?.let { runCatching { OcrLanguages.valueOf(it) }.getOrNull() } ?: OcrLanguages.ARABIC_ENGLISH,
            imageQuality = p[K.imageQuality]?.let { runCatching { ImageQuality.valueOf(it) }.getOrNull() } ?: ImageQuality.BALANCED,
            keepImages = p[K.keepImages] ?: true,
            detectHeadersFooters = p[K.headersFooters] ?: true,
            defaultLatinFont = p[K.latinFont] ?: "Calibri",
            defaultArabicFont = p[K.arabicFont] ?: "Arial",
            fontRules = p[K.fontRules] ?: "",
            outputTreeUri = p[K.outputTree] ?: "",
            deleteTempImmediately = p[K.deleteTemp] ?: false,
        )
    }

    suspend fun current(): AppSettings = settings.first()

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        val s = transform(current())
        context.dataStore.edit { p ->
            p[K.mode] = s.defaultMode.name
            p[K.ocrMode] = s.ocrMode.name
            p[K.ocrLangs] = s.ocrLanguages.name
            p[K.imageQuality] = s.imageQuality.name
            p[K.keepImages] = s.keepImages
            p[K.headersFooters] = s.detectHeadersFooters
            p[K.latinFont] = s.defaultLatinFont
            p[K.arabicFont] = s.defaultArabicFont
            p[K.fontRules] = s.fontRules
            p[K.outputTree] = s.outputTreeUri
            p[K.deleteTemp] = s.deleteTempImmediately
        }
    }

    /** Last known Pro entitlement, so Pro keeps working offline. */
    val proCached: Flow<Boolean> = context.dataStore.data.map { it[K.proCached] ?: false }

    suspend fun setProCached(value: Boolean) {
        context.dataStore.edit { it[K.proCached] = value; it[K.proCheckedAt] = System.currentTimeMillis() }
    }
}
