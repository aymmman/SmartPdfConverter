@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.ayman.pdfword.ui.setup

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ayman.pdfword.R
import com.ayman.pdfword.core.ConversionMode
import com.ayman.pdfword.data.settings.ImageQuality
import com.ayman.pdfword.data.settings.OcrLanguages
import com.ayman.pdfword.data.settings.OcrMode
import com.ayman.pdfword.engine.PdfImportException
import com.ayman.pdfword.ui.components.PrivacyBadge
import com.ayman.pdfword.ui.components.SectionCard
import com.ayman.pdfword.ui.components.formatSize

val LATIN_FONTS = listOf("Calibri", "Arial", "Times New Roman", "Cambria", "Aptos", "Segoe UI", "Tahoma", "Verdana", "Georgia", "Garamond")
val ARABIC_FONTS = listOf("Arial", "Simplified Arabic", "Traditional Arabic", "Sakkal Majalla", "Arabic Typesetting", "Dubai", "Tahoma", "Times New Roman", "Amiri", "Noto Naskh Arabic", "Cairo")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(onBack: () -> Unit, onStarted: (String) -> Unit, onPro: () -> Unit, vm: SetupViewModel = hiltViewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.started.collect { onStarted(it) } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.setup_title)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back)) } },
            )
        },
        bottomBar = {
            if (s.info != null) {
                Surface(tonalElevation = 3.dp) {
                    Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp)) {
                        if (s.overLimit) {
                            Text(
                                stringResource(R.string.limit_free_pages, s.maxPages),
                                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(bottom = 8.dp),
                            )
                        }
                        Button(
                            onClick = { if (s.overLimit && !s.isPro) onPro() else vm.start() },
                            enabled = s.rangeValid && !s.starting,
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                        ) { Text(if (s.overLimit && !s.isPro) stringResource(R.string.upgrade_to_convert) else stringResource(R.string.convert_now)) }
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                s.loading -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text(stringResource(R.string.reading_pdf))
                }
                s.error != null -> ErrorView(s.error!!, onBack)
                s.needsPassword -> PasswordView(s.wrongPassword, vm::submitPassword)
                s.info != null -> Options(s, vm, onPro)
            }
        }
    }
}

@Composable
private fun ErrorView(reason: PdfImportException.Reason, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(12.dp))
        val msg = when (reason) {
            PdfImportException.Reason.NOT_PDF -> R.string.err_not_pdf
            PdfImportException.Reason.EMPTY -> R.string.err_empty
            PdfImportException.Reason.CORRUPT -> R.string.err_corrupt
            PdfImportException.Reason.UNREADABLE -> R.string.err_unreadable
            else -> R.string.err_corrupt
        }
        Text(stringResource(msg), style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onBack) { Text(stringResource(R.string.back)) }
    }
}

@Composable
private fun PasswordView(wrong: Boolean, onSubmit: (String) -> Unit) {
    var pw by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.password_title), style = MaterialTheme.typography.titleLarge)
        Text(stringResource(R.string.password_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = pw, onValueChange = { pw = it }, singleLine = true,
            label = { Text(stringResource(R.string.password)) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            isError = wrong,
            supportingText = { if (wrong) Text(stringResource(R.string.password_wrong)) },
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onSubmit(pw) }, enabled = pw.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.unlock)) }
    }
}

@Composable
private fun Options(s: SetupUiState, vm: SetupViewModel, onPro: () -> Unit) {
    val info = s.info ?: return
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard {
            Text(info.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                "${stringResource(R.string.pages_count, info.pageCount)} · ${formatSize(info.size)}" +
                    if (info.encrypted) " · " + stringResource(R.string.protected_pdf) else "",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            PrivacyBadge()
        }

        SectionCard(title = stringResource(R.string.conversion_mode)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = s.mode == ConversionMode.EDITABLE, onClick = { vm.setMode(ConversionMode.EDITABLE) },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                ) { Text(stringResource(R.string.mode_editable)) }
                SegmentedButton(
                    selected = s.mode == ConversionMode.LAYOUT,
                    onClick = { if (s.isPro) vm.setMode(ConversionMode.LAYOUT) else onPro() },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                ) { Text(stringResource(R.string.mode_layout) + if (s.isPro) "" else " · PRO") }
            }
            Text(
                stringResource(if (s.mode == ConversionMode.EDITABLE) R.string.mode_editable_desc else R.string.mode_layout_desc),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        SectionCard(title = stringResource(R.string.ocr_title)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                val modes = listOf(OcrMode.AUTO to R.string.ocr_auto, OcrMode.ALWAYS to R.string.ocr_always, OcrMode.OFF to R.string.ocr_off)
                modes.forEachIndexed { i, (m, label) ->
                    SegmentedButton(selected = s.ocrMode == m, onClick = { vm.setOcrMode(m) }, shape = SegmentedButtonDefaults.itemShape(i, modes.size)) { Text(stringResource(label)) }
                }
            }
            Text(stringResource(R.string.ocr_desc), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(stringResource(R.string.recognition_languages), style = MaterialTheme.typography.labelLarge)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                val langs = listOf(OcrLanguages.ARABIC_ENGLISH to R.string.lang_both, OcrLanguages.ARABIC to R.string.lang_ar, OcrLanguages.ENGLISH to R.string.lang_en)
                langs.forEachIndexed { i, (l, label) ->
                    SegmentedButton(selected = s.ocrLanguages == l, onClick = { vm.setOcrLanguages(l) }, shape = SegmentedButtonDefaults.itemShape(i, langs.size)) { Text(stringResource(label)) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.high_accuracy_ocr) + if (s.isPro) "" else " · PRO", style = MaterialTheme.typography.bodyLarge)
                    Text(stringResource(R.string.high_accuracy_ocr_desc), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = s.highAccuracyOcr && s.isPro, onCheckedChange = { if (s.isPro) vm.setHighAccuracy(it) else onPro() })
            }
        }

        SectionCard(title = stringResource(R.string.page_range)) {
            var fromText by remember(info.pageCount) { mutableStateOf(s.pageFrom.toString()) }
            var toText by remember(info.pageCount) { mutableStateOf(s.pageTo.toString()) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = fromText, singleLine = true, modifier = Modifier.weight(1f),
                    onValueChange = { v -> fromText = v.filter { it.isDigit() }.take(5); vm.setRange(fromText.toIntOrNull() ?: 0, s.pageTo) },
                    label = { Text(stringResource(R.string.from_page)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                OutlinedTextField(
                    value = toText, singleLine = true, modifier = Modifier.weight(1f),
                    onValueChange = { v -> toText = v.filter { it.isDigit() }.take(5); vm.setRange(s.pageFrom, toText.toIntOrNull() ?: 0) },
                    label = { Text(stringResource(R.string.to_page)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            }
            if (!s.rangeValid) Text(stringResource(R.string.range_invalid, info.pageCount), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        SectionCard(title = stringResource(R.string.images_quality)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                val qs = listOf(ImageQuality.HIGH to R.string.quality_high, ImageQuality.BALANCED to R.string.quality_balanced, ImageQuality.SMALL to R.string.quality_small)
                qs.forEachIndexed { i, (q, label) ->
                    SegmentedButton(selected = s.imageQuality == q, onClick = { vm.setQuality(q) }, shape = SegmentedButtonDefaults.itemShape(i, qs.size)) { Text(stringResource(label)) }
                }
            }
        }

        SectionCard(title = stringResource(R.string.font_substitution)) {
            Text(stringResource(R.string.font_substitution_desc), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FontPicker(stringResource(R.string.latin_font), s.latinFont, LATIN_FONTS, vm::setLatinFont)
            FontPicker(stringResource(R.string.arabic_font), s.arabicFont, ARABIC_FONTS, vm::setArabicFont)
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
fun FontPicker(label: String, value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Box {
            OutlinedButton(onClick = { open = true }) { Text(value) }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                for (o in options) DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false })
            }
        }
    }
    Spacer(Modifier.width(1.dp))
}
