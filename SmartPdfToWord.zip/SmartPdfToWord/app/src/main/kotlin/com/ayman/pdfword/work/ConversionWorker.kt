package com.ayman.pdfword.work

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.ayman.pdfword.MainActivity
import com.ayman.pdfword.R
import com.ayman.pdfword.data.db.ConversionDao
import com.ayman.pdfword.data.db.JobStatus
import com.ayman.pdfword.data.settings.ConversionRequest
import com.ayman.pdfword.engine.ConversionFailedException
import com.ayman.pdfword.engine.ConversionPipeline
import com.ayman.pdfword.engine.JobFiles
import com.ayman.pdfword.engine.SessionStore
import com.ayman.pdfword.engine.Stage
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext

@HiltWorker
class ConversionWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val pipeline: ConversionPipeline,
    private val dao: ConversionDao,
    private val sessions: SessionStore,
    private val settings: com.ayman.pdfword.data.settings.SettingsRepository,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val jobId = inputData.getString(KEY_JOB_ID) ?: return Result.failure()
        val entity = dao.get(jobId) ?: return Result.failure()
        val request = runCatching { ConversionRequest.fromJson(entity.requestJson) }.getOrElse { return Result.failure() }
        dao.setStatus(jobId, JobStatus.RUNNING.name)
        runCatching { setForeground(foregroundInfo(request.sourceName, 0, 0, Stage.PREPARING)) }
        var lastNotified = 0L
        return try {
            val outcome = pipeline.runExclusive(request) { p ->
                setProgress(workDataOf(KEY_STAGE to p.stage.name, KEY_PAGE to p.page, KEY_TOTAL to p.totalPages))
                val now = System.currentTimeMillis()
                if (now - lastNotified > 700) {
                    lastNotified = now
                    runCatching { setForeground(foregroundInfo(request.sourceName, p.page, p.totalPages, p.stage)) }
                }
            }
            setProgress(workDataOf(KEY_STAGE to Stage.SAVING.name, KEY_PAGE to outcome.report.pagesProcessed, KEY_TOTAL to outcome.report.totalPages))
            val exported = exportToTree(request, outcome.output)
            dao.finish(
                id = jobId, status = JobStatus.SUCCEEDED.name, finishedAt = System.currentTimeMillis(),
                outputPath = outcome.output.absolutePath, outputSize = outcome.output.length(), reportJson = outcome.report.toJson(),
                error = null, ocrPages = outcome.report.ocrPages.size, tables = outcome.report.tablesDetected,
                reviewItems = outcome.report.reviewItems.size, exportedUri = exported,
            )
            sessions.clearPassword(jobId)
            if (settings.current().deleteTempImmediately) JobFiles(applicationContext, jobId).deleteWorkFiles()
            notifyDone(jobId, request.sourceName, success = true)
            Result.success(workDataOf(KEY_JOB_ID to jobId))
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                dao.finish(jobId, JobStatus.CANCELLED.name, System.currentTimeMillis(), null, null, null, "cancelled", 0, 0, 0, null)
            }
            throw e
        } catch (e: Throwable) {
            val code = (e as? ConversionFailedException)?.code ?: if (e is OutOfMemoryError) "out_of_memory" else "unexpected"
            dao.finish(jobId, JobStatus.FAILED.name, System.currentTimeMillis(), null, null, null, code, 0, 0, 0, null)
            notifyDone(jobId, request.sourceName, success = false)
            // Reported as success to WorkManager: the failure is recorded in the database and shown in the UI.
            Result.success(workDataOf(KEY_JOB_ID to jobId, KEY_ERROR to code))
        } finally {
            if (isStopped) JobFiles(applicationContext, jobId).deleteWorkFiles()
        }
    }

    /** Copies the result into the user's chosen output folder (Storage Access Framework). */
    private fun exportToTree(request: ConversionRequest, file: java.io.File): String? {
        if (request.outputTreeUri.isBlank()) return null
        return runCatching {
            val tree = DocumentFile.fromTreeUri(applicationContext, Uri.parse(request.outputTreeUri)) ?: return null
            val target = tree.createFile(DOCX_MIME, file.name) ?: return null
            applicationContext.contentResolver.openOutputStream(target.uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            target.uri.toString()
        }.getOrNull()
    }

    private fun foregroundInfo(name: String, page: Int, total: Int, stage: Stage): ForegroundInfo {
        ensureChannel(applicationContext)
        val text = when (stage) {
            Stage.OCR -> applicationContext.getString(R.string.notif_ocr, page, total)
            Stage.WRITING, Stage.SAVING -> applicationContext.getString(R.string.notif_writing)
            else -> if (total > 0) applicationContext.getString(R.string.notif_page, page, total) else applicationContext.getString(R.string.notif_preparing)
        }
        val n = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_convert)
            .setContentTitle(name)
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(max(total, 1), page, total == 0)
            .setContentIntent(openAppIntent(null))
            .build()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ForegroundInfo(NOTIF_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(NOTIF_PROGRESS, n)
    }

    private fun max(a: Int, b: Int) = if (a > b) a else b

    private fun openAppIntent(jobId: String?): PendingIntent {
        val i = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (jobId != null) putExtra(MainActivity.EXTRA_OPEN_JOB, jobId)
        }
        return PendingIntent.getActivity(applicationContext, jobId?.hashCode() ?: 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun notifyDone(jobId: String, name: String, success: Boolean) {
        ensureChannel(applicationContext)
        val nm = applicationContext.getSystemService(NotificationManager::class.java) ?: return
        val n = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_convert)
            .setContentTitle(name)
            .setContentText(applicationContext.getString(if (success) R.string.notif_done else R.string.notif_failed))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(jobId))
            .build()
        runCatching { nm.notify(jobId.hashCode(), n) }
    }

    companion object {
        const val KEY_JOB_ID = "job_id"
        const val KEY_STAGE = "stage"
        const val KEY_PAGE = "page"
        const val KEY_TOTAL = "total"
        const val KEY_ERROR = "error"
        const val CHANNEL = "conversion"
        const val NOTIF_PROGRESS = 4201
        const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = context.getSystemService(NotificationManager::class.java) ?: return
                if (nm.getNotificationChannel(CHANNEL) == null) {
                    nm.createNotificationChannel(NotificationChannel(CHANNEL, context.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW))
                }
            }
        }
    }
}
