package com.ayman.pdfword

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.content.IntentCompat
import com.ayman.pdfword.ui.AppNavigation
import com.ayman.pdfword.ui.theme.PdfWordTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableStateFlow

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    /** PDFs opened from other apps, or a job to show from a notification. */
    val incoming = MutableStateFlow<IncomingAction?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent {
            PdfWordTheme {
                AppNavigation(incoming = incoming, onIncomingHandled = { incoming.value = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return
        intent.getStringExtra(EXTRA_OPEN_JOB)?.let { incoming.value = IncomingAction.OpenJob(it); return }
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            else -> null
        }
        if (uri != null) incoming.value = IncomingAction.OpenPdf(uri)
    }

    companion object {
        const val EXTRA_OPEN_JOB = "open_job"
    }
}

sealed interface IncomingAction {
    data class OpenPdf(val uri: Uri) : IncomingAction
    data class OpenJob(val jobId: String) : IncomingAction
}
