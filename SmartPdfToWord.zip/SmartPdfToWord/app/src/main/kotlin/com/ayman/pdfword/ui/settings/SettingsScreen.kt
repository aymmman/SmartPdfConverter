@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.ayman.pdfword.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.ayman.pdfword.BuildConfig
import com.ayman.pdfword.R
import com.ayman.pdfword.core.ConversionMode
import com.ayman.pdfword.data.JobRepository
import com.ayman.pdfword.data.billing.BillingManager
import com.ayman.pdfword.data.settings.AppSettings
import com.ayman.pdfword.data.settings.ImageQuality
import com.ayman.pdfword.data.settings.OcrLanguages
import com.ayman.pdfword.data.settings.OcrMode
import com.ayman.pdfword.data.settings.SettingsRepository
import com.ayman.pdfword.engine.JobFiles
import com.ayman.pdfword.engine.OcrEngine
import com.ayman.pdfword.ui.components.SectionCard
import com.ayman.pdfword.ui.setup.ARABIC_FONTS
import com.ayman.pdfword.ui.setup.FontPicker
import com.ayman.pdfword.ui.setup.LATIN_FONTS
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repo: SettingsRepository,
    private val jobs: JobRepository,
    billing: BillingManager,
) : ViewModel() {
    val settings: StateFlow<AppSettings> = repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val isPro = billing.isPro
    val ocrLanguages: Set<String> = OcrEngine(context).availableLanguages()

    fun update(t: (AppSettings) -> AppSettings) { viewModelScope.launch { repo.update(t) } }

    fun setOutputFolder(uri: Uri?) {
        if (uri != null) runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        update { it.copy(outputTreeUri = uri?.toString() ?: "") }
    }

    fun clearTemp() { JobFiles.clearAll(context) }
    fun clearHistory() { viewModelScope.launch { jobs.clearHistory() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onPro: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val isPro by vm.isPro.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }
    var showLicenses by remember { mutableStateOf(false) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.setOutputFolder(uri) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.settings)) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back)) } },
        )
    }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionCard(title = stringResource(R.string.default_conversion)) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(selected = s.defaultMode == ConversionMode.EDITABLE, onClick = { vm.update { it.copy(defaultMode = ConversionMode.EDITABLE) } }, shape = SegmentedButtonDefaults.itemShape(0, 2)) { Text(stringResource(R.string.mode_editable)) }
                    SegmentedButton(selected = s.defaultMode == ConversionMode.LAYOUT, onClick = { if (isPro) vm.update { it.copy(defaultMode = ConversionMode.LAYOUT) } else onPro() }, shape = SegmentedButtonDefaults.itemShape(1, 2)) { Text(stringResource(R.string.mode_layout)) }
                }
                Text(stringResource(R.string.ocr_title), style = MaterialTheme.typography.labelLarge)
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    val modes = listOf(OcrMode.AUTO to R.string.ocr_auto, OcrMode.ALWAYS to R.string.ocr_always, OcrMode.OFF to R.string.ocr_off)
                    modes.forEachIndexed { i, (m, l) -> SegmentedButton(selected = s.ocrMode == m, onClick = { vm.update { it.copy(ocrMode = m) } }, shape = SegmentedButtonDefaults.itemShape(i, modes.size)) { Text(stringResource(l)) } }
                }
                Text(stringResource(R.string.recognition_languages), style = MaterialTheme.typography.labelLarge)
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    val langs = listOf(OcrLanguages.ARABIC_ENGLISH to R.string.lang_both, OcrLanguages.ARABIC to R.string.lang_ar, OcrLanguages.ENGLISH to R.string.lang_en)
                    langs.forEachIndexed { i, (l, label) -> SegmentedButton(selected = s.ocrLanguages == l, onClick = { vm.update { it.copy(ocrLanguages = l) } }, shape = SegmentedButtonDefaults.itemShape(i, langs.size)) { Text(stringResource(label)) } }
                }
                Text(
                    stringResource(R.string.ocr_models_installed, vm.ocrLanguages.sorted().joinToString(", ").ifEmpty { "—" }),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(stringResource(R.string.images_quality), style = MaterialTheme.typography.labelLarge)
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    val qs = listOf(ImageQuality.HIGH to R.string.quality_high, ImageQuality.BALANCED to R.string.quality_balanced, ImageQuality.SMALL to R.string.quality_small)
                    qs.forEachIndexed { i, (q, l) -> SegmentedButton(selected = s.imageQuality == q, onClick = { vm.update { it.copy(imageQuality = q) } }, shape = SegmentedButtonDefaults.itemShape(i, qs.size)) { Text(stringResource(l)) } }
                }
                ToggleRow(stringResource(R.string.keep_images), s.keepImages) { v -> vm.update { it.copy(keepImages = v) } }
                ToggleRow(stringResource(R.string.detect_headers), s.detectHeadersFooters) { v -> vm.update { it.copy(detectHeadersFooters = v) } }
            }

            SectionCard(title = stringResource(R.string.font_substitution)) {
                FontPicker(stringResource(R.string.latin_font), s.defaultLatinFont, LATIN_FONTS) { f -> vm.update { it.copy(defaultLatinFont = f) } }
                FontPicker(stringResource(R.string.arabic_font), s.defaultArabicFont, ARABIC_FONTS) { f -> vm.update { it.copy(defaultArabicFont = f) } }
                Text(stringResource(R.string.font_rules) + if (isPro) "" else " · PRO", style = MaterialTheme.typography.labelLarge)
                var rules by remember(s.fontRules) { mutableStateOf(s.fontRules) }
                OutlinedTextField(
                    value = rules, onValueChange = { rules = it }, enabled = isPro, minLines = 3,
                    placeholder = { Text("Helvetica=Arial\nAdobeArabic=Simplified Arabic") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row {
                    if (isPro) TextButton(onClick = { vm.update { it.copy(fontRules = rules) } }) { Text(stringResource(R.string.save)) }
                    else TextButton(onClick = onPro) { Text(stringResource(R.string.unlock_pro)) }
                }
            }

            SectionCard(title = stringResource(R.string.output_location)) {
                Text(
                    if (s.outputTreeUri.isBlank()) stringResource(R.string.output_none) else Uri.parse(s.outputTreeUri).lastPathSegment ?: s.outputTreeUri,
                    style = MaterialTheme.typography.bodyMedium,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { folderPicker.launch(null) }) { Text(stringResource(R.string.choose_folder)) }
                    if (s.outputTreeUri.isNotBlank()) TextButton(onClick = { vm.setOutputFolder(null) }) { Text(stringResource(R.string.clear)) }
                }
            }

            SectionCard(title = stringResource(R.string.privacy_title)) {
                Text(stringResource(R.string.privacy_text), style = MaterialTheme.typography.bodyMedium)
                ToggleRow(stringResource(R.string.delete_temp), s.deleteTempImmediately) { v -> vm.update { it.copy(deleteTempImmediately = v) } }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.clearTemp() }) { Text(stringResource(R.string.clear_temp)) }
                    OutlinedButton(onClick = { confirmClear = true }) { Text(stringResource(R.string.clear_history)) }
                }
            }

            SectionCard(title = stringResource(R.string.about)) {
                Text("${stringResource(R.string.app_name)} ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyMedium)
                TextButton(onClick = { showLicenses = true }) { Text(stringResource(R.string.licenses)) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(stringResource(R.string.clear_history)) },
            text = { Text(stringResource(R.string.clear_history_confirm)) },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
    if (showLicenses) {
        AlertDialog(
            onDismissRequest = { showLicenses = false },
            title = { Text(stringResource(R.string.licenses)) },
            text = { Text(LICENSES, style = MaterialTheme.typography.bodySmall) },
            confirmButton = { TextButton(onClick = { showLicenses = false }) { Text(stringResource(R.string.ok)) } },
        )
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private const val LICENSES = """PdfBox-Android (Apache License 2.0) – © Tom Roush, Apache PDFBox contributors
Tesseract OCR & Tesseract4Android (Apache License 2.0) – © Google, adaptech-cz
Tesseract language models tessdata_best/tessdata_fast (Apache License 2.0)
AndroidX, Jetpack Compose, Material 3, Room, WorkManager, DataStore, Hilt (Apache License 2.0) – © Google
Kotlin & kotlinx.coroutines (Apache License 2.0) – © JetBrains
Google Play Billing Library – Android Software Development Kit License

No font files are bundled or redistributed. Fonts are referenced by name in the generated documents."""
