package com.ayman.pdfword.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [ConversionEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun conversions(): ConversionDao
}
