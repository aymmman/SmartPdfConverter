package com.ayman.pdfword.engine

import android.graphics.Path
import android.graphics.PointF
import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.FillRect
import com.ayman.pdfword.core.model.Glyph
import com.ayman.pdfword.core.model.GraphicElement
import com.ayman.pdfword.core.model.GraphicKind
import com.ayman.pdfword.core.model.Segment
import com.ayman.pdfword.core.model.TextStyle
import com.ayman.pdfword.core.text.UnicodeText
import com.tom_roush.pdfbox.contentstream.PDFGraphicsStreamEngine
import com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingColor
import com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingColorN
import com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingColorSpace
import com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingDeviceCMYKColor
import com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingDeviceGrayColor
import com.tom_roush.pdfbox.contentstream.operator.color.SetNonStrokingDeviceRGBColor
import com.tom_roush.pdfbox.contentstream.operator.color.SetStrokingColor
import com.tom_roush.pdfbox.contentstream.operator.color.SetStrokingColorN
import com.tom_roush.pdfbox.contentstream.operator.color.SetStrokingColorSpace
import com.tom_roush.pdfbox.contentstream.operator.color.SetStrokingDeviceCMYKColor
import com.tom_roush.pdfbox.contentstream.operator.color.SetStrokingDeviceGrayColor
import com.tom_roush.pdfbox.contentstream.operator.color.SetStrokingDeviceRGBColor
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImage
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Raw page content in display space (top-left origin, rotation applied, points). */
class RawPage(
    val width: Float,
    val height: Float,
    val glyphs: List<Glyph>,
    val segments: List<Segment>,
    val fills: List<FillRect>,
    val graphics: List<GraphicElement>,
    val imageBoxes: List<Box>,
    val totalChars: Int,
    val meaningfulChars: Int,
    val suspiciousChars: Int,
    val invisibleChars: Int,
    val rotatedDropped: Int,
) {
    val textQuality: Float get() = if (totalChars == 0) 1f else ((meaningfulChars - suspiciousChars).coerceAtLeast(0)).toFloat() / totalChars
}

/** Maps PDF user space to display space for a page's crop box and rotation. */
class PageGeometry(page: PDPage) {
    private val crop = page.cropBox
    private val llx = crop.lowerLeftX
    private val lly = crop.lowerLeftY
    private val w = crop.width
    private val h = crop.height
    val rotation = ((page.rotation % 360) + 360) % 360
    val displayWidth: Float = if (rotation == 90 || rotation == 270) h else w
    val displayHeight: Float = if (rotation == 90 || rotation == 270) w else h

    fun toDisplay(x: Float, y: Float): PointF {
        val ux = x - llx
        val uy = y - lly
        return when (rotation) {
            90 -> PointF(uy, ux)
            180 -> PointF(w - ux, uy)
            270 -> PointF(h - uy, w - ux)
            else -> PointF(ux, h - uy)
        }
    }
}

/**
 * Extracts positioned glyphs with font metadata and colours, plus vector
 * graphics (rulings, fills, curves) and image placements for one page.
 */
class PdfPageExtractor(private val doc: PDDocument) {

    fun interface ImageSink { fun accept(image: PDImage, box: Box) }

    fun extract(pageIndex: Int, imageSink: ImageSink?): RawPage {
        val page = doc.getPage(pageIndex)
        val geo = PageGeometry(page)
        val text = GlyphCollector()
        text.startPage = pageIndex + 1
        text.endPage = pageIndex + 1
        text.sortByPosition = false
        runCatching { text.getText(doc) }
        val gfx = GraphicsCollector(page, geo, imageSink)
        runCatching { gfx.processPage(page) }

        // Keep the dominant text direction; rotated text (e.g. vertical labels) is dropped and reported.
        val dirCounts = text.items.groupingBy { it.dir }.eachCount()
        val mainDir = dirCounts.maxByOrNull { it.value }?.key ?: 0
        val upright = text.items.filter { it.dir == mainDir }
        val rotated = text.items.size - upright.size
        return RawPage(
            width = geo.displayWidth,
            height = geo.displayHeight,
            glyphs = upright.map { it.glyph },
            segments = gfx.segments,
            fills = gfx.fills,
            graphics = gfx.graphics,
            imageBoxes = gfx.imageBoxes,
            totalChars = text.total,
            meaningfulChars = text.meaningful,
            suspiciousChars = text.suspicious,
            invisibleChars = text.invisible,
            rotatedDropped = rotated,
        )
    }

    private class Item(val glyph: Glyph, val dir: Int)

    private class GlyphCollector : PDFTextStripper() {
        val items = ArrayList<Item>()
        var total = 0
        var meaningful = 0
        var suspicious = 0
        var invisible = 0

        init {
            // PDFTextStripper ignores colour operators by default; register them to know text colours.
            addOperator(SetStrokingColorSpace())
            addOperator(SetNonStrokingColorSpace())
            addOperator(SetStrokingColor())
            addOperator(SetNonStrokingColor())
            addOperator(SetStrokingColorN())
            addOperator(SetNonStrokingColorN())
            addOperator(SetStrokingDeviceGrayColor())
            addOperator(SetNonStrokingDeviceGrayColor())
            addOperator(SetStrokingDeviceRGBColor())
            addOperator(SetNonStrokingDeviceRGBColor())
            addOperator(SetStrokingDeviceCMYKColor())
            addOperator(SetNonStrokingDeviceCMYKColor())
        }

        override fun processTextPosition(text: TextPosition) {
            val unicode = text.unicode
            total++
            if (unicode.isNullOrEmpty()) return
            var ok = true
            var sus = false
            var i = 0
            while (i < unicode.length) {
                val cp = unicode.codePointAt(i)
                if (!UnicodeText.isMeaningful(cp)) ok = false
                if (cp in 0x00C0..0x00FF) sus = true
                i += Character.charCount(cp)
            }
            if (ok) meaningful++
            if (sus) suspicious++
            if (unicode.isBlank()) return

            val gs = graphicsState
            val mode = runCatching { gs.textState.renderingMode }.getOrNull()
            if (mode == RenderingMode.NEITHER) invisible++
            val font = text.font
            val rawName = runCatching { font?.name }.getOrNull() ?: ""
            val descriptor = runCatching { font?.fontDescriptor }.getOrNull()
            val weight = descriptor?.fontWeight ?: 0f
            val bold = weight >= 600f || (descriptor?.isForceBold == true) || mode == RenderingMode.FILL_STROKE
            val italic = (descriptor?.isItalic == true) || abs(descriptor?.italicAngle ?: 0f) > 0.5f
            val color = colorOf(runCatching { gs.nonStrokingColor }.getOrNull())
            val size = text.fontSizeInPt.takeIf { it > 0.5f } ?: text.heightDir.coerceAtLeast(1f)
            val x = text.x
            val baseline = text.y
            val width = max(text.width, 0f)
            val box = Box(x, baseline - 0.78f * size, x + width, baseline + 0.22f * size)
            val embedded = runCatching { font?.isEmbedded == true }.getOrDefault(false)
            val style = TextStyle(rawName, size, bold, italic, color, embedded)
            items += Item(Glyph(unicode, box, baseline, style), text.dir.roundToInt())
        }

        // Prevent the stripper from building its own text output.
        override fun writePage() {}
    }

    private class GraphicsCollector(
        page: PDPage,
        private val geo: PageGeometry,
        private val imageSink: ImageSink?,
    ) : PDFGraphicsStreamEngine(page) {
        val segments = ArrayList<Segment>()
        val fills = ArrayList<FillRect>()
        val graphics = ArrayList<GraphicElement>()
        val imageBoxes = ArrayList<Box>()

        private class SubPath(val points: MutableList<PointF> = ArrayList(), var curved: Boolean = false, var isRect: Boolean = false)
        private val path = ArrayList<SubPath>()
        private var current = PointF(0f, 0f)
        private var budget = 40_000

        override fun appendRectangle(p0: PointF, p1: PointF, p2: PointF, p3: PointF) {
            path += SubPath(mutableListOf(PointF(p0.x, p0.y), PointF(p1.x, p1.y), PointF(p2.x, p2.y), PointF(p3.x, p3.y), PointF(p0.x, p0.y)), isRect = true)
            current = PointF(p0.x, p0.y)
        }

        override fun drawImage(pdImage: PDImage) {
            val m = graphicsState.currentTransformationMatrix
            val corners = listOf(0f to 0f, 1f to 0f, 0f to 1f, 1f to 1f).map { (u, v) ->
                val x = m.getValue(0, 0) * u + m.getValue(1, 0) * v + m.getValue(2, 0)
                val y = m.getValue(0, 1) * u + m.getValue(1, 1) * v + m.getValue(2, 1)
                geo.toDisplay(x, y)
            }
            val box = Box(corners.minOf { it.x }, corners.minOf { it.y }, corners.maxOf { it.x }, corners.maxOf { it.y })
            if (box.width < 1f || box.height < 1f) return
            if (pdImage.isStencil) { graphics += GraphicElement(box, GraphicKind.FILL); return }
            imageBoxes += box
            imageSink?.accept(pdImage, box)
        }

        override fun clip(windingRule: Path.FillType) {}

        override fun moveTo(x: Float, y: Float) {
            path += SubPath(mutableListOf(PointF(x, y)))
            current = PointF(x, y)
        }

        override fun lineTo(x: Float, y: Float) {
            if (path.isEmpty()) path += SubPath(mutableListOf(PointF(current.x, current.y)))
            path.last().points += PointF(x, y)
            current = PointF(x, y)
        }

        override fun curveTo(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
            if (path.isEmpty()) path += SubPath(mutableListOf(PointF(current.x, current.y)))
            val sp = path.last()
            sp.curved = true
            sp.points += PointF(x1, y1); sp.points += PointF(x2, y2); sp.points += PointF(x3, y3)
            current = PointF(x3, y3)
        }

        override fun getCurrentPoint(): PointF = current

        override fun closePath() {
            val sp = path.lastOrNull() ?: return
            if (sp.points.isNotEmpty()) sp.points += PointF(sp.points.first().x, sp.points.first().y)
        }

        override fun endPath() { path.clear() }

        override fun strokePath() { emit(stroke = true, fill = false); path.clear() }

        override fun fillPath(windingRule: Path.FillType) { emit(stroke = false, fill = true); path.clear() }

        override fun fillAndStrokePath(windingRule: Path.FillType) { emit(stroke = true, fill = true); path.clear() }

        override fun shadingFill(shadingName: COSName) {}

        private fun emit(stroke: Boolean, fill: Boolean) {
            if (budget <= 0) return
            val strokeColor = if (stroke) colorOf(runCatching { graphicsState.strokingColor }.getOrNull()) else 0
            val fillColor = if (fill) colorOf(runCatching { graphicsState.nonStrokingColor }.getOrNull()) else 0
            for (sp in path) {
                if (sp.points.size < 2) continue
                budget--
                val pts = sp.points.map { geo.toDisplay(it.x, it.y) }
                val box = Box(pts.minOf { it.x }, pts.minOf { it.y }, pts.maxOf { it.x }, pts.maxOf { it.y })
                if (sp.curved) {
                    graphics += GraphicElement(box, GraphicKind.CURVE)
                    continue
                }
                val axisRect = sp.isRect || isAxisRectangle(pts)
                if (fill) {
                    if (axisRect) fills += FillRect(box, fillColor)
                    graphics += GraphicElement(box, GraphicKind.FILL)
                }
                if (stroke) {
                    for (k in 0 until pts.size - 1) {
                        val a = pts[k]; val b = pts[k + 1]
                        if (abs(a.x - b.x) < 0.01f && abs(a.y - b.y) < 0.01f) continue
                        segments += Segment(a.x, a.y, b.x, b.y, 1f, strokeColor)
                    }
                    graphics += GraphicElement(box, if (axisRect) GraphicKind.RECT else GraphicKind.LINE)
                }
            }
        }

        private fun isAxisRectangle(pts: List<PointF>): Boolean {
            if (pts.size !in 4..5) return false
            val xs = pts.map { it.x }; val ys = pts.map { it.y }
            val distinctX = xs.distinctBy { (it * 2).roundToInt() }.size
            val distinctY = ys.distinctBy { (it * 2).roundToInt() }.size
            if (distinctX > 2 || distinctY > 2) return false
            for (k in 0 until pts.size - 1) {
                val a = pts[k]; val b = pts[k + 1]
                if (abs(a.x - b.x) > 0.5f && abs(a.y - b.y) > 0.5f) return false
            }
            return true
        }
    }

    companion object {
        fun colorOf(c: PDColor?): Int {
            if (c == null) return 0
            return try {
                c.toRGB() and 0xFFFFFF
            } catch (e: Exception) {
                0x808080
            }
        }

        @Suppress("unused")
        private fun clamp(v: Float, a: Float, b: Float) = min(max(v, a), b)
    }
}
