@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.ayman.pdfword.ui.result

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.ayman.pdfword.R
import com.ayman.pdfword.data.JobRepository
import com.ayman.pdfword.data.db.ConversionEntity
import com.ayman.pdfword.data.db.JobStatus
import com.ayman.pdfword.data.db.jobStatus
import com.ayman.pdfword.engine.SessionStore
import com.ayman.pdfword.ui.components.IconBubble
import com.ayman.pdfword.ui.components.SectionCard
import com.ayman.pdfword.ui.components.StatTile
import com.ayman.pdfword.ui.components.formatSize
import com.ayman.pdfword.ui.progress.errorText
import com.ayman.pdfword.util.FileActions
import com.ayman.pdfword.work.ConversionWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

@HiltViewModel
class ResultViewModel @Inject constructor(
    savedState: SavedStateHandle,
    jobs: JobRepository,
    private val sessions: SessionStore,
) : ViewModel() {
    val jobId: String = savedState["jobId"] ?: ""
    val entity: StateFlow<ConversionEntity?> = jobs.observe(jobId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val report: StateFlow<ReportUi?> = jobs.observe(jobId).map { ReportUi.parse(it?.reportJson) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val canReview: Boolean get() = sessions.model(jobId) != null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(onBack: () -> Unit, onReview: (String) -> Unit, onRetry: (String) -> Unit, vm: ResultViewModel = hiltViewModel()) {
    val entity by vm.entity.collectAsStateWithLifecycle()
    val report by vm.report.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val e = entity
    val file = e?.outputPath?.let { File(it) }?.takeIf { it.exists() }

    val saveAs = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ConversionWorker.DOCX_MIME)) { uri ->
        if (uri != null && file != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { FileActions.copyTo(context, file, uri) }
            snackbar.showSnackbar(context.getString(if (ok) R.string.saved else R.string.save_failed))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.result_title)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back)) } },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (e == null) return@Column
            if (e.jobStatus != JobStatus.SUCCEEDED) {
                SectionCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Icons.Filled.Warning, MaterialTheme.colorScheme.error, MaterialTheme.colorScheme.errorContainer)
                        Spacer(Modifier.width(12.dp))
                        Text(stringResource(if (e.jobStatus == JobStatus.CANCELLED) R.string.status_cancelled else errorText(e.errorMessage)))
                    }
                    OutlinedButton(onClick = { onRetry(e.id) }) { Text(stringResource(R.string.retry)) }
                }
                return@Column
            }
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Icons.Filled.CheckCircle, MaterialTheme.colorScheme.secondary, MaterialTheme.colorScheme.secondaryContainer)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(file?.name ?: e.sourceName, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(formatSize(e.outputSize ?: 0), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (file == null) Text(stringResource(R.string.output_missing), color = MaterialTheme.colorScheme.error)
                Button(onClick = { file?.let { FileActions.open(context, it) } }, enabled = file != null, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text(stringResource(R.string.open_document))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    FilledTonalButton(onClick = { file?.let { FileActions.share(context, it) } }, enabled = file != null, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.share))
                    }
                    FilledTonalButton(onClick = { saveAs.launch(file?.name ?: "document.docx") }, enabled = file != null, modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.save_as))
                    }
                }
                if (e.exportedUri != null) Text(stringResource(R.string.saved_to_folder), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    if (e.reviewItems > 0 && vm.canReview) {
                        OutlinedButton(onClick = { onReview(e.id) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.review_count, e.reviewItems))
                        }
                    }
                    OutlinedButton(onClick = { onRetry(e.id) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.retry_settings))
                    }
                }
            }
            report?.let { ReportSection(it) }
            Text(stringResource(R.string.disclaimer), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
        }
    }
    LaunchedEffect(Unit) { }
}

@Composable
private fun ReportSection(r: ReportUi) {
    SectionCard(title = stringResource(R.string.report_title)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            StatTile("${r.pagesProcessed}/${r.totalPages}", stringResource(R.string.report_pages), Modifier.weight(1f))
            StatTile("${r.tables}", stringResource(R.string.report_tables), Modifier.weight(1f))
            StatTile("${r.images + r.figures}", stringResource(R.string.report_images), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            StatTile("${r.ocrPages.size}", stringResource(R.string.report_ocr_pages), Modifier.weight(1f), MaterialTheme.colorScheme.tertiary)
            StatTile(r.ocrConfidence?.let { "${it.toInt()}%" } ?: "—", stringResource(R.string.report_ocr_conf), Modifier.weight(1f), MaterialTheme.colorScheme.tertiary)
            StatTile(r.textQuality?.let { "${(it * 100).toInt()}%" } ?: "—", stringResource(R.string.report_text_quality), Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
        }
        if (r.borderlessTables > 0) Bullet(stringResource(R.string.report_borderless, r.borderlessTables))
        if (r.figures > 0) Bullet(stringResource(R.string.report_figures, r.figures))
        if (r.pagesFailed.isNotEmpty()) Bullet(stringResource(R.string.report_failed_pages, r.pagesFailed.joinToString(", ")), error = true)
    }
    SectionCard(title = stringResource(R.string.report_fonts)) {
        if (r.fontsPreserved.isEmpty() && r.fontsUnverified.isEmpty() && r.fontsSubstituted.isEmpty()) Text(stringResource(R.string.none))
        if (r.fontsPreserved.isNotEmpty()) {
            Text(stringResource(R.string.fonts_preserved), style = MaterialTheme.typography.labelLarge)
            r.fontsPreserved.distinctBy { it.second }.forEach { Bullet(it.second) }
        }
        if (r.fontsUnverified.isNotEmpty()) {
            Text(stringResource(R.string.fonts_unverified), style = MaterialTheme.typography.labelLarge)
            r.fontsUnverified.distinctBy { it.second }.forEach { Bullet(it.second) }
        }
        if (r.fontsSubstituted.isNotEmpty()) {
            Text(stringResource(R.string.fonts_substituted), style = MaterialTheme.typography.labelLarge)
            r.fontsSubstituted.distinctBy { it.first }.forEach { Bullet("${it.first.ifBlank { "OCR" }} → ${it.second}") }
        }
    }
    val reviewList = r.reviewItems + r.uncertain.map { stringResource(R.string.page_reason, it.first, it.second) }
    if (reviewList.isNotEmpty() || r.ocrWarnings.isNotEmpty() || r.warnings.isNotEmpty()) {
        SectionCard(title = stringResource(R.string.report_review)) {
            (r.ocrWarnings + reviewList).take(40).forEach { Bullet(it) }
            if (r.warnings.isNotEmpty()) {
                HorizontalDivider()
                r.warnings.take(20).forEach { Bullet(it) }
            }
        }
    }
}

@Composable
private fun Bullet(text: String, error: Boolean = false) {
    Row {
        Text("•  ", color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        Text(text, style = MaterialTheme.typography.bodyMedium, color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
    }
}
