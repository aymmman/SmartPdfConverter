# Test report

This report separates what was **measured** from what was **not yet verified**, as the brief requires.

## 1. What was measured (conversion engine, `core/`)

The engine (layout analysis, bidi, tables, OCR post-processing, DOCX writer) is pure Kotlin. It was compiled
with the Kotlin compiler and run against real PDFs produced by LibreOffice and ReportLab. Glyph and vector
data were extracted with pdfplumber in the same form the Android PdfBox extractor supplies (display-space
glyph boxes, baselines, fonts, colours, rulings, fills, curves, images). The generated DOCX files were then
validated (zip + XML parse), compared word-by-word with the source text, and rendered with LibreOffice for
side-by-side visual comparison (`docs/test-report/*.png`: original left, converted right).

| Fixture | Content | Word-sequence match | Char match | Tables | Notes |
|---|---|---|---|---|---|
| english.pdf (2 pp) | headings, justified text, bold/italic/colour runs, bullets, numbered list, ruled table with **row-span + col-span + shaded header**, borderless table, header + page-number footer | **100 %** | 100 % | 2/2 (merged cells exact) | Header/footer rebuilt as Word header/footer with a live `PAGE` field |
| arabic.pdf (RTL) | Arabic paragraphs with Latin terms (KoboToolbox, Power BI, FGD), numbers, %, parentheses, bullets, RTL ruled table with merged cell | 95.0 % | 98.0 % | 1/1 (`bidiVisual`, merged cell exact) | Difference = header/footer lines kept in the body (one-page doc, nothing to repeat). Two diacritics whose glyphs had broken Unicode in the PDF are dropped. |
| columns.pdf | title + two-column newsletter | **100 %** | 100 % | – | Exported as a 2-column Word section |
| invoice.pdf | logo, bilingual title, 2-col address block, **borderless 5-column invoice table with tight columns and a wrapped cell**, totals | text complete | – | 2/2 | All 5 columns recovered |
| logframe.pdf (landscape RTL) | borderless logframe with shaded header cells, multi-line cells | text complete | – | 1/1 | Data rows exact; merged header row is approximated |
| chart.pdf | vector bar chart + pie chart with labels | text complete | – | – | Both charts detected and rasterised as images (labels included) |
| engocr (english.pdf rasterised at 200 dpi → Tesseract `eng`) | scanned version of english.pdf | **99.5 %** | 100 % | 2/2 incl. merged cells | Table rulings detected from the bitmap; mean OCR confidence 95 % |

Unit tests (`./gradlew :core:test`, 9 tests, all passing) cover: Arabic visual→logical recovery, mixed
Arabic/Latin/number ordering, bracket mirroring, presentation-form normalisation, font mapping, merged-cell
grid detection, a full page → DOCX round trip (well-formed XML parts, `w:bidi`, `w:bidiVisual`, Arabic never
stored reversed), OCR baseline normalisation and raster ruling detection.

Acceptance checks covered by the above:
1. Generated DOCX files pass structural validation (zip entries + every XML part parsed). ✓
2. Arabic text is never manually reversed (checked in tests: no reversed string in `document.xml`). ✓
3. Extracted text compared against known source text (table above). ✓
4. OCR accuracy measured for English (99.5 % word match). Arabic OCR: see §2.
5. Fonts: each conversion reports preserved / kept-by-name / substituted fonts. ✓
6. Layout fidelity: visual comparisons in `docs/test-report/`. ✓
7. Failed pages are never silent: they get a visible placeholder paragraph and are listed in the report. ✓
10. No test assumes perfect reconstruction (similarity thresholds, not equality, except where exact). ✓

## 2. Not yet verified — please check on the first CI build / device

| Item | Why it could not be verified here | How it is covered |
|---|---|---|
| Android build (AGP 9.4, Kotlin 2.4.20, Compose BOM 2026.09) | The build machine used for development has no access to Google's Maven repository | GitHub Actions builds it; versions were checked against current release notes |
| Arabic OCR accuracy | `ara.traineddata` could not be downloaded in the development environment | Downloaded by the workflow; same code path as the English OCR test |
| PdfBox-Android extractor + PDFium rendering on device | Requires an Android runtime | Mirrors the pdfplumber extraction used in the engine tests |
| Memory on low-RAM devices / 500+ page PDFs | Requires devices | Page-by-page processing, temp-file-backed PDF parsing, capped bitmaps (16 MP), OOM retry at lower resolution, sequential job queue |
| Microsoft Word rendering | Only LibreOffice was available | OOXML follows Word's transitional conventions (`jc`/`ind` logical in bidi paragraphs, `bidiVisual` tables) |
| Play Billing purchase flow | Needs a Play Console app and product `pro_subscription` | Debug builds unlock Pro for testing |

## 3. Known limitations

- PDFs do not store document structure; the DOCX is a reconstruction. Complex magazine-style layouts,
  three or more text columns, rotated text and text on curves are simplified (rotated text is reported).
- Borderless tables are inferred from whitespace alignment; spanning header cells of borderless tables are
  approximated and flagged in the report for review.
- Fonts are written by name. If the original font is not installed where the DOCX is opened, Word substitutes it.
  Fonts cannot be identified from appearance for scanned pages; OCR text uses the configured fonts and is marked *estimated*.
- OCR does not detect bold/italic. Page orientation is taken from the PDF; skewed scans are not de-skewed.
- Vector charts become images (not editable Word charts).
- Tables split across pages are converted as separate tables.
- The brief asked for ads in the free tier; no ad SDK is included (no ad account was provided). The free/Pro
  split is enforced by page limits and Pro-only features instead.
