# Smart PDF to Word — Android

Native Android app (Kotlin, Jetpack Compose, Material 3) that converts PDFs into **editable Word (.docx)** documents on-device, with first-class **Arabic (RTL)** and English support, real **editable tables** (ruled, merged-cell and borderless), OCR for scanned pages, and an honest conversion report.

> **بالعربي باختصار:** ارفع محتويات هذا المجلد إلى مستودع GitHub جديد، وسيقوم ملف `.github/workflows/build.yml` تلقائياً بتنزيل نماذج OCR للعربية والإنجليزية وتشغيل الاختبارات وبناء ملف APK. حمّل الـ APK من تبويب **Actions › آخر تشغيل › Artifacts › SmartPdfToWord-debug-apk**.

## Build with GitHub Actions (no computer needed)

1. Create a new repository and upload **all** files from this folder, including the hidden `.github` folder.
2. Every push runs **Build Android APK**: it downloads the Tesseract models, runs the engine unit tests (`:core:test`), and builds the debug APK.
3. Open **Actions → latest run → Artifacts → `SmartPdfToWord-debug-apk`**, unzip, install the APK.

Debug builds unlock all Pro features so you can test everything from a side-loaded APK (purchases only work for apps installed from Google Play).

### Signed release (Play Store)

Add these repository secrets and the workflow also produces a signed `.apk` and `.aab`:

| Secret | Value |
|---|---|
| `SIGNING_KEYSTORE_BASE64` | your `.jks` file, base64-encoded (`base64 -w0 release.jks`) |
| `SIGNING_STORE_PASSWORD` | keystore password |
| `SIGNING_KEY_ALIAS` | key alias |
| `SIGNING_KEY_PASSWORD` | key password |

Locally, put the same values in `keystore.properties` (`storeFile=…`, `storePassword=…`, `keyAlias=…`, `keyPassword=…`) and run `./gradlew :app:bundleRelease`.

**Google Play Console:** create a subscription with product id **`pro_subscription`** (one base plan is enough).

## Build locally (Android Studio)

- Android Studio with AGP 9.4 support, JDK 17+ (JDK 21 recommended), Android SDK 37.
- Download the OCR models once (the workflow does this automatically):
  ```bash
  mkdir -p app/src/main/assets/tessdata
  curl -L -o app/src/main/assets/tessdata/ara.traineddata https://github.com/tesseract-ocr/tessdata_best/raw/main/ara.traineddata
  curl -L -o app/src/main/assets/tessdata/eng.traineddata https://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata
  ```
- `./gradlew :core:test :app:assembleDebug` → `app/build/outputs/apk/debug/`.
  Without the models the app still works; scanned pages are kept as images and the report says so.

## Toolchain

| Component | Version |
|---|---|
| Android Gradle Plugin | 9.4.0 (built-in Kotlin) |
| Gradle | 9.6.0 |
| Kotlin / Compose compiler plugin | 2.4.20 |
| KSP | 2.3.11 |
| Compose BOM | 2026.09.00 (Material 3) |
| Hilt (Dagger) / AndroidX Hilt | 2.60.1 / 1.4.0 |
| Room / WorkManager / DataStore | 2.8.5 / 2.12.0 / 1.3.0 |
| Navigation / Lifecycle / Activity | 2.10.2 / 2.11.0 / 1.13.0 |
| Play Billing | 8.0.0 |
| PdfBox-Android | 2.0.27.0 |
| Tesseract4Android (Tesseract 5) | 4.8.0 |
| compileSdk / targetSdk / minSdk | 37 / 37 / 26 |

## Architecture

```
core/   Pure-Kotlin conversion engine (no Android deps, unit-tested on the JVM)
  text/      Unicode classes, presentation-form normalisation, visual→logical bidi recovery
  layout/    line grouping, columns, paragraphs, headings, lists, figures, page assembly
  table/     ruling-line tables (merged cells, shading) + borderless/“booktabs” tables
  font/      PDF font name → Word family mapping, substitution rules, honest status
  ocr/       OCR word normalisation (baselines, sizes, bullet repair)
  raster/    Otsu binarisation + ruling detection for scanned tables
  docx/      streaming OOXML writer (bidi, tables, numbering, headers/footers, images)
  report/    conversion quality report
app/    Android app (Clean Architecture + MVVM)
  engine/    PdfBox-Android extraction, PDFium/PDFBox rasterisation, Tesseract OCR, pipeline
  work/      WorkManager foreground worker (survives backgrounding, cancellable)
  data/      Room history, DataStore settings, Play Billing, job repository
  ui/        Compose screens: Home, Setup, Progress, Result + report, OCR review, Settings, Pro
```

### How a page is converted

1. **Inspect** – PdfBox-Android extracts every glyph with Unicode, font name, size, weight/italic, colour, render mode and exact position; a graphics engine collects lines, rectangles, fills, curves and image placements. Pages are classified *text / scanned / hybrid / empty*; text-layer quality (unmapped glyphs, mojibake) is measured.
2. **OCR when needed** – scanned pages (or unreadable text layers) are rendered with PDFium at 300 dpi (400 dpi Pro) and recognised by Tesseract (`ara+eng`). Table rulings are detected from the bitmap.
3. **Reading order** – glyph positions in a PDF are always *visual*. Lines are rebuilt from baselines, and Arabic/English order is recovered with a Unicode-bidi-based visual→logical algorithm (numbers, Latin terms, brackets handled). Arabic is never stored reversed.
4. **Tables** – ruling lines are merged into grids; missing inner lines become merged cells (`gridSpan`/`vMerge`); cell shading and per-cell borders are kept. Tables without lines are found from whitespace corridors through consecutive lines; horizontal-rule tables keep their rules.
5. **Structure** – columns, paragraphs (alignment, indents, spacing), headings (ranked by size across the document), bulleted/numbered lists, headers/footers (page numbers become `PAGE` fields), images and charts (vector charts are rasterised as images).
6. **Write DOCX** – valid OOXML with `w:bidi`, `w:rtl`, complex-script fonts and sizes, `bidiVisual` RTL tables; written to a temporary file and only moved into place after validation.

### Modes
- **Editable Word** – flowing paragraphs, headings, lists and tables.
- **Layout preservation (Pro)** – every line positioned at its exact location (frames, floating tables, anchored images). Looks closest to the PDF; less convenient to edit.

## Privacy & security

Documents are processed on the device only; nothing is uploaded and no analytics are collected. Inputs are copied to private cache, validated (`%PDF-` header), and never modified. Passwords stay in memory only. Temporary files are cleaned automatically (optionally right after each conversion). Backups exclude all app data. No broad storage permissions are requested — files are accessed through the Storage Access Framework.

## Free vs Pro

| | Free | Pro |
|---|---|---|
| Editable Word conversion, tables, Arabic/English, OCR, report | ✓ (≤ 50 pages/document) | ✓ (≤ 2,000 pages) |
| Layout-preservation mode | | ✓ |
| Batch conversion | | ✓ |
| High-accuracy OCR (400 dpi) | | ✓ |
| Custom font substitution rules | | ✓ |

The app contains **no ads** (the ad slot required by the brief was intentionally not added; see TEST_REPORT.md).

See `TEST_REPORT.md` for measured accuracy and known limitations, and `LICENSES.md` for the library/font licence inventory.
