package com.ayman.pdfword.core.model

import kotlin.math.max
import kotlin.math.min

/**
 * Axis-aligned box in page display space: origin at the top-left corner of the
 * (rotation-adjusted) page, x grows right, y grows down, units are PDF points.
 */
data class Box(val x0: Float, val top: Float, val x1: Float, val bottom: Float) {
    val width: Float get() = x1 - x0
    val height: Float get() = bottom - top
    val cx: Float get() = (x0 + x1) / 2f
    val cy: Float get() = (top + bottom) / 2f
    val area: Float get() = max(0f, width) * max(0f, height)

    fun union(o: Box) = Box(min(x0, o.x0), min(top, o.top), max(x1, o.x1), max(bottom, o.bottom))

    fun overlapX(o: Box): Float = max(0f, min(x1, o.x1) - max(x0, o.x0))
    fun overlapY(o: Box): Float = max(0f, min(bottom, o.bottom) - max(top, o.top))
    fun intersectionArea(o: Box): Float = overlapX(o) * overlapY(o)

    fun contains(x: Float, y: Float, tol: Float = 0f) =
        x >= x0 - tol && x <= x1 + tol && y >= top - tol && y <= bottom + tol

    fun containsBox(o: Box, tol: Float = 0f) =
        o.x0 >= x0 - tol && o.x1 <= x1 + tol && o.top >= top - tol && o.bottom <= bottom + tol

    fun expand(d: Float) = Box(x0 - d, top - d, x1 + d, bottom + d)

    companion object {
        fun of(boxes: Collection<Box>): Box? {
            if (boxes.isEmpty()) return null
            var r = boxes.first()
            for (b in boxes) r = r.union(b)
            return r
        }
    }
}

fun List<Float>.medianOr(default: Float): Float {
    if (isEmpty()) return default
    val s = sorted()
    return s[s.size / 2]
}
