package com.ayman.pdfword.core.doc

import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.ImageInput

/** A run of text with uniform formatting, in logical order. */
data class Run(
    val text: String,
    val latinFont: String,
    val csFont: String,
    val sizePt: Float,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val rtl: Boolean,
    val underline: Boolean = false,
    val highlight: Int? = null,
    val vertAlign: Int = 0,
    /** Special field instead of text (e.g. "PAGE"). */
    val field: String? = null,
)

enum class Align { START, END, CENTER, JUSTIFY }

data class ListRef(val numId: Int, val level: Int)

data class ParaProps(
    val rtl: Boolean,
    val align: Align = Align.START,
    val indStartPt: Float = 0f,
    val indEndPt: Float = 0f,
    /** Positive = first-line indent, negative = hanging. */
    val firstLinePt: Float = 0f,
    val spaceBeforePt: Float = 0f,
    val spaceAfterPt: Float = 0f,
    /** Line spacing multiple (1.0 = single). */
    val lineMultiple: Float = 1f,
    val headingLevel: Int = 0,
    val list: ListRef? = null,
    val keepNext: Boolean = false,
    /** Empty paragraph that only carries vertical space (rendered ~1pt high). */
    val spacer: Boolean = false,
)

/** Absolute placement for layout-preservation mode. */
data class Placement(val box: Box)

sealed interface Block {
    val id: String
    val top: Float
}

data class ParagraphBlock(
    override val id: String,
    val runs: List<Run>,
    val props: ParaProps,
    override val top: Float,
    val box: Box? = null,
    val frame: Placement? = null,
    /** Lowest OCR confidence of the words in this paragraph (null = text layer). */
    val confidence: Float? = null,
    val needsReview: Boolean = false,
    /** Margin candidate key for header/footer detection. */
    val marginalKey: String? = null,
    val marginalTop: Boolean = false,
    /** Dominant font size, used to rank heading levels across the document. */
    val fontSize: Float = 0f,
) : Block {
    val text: String get() = runs.joinToString("") { it.text }
}

data class CellBorders(val top: Boolean, val bottom: Boolean, val start: Boolean, val end: Boolean)

data class TableCell(
    val row: Int,
    val col: Int,
    val rowSpan: Int,
    val colSpan: Int,
    val paragraphs: List<ParagraphBlock>,
    val shading: Int? = null,
    val borders: CellBorders = CellBorders(true, true, true, true),
    val vAlignCenter: Boolean = false,
)

data class TableBlock(
    override val id: String,
    override val top: Float,
    val box: Box,
    /** Column widths in points, in *visual* left-to-right order. */
    val colWidths: List<Float>,
    val rowHeights: List<Float>,
    /** Cells with visual column indices. */
    val cells: List<TableCell>,
    val rtl: Boolean,
    val bordered: Boolean,
    val borderColor: Int = 0,
    val indentPt: Float = 0f,
    val floating: Boolean = false,
    val detection: String = "ruling",
    /** Left/right cell padding in points. */
    val cellMarginPt: Float = 5.4f,
) : Block

data class ImageBlock(
    override val id: String,
    override val top: Float,
    val image: ImageInput,
    val anchored: Boolean,
    val behindText: Boolean,
    val align: Align = Align.CENTER,
) : Block

/** Column break inside a multi-column section. */
data class ColumnBreakBlock(override val id: String, override val top: Float) : Block

data class Margins(val top: Float, val bottom: Float, val left: Float, val right: Float)

data class SectionPart(val columns: Int, val rtl: Boolean, val blocks: List<Block>, val columnGapPt: Float = 36f)

data class PageLayout(
    val pageIndex: Int,
    val widthPt: Float,
    val heightPt: Float,
    val margins: Margins,
    val parts: List<SectionPart>,
    val rtlDominant: Boolean,
)

data class NumberingDef(val numId: Int, val bullet: Boolean, val format: String, val suffix: String, val start: Int, val rtl: Boolean)

data class DocModel(
    val pages: List<PageLayout>,
    val header: List<ParagraphBlock>,
    val footer: List<ParagraphBlock>,
    val numbering: List<NumberingDef>,
    val defaultLatinFont: String,
    val defaultCsFont: String,
    val title: String,
    val rtlDominant: Boolean,
)
