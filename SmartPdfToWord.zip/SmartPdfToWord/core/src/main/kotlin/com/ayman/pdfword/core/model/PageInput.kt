package com.ayman.pdfword.core.model

/** Visual style of a glyph as recovered from the PDF (or estimated by OCR). */
data class TextStyle(
    /** Raw font name as stored in the PDF, e.g. "ABCDEF+Arial-BoldMT". Empty for OCR. */
    val fontName: String,
    val size: Float,
    val bold: Boolean,
    val italic: Boolean,
    /** 0xRRGGBB */
    val color: Int,
    val embedded: Boolean,
    /** True when style was estimated (OCR) rather than read from the file. */
    val estimated: Boolean = false,
)

/**
 * One positioned piece of text. For text-layer PDFs this is normally one glyph
 * (or a ligature such as "fi"). For OCR it is one recognised word whose [text]
 * is already in logical order ([isWord] = true).
 */
class Glyph(
    val text: String,
    val box: Box,
    /** Baseline y in display space (for OCR: bottom of the word box). */
    val baseline: Float,
    val style: TextStyle,
    val isWord: Boolean = false,
    /** OCR confidence 0..100; 100 for text-layer glyphs. */
    val confidence: Float = 100f,
) {
    var underline: Boolean = false
    var highlight: Int? = null
    /** 0 = baseline, 1 = superscript, -1 = subscript */
    var vertAlign: Int = 0
    var fakeBold: Boolean = false
}

/** A straight stroked line (or a very thin filled rectangle), display space. */
data class Segment(val x0: Float, val y0: Float, val x1: Float, val y1: Float, val thickness: Float = 1f, val color: Int = 0) {
    val isHorizontal: Boolean get() = kotlin.math.abs(y1 - y0) <= 1.5f && kotlin.math.abs(x1 - x0) > 1.5f
    val isVertical: Boolean get() = kotlin.math.abs(x1 - x0) <= 1.5f && kotlin.math.abs(y1 - y0) > 1.5f
    val length: Float get() = kotlin.math.hypot(x1 - x0, y1 - y0)
    val box: Box get() = Box(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1))
}

/** A filled, non-thin rectangle (cell shading, highlight, coloured band). */
data class FillRect(val box: Box, val color: Int)

enum class GraphicKind { LINE, RECT, CURVE, FILL }

/** Any vector drawing operation; used to find charts/diagrams to rasterise. */
data class GraphicElement(val box: Box, val kind: GraphicKind)

data class ImageInput(
    val box: Box,
    /** Absolute path of an already-encoded PNG/JPEG on disk. */
    val filePath: String,
    val mime: String,
    val pixelWidth: Int,
    val pixelHeight: Int,
    /** True if produced by rasterising a vector figure region. */
    val fromVectorFigure: Boolean = false,
)

enum class PageKind { TEXT, SCANNED, HYBRID, EMPTY }

class PageInput(
    val index: Int,
    val width: Float,
    val height: Float,
    val glyphs: List<Glyph>,
    val segments: List<Segment> = emptyList(),
    val fills: List<FillRect> = emptyList(),
    val graphics: List<GraphicElement> = emptyList(),
    val images: List<ImageInput> = emptyList(),
    val kind: PageKind = PageKind.TEXT,
    val ocrApplied: Boolean = false,
    val ocrMeanConfidence: Float? = null,
    /** Fraction of text-layer characters that decoded to meaningful Unicode. */
    val textQuality: Float = 1f,
    val rotatedGlyphsDropped: Int = 0,
    val invisibleTextLayer: Boolean = false,
    val warnings: List<String> = emptyList(),
)
