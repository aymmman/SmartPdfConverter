package com.ayman.pdfword.core.table

import com.ayman.pdfword.core.doc.CellBorders
import com.ayman.pdfword.core.layout.LineGrouper
import com.ayman.pdfword.core.layout.TextLine
import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.FillRect
import com.ayman.pdfword.core.model.Glyph
import com.ayman.pdfword.core.model.Segment
import com.ayman.pdfword.core.text.UnicodeText
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class DetectedCell(
    val r: Int, val c: Int, val rs: Int, val cs: Int,
    val box: Box, val borders: CellBorders, val shading: Int?,
) {
    val glyphs = ArrayList<Glyph>()
    /** For alignment tables: pre-built lines. */
    val lines = ArrayList<TextLine>()
}

class DetectedTable(
    val box: Box,
    val xs: List<Float>,
    val ys: List<Float>,
    val cells: List<DetectedCell>,
    val bordered: Boolean,
    val borderColor: Int,
    val detection: String,
) {
    val rows get() = ys.size - 1
    val cols get() = xs.size - 1

    fun cellAt(x: Float, y: Float): DetectedCell? {
        if (!box.contains(x, y, 1.5f)) return null
        val c = (xs.indexOfLast { it <= x }).coerceIn(0, cols - 1)
        val r = (ys.indexOfLast { it <= y }).coerceIn(0, rows - 1)
        return cells.firstOrNull { r >= it.r && r < it.r + it.rs && c >= it.c && c < it.c + it.cs }
    }
}

/** Horizontal-rule-only region ("booktabs" style tables), used by the alignment detector. */
data class RuleRegion(val box: Box, val ruleYs: List<Float>)

private class HLine(var y: Float, var x0: Float, var x1: Float, val color: Int)
private class VLine(var x: Float, var y0: Float, var y1: Float, val color: Int)

object RulingTableDetector {

    data class Result(val tables: List<DetectedTable>, val ruleRegions: List<RuleRegion>, val usedSegmentBoxes: List<Box>)

    fun detect(segments: List<Segment>, fills: List<FillRect>, pageW: Float, pageH: Float): Result {
        val hs = ArrayList<HLine>()
        val vs = ArrayList<VLine>()
        for (s in segments) {
            if (s.isHorizontal && s.length >= 3f) hs += HLine((s.y0 + s.y1) / 2, min(s.x0, s.x1), max(s.x0, s.x1), s.color)
            else if (s.isVertical && s.length >= 3f) vs += VLine((s.x0 + s.x1) / 2, min(s.y0, s.y1), max(s.y0, s.y1), s.color)
        }
        for (f in fills) {
            val b = f.box
            if (b.height <= 2.5f && b.width >= 3f) hs += HLine(b.cy, b.x0, b.x1, f.color)
            else if (b.width <= 2.5f && b.height >= 3f) vs += VLine(b.cx, b.top, b.bottom, f.color)
        }
        if (hs.isEmpty()) return Result(emptyList(), emptyList(), emptyList())
        val H = mergeH(hs)
        val V = mergeV(vs)

        // Union-find clusters of intersecting lines.
        val n = H.size + V.size
        val parent = IntArray(n) { it }
        fun find(a: Int): Int { var x = a; while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x] }; return x }
        fun union(a: Int, b: Int) { parent[find(a)] = find(b) }
        val tol = 3f
        for ((i, h) in H.withIndex()) for ((j, v) in V.withIndex()) {
            if (v.x >= h.x0 - tol && v.x <= h.x1 + tol && h.y >= v.y0 - tol && h.y <= v.y1 + tol) union(i, H.size + j)
        }
        val groups = HashMap<Int, Pair<MutableList<HLine>, MutableList<VLine>>>()
        for (i in H.indices) groups.getOrPut(find(i)) { mutableListOf<HLine>() to mutableListOf() }.first += H[i]
        for (j in V.indices) groups.getOrPut(find(H.size + j)) { mutableListOf<HLine>() to mutableListOf() }.second += V[j]

        val tables = ArrayList<DetectedTable>()
        val ruleRegions = ArrayList<RuleRegion>()
        val used = ArrayList<Box>()
        for ((gh, gv) in groups.values) {
            if (gh.size >= 2 && gv.size >= 2) {
                buildGrid(gh, gv, fills, pageW, pageH)?.let { tables += it; used += it.box }
            } else if (gh.size == 0 && gv.isEmpty()) continue
        }
        // Horizontal-rule regions: >=3 stacked rules of similar extent not part of a table.
        val loose = H.filter { h -> tables.none { it.box.expand(2f).contains((h.x0 + h.x1) / 2, h.y) } && (h.x1 - h.x0) > 60f }
            .sortedBy { it.y }
        val consumed = HashSet<HLine>()
        for (h in loose) {
            if (h in consumed) continue
            val similar = loose.filter { o -> o !in consumed && abs(o.x0 - h.x0) < 8f && abs(o.x1 - h.x1) < 8f }
            if (similar.size >= 2) {
                val ys = similar.map { it.y }.sorted()
                if (ys.last() - ys.first() > 20f && ys.last() - ys.first() < pageH * 0.9f) {
                    ruleRegions += RuleRegion(Box(h.x0, ys.first(), h.x1, ys.last()), ys)
                    consumed += similar
                }
            }
        }
        return Result(tables.sortedBy { it.box.top }, ruleRegions, used)
    }

    private fun mergeH(src: List<HLine>): List<HLine> {
        val s = src.sortedWith(compareBy({ it.y }, { it.x0 }))
        val out = ArrayList<HLine>()
        for (h in s) {
            val m = out.lastOrNull { abs(it.y - h.y) < 1.6f && h.x0 <= it.x1 + 2f && h.x1 >= it.x0 - 2f }
            if (m != null) { m.x0 = min(m.x0, h.x0); m.x1 = max(m.x1, h.x1); m.y = (m.y + h.y) / 2 } else out += HLine(h.y, h.x0, h.x1, h.color)
        }
        // Second pass to catch merges enabled by growth.
        return if (out.size < s.size) mergeHOnce(out) else out
    }

    private fun mergeHOnce(src: List<HLine>): List<HLine> {
        val out = ArrayList<HLine>()
        for (h in src.sortedWith(compareBy({ it.y }, { it.x0 }))) {
            val m = out.firstOrNull { abs(it.y - h.y) < 1.6f && h.x0 <= it.x1 + 2f && h.x1 >= it.x0 - 2f }
            if (m != null) { m.x0 = min(m.x0, h.x0); m.x1 = max(m.x1, h.x1) } else out += h
        }
        return out
    }

    private fun mergeV(src: List<VLine>): List<VLine> {
        val s = src.sortedWith(compareBy({ it.x }, { it.y0 }))
        val out = ArrayList<VLine>()
        for (v in s) {
            val m = out.firstOrNull { abs(it.x - v.x) < 1.6f && v.y0 <= it.y1 + 2f && v.y1 >= it.y0 - 2f }
            if (m != null) { m.y0 = min(m.y0, v.y0); m.y1 = max(m.y1, v.y1); m.x = (m.x + v.x) / 2 } else out += VLine(v.x, v.y0, v.y1, v.color)
        }
        return out
    }

    private fun snap(values: List<Float>, tol: Float): List<Float> {
        val s = values.sorted()
        val out = ArrayList<Float>()
        var acc = ArrayList<Float>()
        for (v in s) {
            if (acc.isNotEmpty() && v - acc.last() > tol) { out += acc.average().toFloat(); acc = ArrayList() }
            acc += v
        }
        if (acc.isNotEmpty()) out += acc.average().toFloat()
        return out
    }

    private fun buildGrid(H: List<HLine>, V: List<VLine>, fills: List<FillRect>, pageW: Float, pageH: Float): DetectedTable? {
        val xs = snap(V.map { it.x } + H.map { it.x0 } + H.map { it.x1 }, 3f)
        val ys = snap(H.map { it.y } + V.map { it.y0 } + V.map { it.y1 }, 3f)
        if (xs.size < 2 || ys.size < 2) return null
        val box = Box(xs.first(), ys.first(), xs.last(), ys.last())
        if (box.width < 20f || box.height < 8f) return null
        val rows = ys.size - 1
        val cols = xs.size - 1
        if (rows * cols > 5000) return null
        if (rows == 1 && cols == 1 && box.area > 0.8f * pageW * pageH) return null // page frame

        fun vCover(x: Float, ya: Float, yb: Float): Float {
            var cov = 0f
            for (v in V) if (abs(v.x - x) < 3f) cov += max(0f, min(v.y1, yb) - max(v.y0, ya))
            return cov / max(yb - ya, 0.1f)
        }
        fun hCover(y: Float, xa: Float, xb: Float): Float {
            var cov = 0f
            for (h in H) if (abs(h.y - y) < 3f) cov += max(0f, min(h.x1, xb) - max(h.x0, xa))
            return cov / max(xb - xa, 0.1f)
        }
        val parent = IntArray(rows * cols) { it }
        fun find(a: Int): Int { var x = a; while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x] }; return x }
        fun union(a: Int, b: Int) { parent[find(a)] = find(b) }
        for (r in 0 until rows) for (c in 0 until cols - 1) {
            if (vCover(xs[c + 1], ys[r], ys[r + 1]) < 0.55f) union(r * cols + c, r * cols + c + 1)
        }
        for (r in 0 until rows - 1) for (c in 0 until cols) {
            if (hCover(ys[r + 1], xs[c], xs[c + 1]) < 0.55f) union(r * cols + c, (r + 1) * cols + c)
        }
        val groups = HashMap<Int, MutableList<Int>>()
        for (i in 0 until rows * cols) groups.getOrPut(find(i)) { mutableListOf() } += i
        val cells = ArrayList<DetectedCell>()
        for (members in groups.values) {
            val rs = members.map { it / cols }
            val cs = members.map { it % cols }
            val r0 = rs.min(); val r1 = rs.max(); val c0 = cs.min(); val c1 = cs.max()
            if ((r1 - r0 + 1) * (c1 - c0 + 1) == members.size) {
                cells += makeCell(r0, c0, r1 - r0 + 1, c1 - c0 + 1, xs, ys, ::vCover, ::hCover, fills)
            } else {
                // Non-rectangular merge region: fall back to individual cells.
                for (m in members) cells += makeCell(m / cols, m % cols, 1, 1, xs, ys, ::vCover, ::hCover, fills)
            }
        }
        val color = (H.map { it.color } + V.map { it.color }).groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: 0
        return DetectedTable(box, xs, ys, cells.sortedWith(compareBy({ it.r }, { it.c })), true, color, "ruling")
    }

    private fun makeCell(
        r: Int, c: Int, rs: Int, cs: Int, xs: List<Float>, ys: List<Float>,
        vCover: (Float, Float, Float) -> Float, hCover: (Float, Float, Float) -> Float, fills: List<FillRect>,
    ): DetectedCell {
        val b = Box(xs[c], ys[r], xs[c + cs], ys[r + rs])
        val borders = CellBorders(
            top = hCover(b.top, b.x0, b.x1) >= 0.5f,
            bottom = hCover(b.bottom, b.x0, b.x1) >= 0.5f,
            start = vCover(b.x0, b.top, b.bottom) >= 0.5f, // visual left; writer maps for RTL
            end = vCover(b.x1, b.top, b.bottom) >= 0.5f,
        )
        val shade = fills.asSequence()
            .filter { !LineGrouper.isWhite(it.color) && it.box.height > 2.5f && it.box.width > 2.5f }
            .filter { it.box.contains(b.cx, b.cy) && it.box.intersectionArea(b) >= 0.5f * b.area }
            .minByOrNull { it.box.area }?.color
        return DetectedCell(r, c, rs, cs, b, borders, shade)
    }
}

/**
 * Detects tables without (complete) ruling lines by looking for vertical
 * whitespace corridors that run through several consecutive text lines – the
 * same idea as the "stream" mode of well-known PDF table extractors.
 */
object AlignmentTableDetector {

    private class Word(val glyphs: List<Glyph>, val box: Box)
    private class VLine(val pieces: List<TextLine>) {
        val box = Box.of(pieces.map { it.box })!!
        val size = pieces.maxOf { it.size }
        val words: List<Word> = buildWords(pieces)
    }

    private fun buildWords(pieces: List<TextLine>): List<Word> {
        val out = ArrayList<Word>()
        for (p in pieces) {
            var cur = ArrayList<Glyph>()
            var lastX1 = Float.NEGATIVE_INFINITY
            for (g in p.glyphs) {
                val gap = g.box.x0 - lastX1
                if (cur.isNotEmpty() && (gap > 0.25f * max(p.size, 3f) || g.isWord)) { out += Word(cur, Box.of(cur.map { it.box })!!); cur = ArrayList() }
                cur += g; lastX1 = max(lastX1, g.box.x1)
            }
            if (cur.isNotEmpty()) out += Word(cur, Box.of(cur.map { it.box })!!)
        }
        return out
    }

    fun detect(pieces: List<TextLine>, pageW: Float, ruleRegions: List<RuleRegion>): Pair<List<DetectedTable>, Set<TextLine>> {
        if (pieces.size < 3) return emptyList<DetectedTable>() to emptySet()
        val lines = groupRows(pieces).map { VLine(it) }
        val tables = ArrayList<DetectedTable>()
        val consumed = HashSet<TextLine>()
        var i = 0
        while (i < lines.size) {
            // Grow the longest block starting at i that keeps at least one corridor.
            var best: Pair<Int, List<Pair<Float, Float>>>? = null
            var j = i + 1
            while (j < lines.size) {
                val gap = lines[j].box.top - lines[j - 1].box.bottom
                if (gap > 2.4f * max(lines[j].size, lines[j - 1].size)) break
                val block = lines.subList(i, j + 1)
                if (!hasFreeBand(block)) break
                val corridors = corridors(block)
                if (j - i + 1 >= 3 && corridors.isNotEmpty()) best = j to corridors
                j++
            }
            var b = best
            // Leading lines in a different font size (titles) are not table rows.
            if (b != null) {
                val med = lines.subList(i, b.first + 1).map { it.size }.sorted().let { it[it.size / 2] }
                var s0 = i
                while (s0 < b.first - 1 && abs(lines[s0].size - med) > 0.15f * med) s0++
                if (s0 != i) {
                    val c = corridors(lines.subList(s0, b.first + 1))
                    b = if (c.isNotEmpty() && b.first - s0 + 1 >= 3) { i = s0; b.first to c } else null
                }
            }
            if (b != null) {
                // Drop leading/trailing lines that cut through the columns (titles, notes).
                var s0 = i; var e0 = b.first; var cor = b.second
                while (e0 - s0 + 1 > 3 && crosses(lines[e0], cor)) { e0--; cor = corridors(lines.subList(s0, e0 + 1)).ifEmpty { cor } }
                while (e0 - s0 + 1 > 3 && crosses(lines[s0], cor)) { s0++; cor = corridors(lines.subList(s0, e0 + 1)).ifEmpty { cor } }
                // A first/last line that hides a column boundary is not part of the table.
                while (e0 - s0 + 1 > 3) {
                    val c = corridors(lines.subList(s0 + 1, e0 + 1))
                    if (c.size > cor.size) { s0++; cor = c } else break
                }
                while (e0 - s0 + 1 > 3) {
                    val c = corridors(lines.subList(s0, e0))
                    if (c.size > cor.size) { e0--; cor = c } else break
                }
                i = s0
                b = e0 to cor
                val block = lines.subList(i, b.first + 1)
                val t = build(block, b.second, pageW, ruleRegions)
                if (t != null) {
                    tables += t
                    block.forEach { consumed += it.pieces }
                    i = b.first + 1
                    continue
                }
            }
            i++
        }
        return tables to consumed
    }

    private fun groupRows(pieces: List<TextLine>): List<List<TextLine>> {
        val sorted = pieces.sortedBy { it.baseline }
        val rows = ArrayList<MutableList<TextLine>>()
        for (p in sorted) {
            val last = rows.lastOrNull()
            if (last != null && abs(last.first().baseline - p.baseline) < 0.35f * max(p.size, last.first().size)) last += p
            else rows += mutableListOf(p)
        }
        return rows.map { r -> r.sortedBy { it.box.x0 } }
    }

    /** True while at least one table-like (wide) vertical gap survives through every line. */
    private fun hasFreeBand(block: List<VLine>): Boolean {
        val x0 = block.minOf { it.box.x0 }
        val x1 = block.maxOf { it.box.x1 }
        val n = (x1 - x0).toInt() + 2
        if (n <= 4) return false
        val covered = BooleanArray(n)
        for (l in block) for (w in l.words) {
            val a = (w.box.x0 - x0).toInt().coerceIn(0, n - 1)
            val b = (w.box.x1 - x0 + 0.99f).toInt().coerceIn(0, n - 1)
            for (k in a..b) covered[k] = true
        }
        val size = block.map { it.size }.sorted()[block.size / 2]
        var run = 0
        for (k in 1 until n - 1) { if (!covered[k]) { run++; if (run >= 1.0f * size) return true } else run = 0 }
        return false
    }

    private fun crosses(l: VLine, cor: List<Pair<Float, Float>>) =
        l.words.any { w -> cor.any { (a, b) -> w.box.x0 < a + 0.5f && w.box.x1 > b - 0.5f || (w.box.x0 < b && w.box.x1 > a && w.box.width > (b - a)) } }

    /**
     * Vertical bands inside the block that (almost) no word crosses and that split
     * real content. Up to ~15% of the lines may cross a band (spanning headers, notes).
     */
    private fun corridors(block: List<VLine>): List<Pair<Float, Float>> {
        val x0 = block.minOf { it.box.x0 }
        val x1 = block.maxOf { it.box.x1 }
        val n = (x1 - x0).toInt() + 2
        if (n <= 4) return emptyList()
        val count = IntArray(n)
        for (l in block) {
            val mark = BooleanArray(n)
            for (w in l.words) {
                val a = (w.box.x0 - x0).toInt().coerceIn(0, n - 1)
                val b = (w.box.x1 - x0 + 0.99f).toInt().coerceIn(0, n - 1)
                for (k in a..b) mark[k] = true
            }
            for (k in 0 until n) if (mark[k]) count[k]++
        }
        val allowed = if (block.size >= 7) (block.size * 0.15f).toInt() else 0
        val covered = BooleanArray(n) { count[it] > allowed }
        val size = block.map { it.size }.sorted()[block.size / 2]
        val minWidth = max(0.3f * size, 2.5f)
        val out = ArrayList<Pair<Float, Float>>()
        var k = 0
        while (k < n) {
            if (!covered[k]) {
                var e = k
                while (e + 1 < n && !covered[e + 1]) e++
                val a = x0 + k; val b = x0 + e
                if (b - a >= minWidth && a > x0 + 1f && b < x1 - 1f) {
                    // Content on both sides in at least half of the lines.
                    val both = block.count { l -> l.words.any { it.box.x1 <= a + 1f } && l.words.any { it.box.x0 >= b - 1f } }
                    if (both >= 2 && both * 3 >= block.size) out += a to b
                }
                k = e + 1
            } else k++
        }
        // Prose never has a wide aligned gap; tables almost always do.
        if (out.none { it.second - it.first >= 1.0f * size }) return emptyList()
        return out
    }

    private val debug = System.getenv("PDFW_DEBUG") != null
    private fun dbg(m: String) { if (debug) System.err.println("[align] " + m) }

    private fun build(block: List<VLine>, corridors: List<Pair<Float, Float>>, pageW: Float, ruleRegions: List<RuleRegion>): DetectedTable? {
        dbg("block lines=${block.size} top=${block.first().box.top} corridors=$corridors")
        val bx0 = block.minOf { it.box.x0 } - 2f
        val bx1 = block.maxOf { it.box.x1 } + 2f
        val xs = ArrayList<Float>()
        xs += bx0
        corridors.forEach { xs += (it.first + it.second) / 2f }
        xs += bx1
        val cols = xs.size - 1
        if (cols < 2) return null
        fun colOf(x: Float) = (xs.indexOfLast { it <= x }).coerceIn(0, cols - 1)

        // Column statistics for guards.
        val colWords = (0 until cols).map { c -> block.flatMap { l -> l.words.filter { colOf(it.box.cx) == c } } }
        if (colWords.any { it.isEmpty() }) { dbg("empty column"); return null }
        // A column made only of list markers / bullets means a list, not a table.
        for (ws in colWords) {
            val texts = ws.map { w -> w.glyphs.joinToString("") { it.text } }
            if (texts.all { t -> t.length <= 4 && (t.any { UnicodeText.bulletChars.contains(it.code) } || Regex("^[(]?[0-9\\u0660-\\u0669a-zA-Z\\u0621-\\u064A]{1,3}[.)-]$|^[(][0-9\\u0660-\\u0669]{1,3}[)]$").matches(t) || Regex("^[.)-][0-9\\u0660-\\u0669a-zA-Z\\u0621-\\u064A]{1,3}[(]?$").matches(t)) }) { dbg("marker column"); return null }
        }
        // Two wide prose columns = page columns, not a table.
        val colSpan = (0 until cols).map { c -> val ws = colWords[c]; ws.maxOf { it.box.x1 } - ws.minOf { it.box.x0 } }
        if (cols == 2 && colSpan.all { it > 0.22f * pageW } && block.size > 3) { dbg("prose columns"); return null }
        if (colSpan.any { it > 0.6f * pageW }) { dbg("wide column"); return null }

        // Rows: lines that overlap vertically form one row; sparse close lines continue the previous row.
        val rows = ArrayList<MutableList<VLine>>()
        for (l in block) {
            val last = rows.lastOrNull()
            if (last != null) {
                val lastBottom = last.maxOf { it.box.bottom }
                val overlap = l.box.top < lastBottom - 0.15f * l.size
                val usedCols = l.words.map { colOf(it.box.cx) }.toSet()
                val lastCols = last.flatMap { r -> r.words.map { colOf(it.box.cx) } }.toSet()
                val continuation = usedCols.size < cols && lastCols.containsAll(usedCols) && usedCols.size < lastCols.size &&
                    l.box.top - lastBottom < 0.45f * l.size
                if (overlap || continuation) { last += l; continue }
            }
            rows += mutableListOf(l)
        }
        if (rows.size < 2) { dbg("rows<2"); return null }
        val ys = ArrayList<Float>()
        ys += rows.first().minOf { it.box.top } - 2f
        for (k in 0 until rows.size - 1) ys += (rows[k].maxOf { it.box.bottom } + rows[k + 1].minOf { it.box.top }) / 2f
        ys += rows.last().maxOf { it.box.bottom } + 2f
        val box = Box(xs.first(), ys.first(), xs.last(), ys.last())
        val region = ruleRegions.firstOrNull { it.box.expand(14f).containsBox(box, 4f) || it.box.intersectionArea(box) > 0.6f * box.area }
        val ruleYs = region?.ruleYs ?: emptyList()
        fun ruleBetween(a: Float, b: Float) = ruleYs.any { it >= a && it <= b }
        val cells = ArrayList<DetectedCell>()
        for ((r, row) in rows.withIndex()) {
            val rowTop = row.minOf { it.box.top }; val rowBottom = row.maxOf { it.box.bottom }
            val prevBottom = if (r == 0) rowTop - 14f else rows[r - 1].maxOf { it.box.bottom }
            val nextTop = if (r == rows.size - 1) rowBottom + 14f else rows[r + 1].minOf { it.box.top }
            for (c in 0 until cols) {
                val b = Box(xs[c], ys[r], xs[c + 1], ys[r + 1])
                val top = ruleBetween(prevBottom, rowTop)
                val bottom = ruleBetween(rowBottom, nextTop)
                val cell = DetectedCell(r, c, 1, 1, b, CellBorders(top, bottom, false, false), null)
                for (l in row) for (w in l.words) if (colOf(w.box.cx) == c) cell.glyphs += w.glyphs
                cells += cell
            }
        }
        return DetectedTable(box, xs, ys, cells, bordered = false, borderColor = 0, detection = if (region != null) "rules" else "alignment")
    }
}
