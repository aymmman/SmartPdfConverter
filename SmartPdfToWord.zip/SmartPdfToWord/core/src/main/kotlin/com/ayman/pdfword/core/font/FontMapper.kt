package com.ayman.pdfword.core.font

/**
 * Maps PDF font names (usually PostScript names, often subset-prefixed) to Word
 * font family names. Families are written into the DOCX by name; Word renders
 * them if installed and substitutes otherwise. The mapper records honestly
 * whether the family was recognised, kept as-is, or substituted.
 */
class FontMapper(
    private val defaultLatin: String = "Calibri",
    private val defaultArabic: String = "Arial",
    /** User rules: lower-cased source family (or raw name) → target family. */
    private val userRules: Map<String, String> = emptyMap(),
) {
    enum class Status { PRESERVED, KEPT_UNVERIFIED, SUBSTITUTED, USER_RULE, ESTIMATED }

    data class Resolved(
        val family: String,
        val arabicCapable: Boolean,
        val status: Status,
        val sourceName: String,
        val boldHint: Boolean,
        val italicHint: Boolean,
    )

    private val cache = HashMap<String, Resolved>()

    fun resolve(rawName: String, estimated: Boolean = false): Resolved = cache.getOrPut("$rawName|$estimated") {
        compute(rawName, estimated)
    }

    fun csFontFor(r: Resolved): String = if (r.arabicCapable) r.family else defaultArabic
    val defaultArabicFont: String get() = defaultArabic
    val defaultLatinFont: String get() = defaultLatin

    private fun compute(rawName: String, estimated: Boolean): Resolved {
        val noSubset = rawName.substringAfter('+', rawName).let { if (rawName.indexOf('+') in 1..7) it else rawName }
        val lower = noSubset.lowercase()
        val bold = BOLD_TOKENS.any { lower.contains(it) }
        val italic = lower.contains("italic") || lower.contains("oblique") || lower.endsWith(",it") || lower.endsWith("-it")
        if (estimated || noSubset.isBlank()) {
            return Resolved(defaultLatin, isArabicCapable(defaultLatin), Status.ESTIMATED, rawName, bold, italic)
        }
        // Family part: before "-" or "," style suffix.
        var family = noSubset.split('-', ',').first().trim()
        family = family.removeSuffix("PSMT").removeSuffix("MT").removeSuffix("PS")
        val key = normalizeKey(family)

        userRules[key]?.let { return Resolved(it, isArabicCapable(it), Status.USER_RULE, rawName, bold, italic) }
        userRules[lower]?.let { return Resolved(it, isArabicCapable(it), Status.USER_RULE, rawName, bold, italic) }

        KNOWN[key]?.let { (name, substituted) ->
            return Resolved(name, isArabicCapable(name), if (substituted) Status.SUBSTITUTED else Status.PRESERVED, rawName, bold, italic)
        }
        if (looksGarbage(family)) {
            return Resolved(defaultLatin, isArabicCapable(defaultLatin), Status.SUBSTITUTED, rawName, bold, italic)
        }
        // Unknown but plausible family name: keep it (split CamelCase into words).
        val pretty = splitCamel(family)
        return Resolved(pretty, isArabicCapable(pretty) || ARABIC_HINTS.any { key.contains(it) }, Status.KEPT_UNVERIFIED, rawName, bold, italic)
    }

    private fun looksGarbage(f: String): Boolean {
        if (f.length <= 3) return true
        val k = f.lowercase()
        if (GARBAGE_PATTERNS.any { it.matches(k) }) return true
        val letters = f.count { it.isLetter() }
        return letters < f.length / 2
    }

    private fun splitCamel(s: String): String {
        if (s.contains(' ')) return s
        val sb = StringBuilder()
        for ((i, c) in s.withIndex()) {
            if (i > 0 && c.isUpperCase() && s[i - 1].isLowerCase()) sb.append(' ')
            sb.append(c)
        }
        return sb.toString()
    }

    companion object {
        private val BOLD_TOKENS = listOf("bold", "black", "heavy", "semibold", "demibold", "extrabold", ",bd", "-bd")
        private val ARABIC_HINTS = listOf("arab", "naskh", "kufi", "nastaliq", "thuluth", "diwani", "ruqaa", "uthman", "quran", "majalla")
        private val GARBAGE_PATTERNS = listOf(
            Regex("^f\\d+$"), Regex("^t\\d+(_\\d+)?$"), Regex("^tt\\d+.*"), Regex("^c\\d+_\\d+$"),
            Regex("^identity.*"), Regex("^font\\d*$"), Regex("^r\\d+$"), Regex("^g\\d+$"), Regex("^ff\\d+$"),
        )

        fun normalizeKey(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

        /** key → (Word family name, isSubstitution) */
        private val KNOWN: Map<String, Pair<String, Boolean>> = buildMap {
            fun p(name: String, vararg keys: String) {
                put(normalizeKey(name), name to false); keys.forEach { put(it, name to false) }
            }
            fun s(name: String, vararg keys: String) { keys.forEach { put(it, name to true) } }
            p("Arial", "arialmt", "arialunicodems"); p("Arial Narrow", "arialnarrow"); p("Arial Black", "arialblack")
            p("Times New Roman", "timesnewromanps", "timesnewromanpsmt"); s("Times New Roman", "times", "timesroman", "timesten", "tinos")
            s("Arial", "helvetica", "helveticaneue", "arimo", "liberationsans", "nimbussans", "nimbussansl")
            s("Times New Roman", "liberationserif", "nimbusromno9l", "nimbusroman")
            s("Courier New", "courier", "liberationmono", "nimbusmonol", "cousine")
            p("Calibri"); p("Calibri Light", "calibrilight"); p("Cambria"); p("Cambria Math", "cambriamath"); p("Candara")
            p("Consolas"); p("Courier New", "couriernewps", "couriernewpsmt"); p("Georgia"); p("Garamond"); p("Segoe UI", "segoeui")
            p("Tahoma"); p("Verdana"); p("Trebuchet MS", "trebuchetms", "trebuchet"); p("Century Gothic", "centurygothic")
            p("Book Antiqua", "bookantiqua"); p("Palatino Linotype", "palatinolinotype"); s("Palatino Linotype", "palatino")
            p("Symbol"); p("Wingdings"); p("Aptos"); p("Aptos Display", "aptosdisplay"); p("Corbel"); p("Constantia")
            p("Franklin Gothic", "franklingothic"); p("Gill Sans MT", "gillsansmt", "gillsans"); p("Lucida Sans", "lucidasans")
            p("Roboto"); p("Open Sans", "opensans"); p("Lato"); p("Montserrat"); p("Source Sans Pro", "sourcesanspro"); p("Noto Sans", "notosans")
            p("Noto Serif", "notoserif"); p("DejaVu Sans", "dejavusans"); p("Inter")
            // Arabic families
            p("Simplified Arabic", "simplifiedarabic"); p("Traditional Arabic", "traditionalarabic"); p("Arabic Typesetting", "arabictypesetting")
            p("Sakkal Majalla", "sakkalmajalla"); p("Andalus"); p("Aldhabi"); p("Urdu Typesetting", "urdutypesetting"); p("Dubai")
            p("Microsoft Uighur", "microsoftuighur"); p("Amiri"); p("Noto Naskh Arabic", "notonaskharabic", "notonaskharabicui")
            p("Noto Sans Arabic", "notosansarabic", "notosansarabicui"); p("Noto Kufi Arabic", "notokufiarabic"); p("Cairo"); p("Tajawal")
            p("Almarai"); p("IBM Plex Sans Arabic", "ibmplexsansarabic"); p("Scheherazade New", "scheherazadenew", "scheherazade")
            p("Lateef"); p("Droid Arabic Naskh", "droidarabicnaskh"); p("Droid Arabic Kufi", "droidarabickufi"); p("Changa")
            p("DIN Next LT Arabic", "dinnextltarabic"); p("GE SS Two", "gesstwo"); p("Al Bayan", "albayan"); p("Geeza Pro", "geezapro")
            p("Baghdad"); p("Nadeem"); p("Mudir MT", "mudirmt"); p("Diwani Letter", "diwaniletter"); p("Arial Unicode MS", "arialunicode")
            p("Segoe UI Historic", "segoeuihistoric"); p("Mirza"); p("Harmattan"); p("Markazi Text", "markazitext"); p("Reem Kufi", "reemkufi")
            p("El Messiri", "elmessiri"); p("Readex Pro", "readexpro"); p("Alexandria"); p("Rubik"); p("Noto Nastaliq Urdu", "notonastaliqurdu")
        }

        private val ARABIC_CAPABLE = setOf(
            "arial", "timesnewroman", "tahoma", "segoeui", "couriernew", "arialunicodems", "microsoftsansserif",
            "simplifiedarabic", "traditionalarabic", "arabictypesetting", "sakkalmajalla", "andalus", "aldhabi",
            "urdutypesetting", "dubai", "microsoftuighur", "amiri", "notonaskharabic", "notosansarabic", "notokufiarabic",
            "cairo", "tajawal", "almarai", "ibmplexsansarabic", "scheherazadenew", "lateef", "droidarabicnaskh",
            "droidarabickufi", "changa", "dinnextltarabic", "gesstwo", "albayan", "geezapro", "baghdad", "nadeem",
            "mudirmt", "diwaniletter", "mirza", "harmattan", "markazitext", "reemkufi", "elmessiri", "readexpro",
            "alexandria", "rubik", "notonastaliqurdu", "dejavusans", "aptos",
        )

        fun isArabicCapable(family: String) = normalizeKey(family) in ARABIC_CAPABLE
    }
}
