package com.ayman.pdfword.core.layout

import com.ayman.pdfword.core.ConversionMode
import com.ayman.pdfword.core.doc.Align
import com.ayman.pdfword.core.doc.Block
import com.ayman.pdfword.core.doc.ColumnBreakBlock
import com.ayman.pdfword.core.doc.ImageBlock
import com.ayman.pdfword.core.doc.Margins
import com.ayman.pdfword.core.doc.PageLayout
import com.ayman.pdfword.core.doc.ParaProps
import com.ayman.pdfword.core.doc.ParagraphBlock
import com.ayman.pdfword.core.doc.Placement
import com.ayman.pdfword.core.doc.SectionPart
import com.ayman.pdfword.core.doc.TableBlock
import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.Glyph
import com.ayman.pdfword.core.model.ImageInput
import com.ayman.pdfword.core.model.PageInput
import com.ayman.pdfword.core.report.PageStats
import com.ayman.pdfword.core.table.AlignmentTableDetector
import com.ayman.pdfword.core.table.DetectedTable
import com.ayman.pdfword.core.table.RulingTableDetector
import com.ayman.pdfword.core.table.TableBuilder
import com.ayman.pdfword.core.text.UnicodeText
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class PageLayoutEngine(private val ctx: BuildContext) {

    data class Result(val layout: PageLayout, val stats: PageStats)

    /** Regions of vector graphics (charts, diagrams) the caller should rasterise. */
    fun detectFigureRegions(page: PageInput): List<Box> {
        if (!ctx.options.keepImages || page.graphics.isEmpty()) return emptyList()
        val tables = if (ctx.options.detectTables) RulingTableDetector.detect(page.segments, page.fills, page.width, page.height).tables
            .filter { !isGraphicTable(it, page.glyphs) }.map { it.box } else emptyList()
        return FigureDetector.detect(page.graphics, page.glyphs, tables, page.width, page.height)
    }

    /** A "table" of ruling lines with almost no text is a chart grid or decoration. */
    private fun isGraphicTable(t: DetectedTable, glyphs: List<Glyph>): Boolean {
        if (t.cells.size < 6) return false
        val withText = t.cells.count { c -> glyphs.any { c.box.contains(it.box.cx, it.box.cy) } }
        return withText < 0.3f * t.cells.size
    }

    private sealed interface Item { val top: Float; val box: Box }
    private class PieceItem(val line: TextLine) : Item { override val top get() = line.box.top; override val box get() = line.box }
    private class TableItem(val table: DetectedTable) : Item { override val top get() = table.box.top; override val box get() = table.box }
    private class ImageItem(val image: ImageInput) : Item { override val top get() = image.box.top; override val box get() = image.box }

    fun layout(page: PageInput, figureImages: List<ImageInput>): Result {
        val opts = ctx.options
        val w = page.width
        val h = page.height
        val figureBoxes = figureImages.map { it.box }
        val glyphs = LineGrouper.prepare(page.glyphs).filter { g -> figureBoxes.none { it.contains(g.box.cx, g.box.cy) } }
        val counts = UnicodeText.countLetters(glyphs.joinToString("") { it.text })
        val pageRtl = counts.arabic > counts.latin
        val bodySize = TextLine.dominantSize(glyphs).takeIf { glyphs.isNotEmpty() } ?: 11f

        val ruling = if (opts.detectTables) RulingTableDetector.detect(page.segments, page.fills, w, h) else RulingTableDetector.Result(emptyList(), emptyList(), emptyList())
        val rulingTables = ruling.tables.filter { t -> figureBoxes.none { it.intersectionArea(t.box) > 0.5f * t.box.area } && !isGraphicTable(t, glyphs) }
        LineGrouper.decorate(glyphs, page.segments, page.fills, rulingTables.map { it.box })

        val free = ArrayList<Glyph>()
        for (g in glyphs) {
            val y = (g.box.top + g.baseline) / 2f
            val cell = rulingTables.firstNotNullOfOrNull { it.cellAt(g.box.cx, y) }
            if (cell != null) cell.glyphs += g else free += g
        }
        val tables = rulingTables.filter { t -> !(t.rows == 1 && t.cols == 1 && t.cells.all { it.glyphs.isEmpty() }) }

        val pieces = LineGrouper.groupLines(free).flatMap { LineGrouper.splitPieces(it) }
        for (p in pieces) p.logical = LineGrouper.toLogical(p, pageRtl)

        val images = collectImages(page, figureImages, figureBoxes, glyphs)

        return if (opts.mode == ConversionMode.LAYOUT) layoutPreserve(page, pieces, tables, images, pageRtl, bodySize)
        else layoutEditable(page, pieces, tables, ruling.ruleRegions, images, glyphs, pageRtl, bodySize)
    }

    private fun collectImages(page: PageInput, figureImages: List<ImageInput>, figureBoxes: List<Box>, glyphs: List<Glyph>): List<Pair<ImageInput, Boolean>> {
        if (!ctx.options.keepImages) return emptyList()
        val pageArea = page.width * page.height
        val src = page.images.filter { im -> figureBoxes.none { it.expand(2f).containsBox(im.box) } } + figureImages
        val out = ArrayList<Pair<ImageInput, Boolean>>()
        for (im in src) {
            if (im.box.width < 6f || im.box.height < 6f) continue
            val full = im.box.area > 0.8f * pageArea
            if (full && (page.ocrApplied || page.invisibleTextLayer)) continue // scan behind recognised text
            val textInside = glyphs.count { im.box.contains(it.box.cx, it.box.cy) }
            out += im to (textInside >= 8 || full)
        }
        return out
    }

    // ------------------------------------------------------------------ editable

    private fun layoutEditable(
        page: PageInput,
        pieces: List<TextLine>,
        rulingTables: List<DetectedTable>,
        ruleRegions: List<com.ayman.pdfword.core.table.RuleRegion>,
        images: List<Pair<ImageInput, Boolean>>,
        glyphs: List<Glyph>,
        pageRtl: Boolean,
        bodySize: Float,
    ): Result {
        val opts = ctx.options
        val w = page.width; val h = page.height
        // Page columns first, so two prose columns are never mistaken for a table.
        val preContent = Box.of(pieces.map { it.box })
        val preCol = if (opts.detectColumns && preContent != null) ColumnDetector.detect(pieces, preContent.x0, preContent.x1) else null
        val (alignTables, consumed) = if (opts.detectTables && opts.detectBorderlessTables) {
            if (preCol == null) AlignmentTableDetector.detect(pieces, w, ruleRegions)
            else {
                val g = preCol.gutter
                val groups = pieces.groupBy { if (it.box.x1 <= g + 2f) 0 else if (it.box.x0 >= g - 2f) 1 else 2 }
                val ts = ArrayList<DetectedTable>(); val cs = HashSet<TextLine>()
                for (grp in groups.values) { val (t, c) = AlignmentTableDetector.detect(grp, w, ruleRegions); ts += t; cs += c }
                ts to cs
            }
        } else (emptyList<DetectedTable>() to emptySet())
        val bodyPieces = pieces.filter { it !in consumed }
        val tables = (rulingTables + alignTables).sortedBy { it.box.top }

        fun isMarginal(b: Box) = b.bottom < 0.085f * h || b.top > 0.915f * h
        val inlineImages = images.filter { !it.second }.map { it.first }
        val behindImages = images.filter { it.second }.map { it.first }
        // Margins follow the text body; tables and images may legitimately extend past it
        // (Word outdents table borders by the cell padding, for instance).
        val textBoxes = bodyPieces.filter { !isMarginal(it.box) }.map { it.box } +
            tables.flatMap { t -> t.cells.flatMap { c -> c.glyphs.map { it.box } + c.lines.map { it.box } } }
        val allBoxes = textBoxes + tables.map { it.box } + inlineImages.map { it.box }
        val textContent = Box.of(textBoxes)
        val all = Box.of(allBoxes)
        var content = when {
            textContent == null -> all ?: Box.of(bodyPieces.map { it.box }) ?: Box(72f, 72f, w - 72f, h - 72f)
            all == null -> textContent
            else -> Box(textContent.x0, all.top, textContent.x1, all.bottom)
        }
        // The start margin is where most lines begin; hanging bullets may sit outside it.
        val startEdges = bodyPieces.filter { !isMarginal(it.box) && it.box.width > 0.3f * content.width }
            .map { Math.round(if (pageRtl) it.box.x1 else it.box.x0) }
        if (startEdges.size >= 3) {
            val mode = startEdges.groupingBy { it }.eachCount().entries
                .sortedWith(compareByDescending<Map.Entry<Int, Int>> { it.value }.thenBy { if (pageRtl) -it.key else it.key })
                .first()
            if (mode.value >= 2) {
                content = if (pageRtl) Box(content.x0, content.top, min(content.x1, mode.key + 0.5f), content.bottom)
                else Box(max(content.x0, mode.key - 0.5f), content.top, content.x1, content.bottom)
            }
        }
        val slack = 3f
        val margins = Margins(
            top = (content.top - 0.25f * bodySize).coerceIn(14f, 300f),
            bottom = (h - content.bottom - 12f).coerceIn(14f, 72f),
            left = (content.x0 - if (pageRtl) slack else 0f).coerceIn(14f, 0.4f * w),
            right = (w - content.x1 - if (pageRtl) 0f else slack).coerceIn(14f, 0.4f * w),
        )
        val mL = margins.left
        val mR = w - margins.right

        val col = if (opts.detectColumns) ColumnDetector.detect(bodyPieces.filter { !isMarginal(it.box) }, content.x0, content.x1) else null

        // Lines in the top/bottom page zones are laid out separately so they never
        // influence the spacing of the body flow (they may become header/footer).
        val marginalPieces = bodyPieces.filter { isMarginal(it.box) && (it.logical?.text?.length ?: 0) <= 150 }
        val flowPieces = bodyPieces.filter { it !in marginalPieces }
        val marginalBlocks: List<ParagraphBlock> = run {
            val pb = ParagraphBuilder(ctx, bodySize, mL, mR, content.x0, content.x1, allowHeadings = false, allowLists = false)
            val top = marginalPieces.filter { it.box.bottom < 0.5f * h }.sortedBy { it.box.top }
            val bottom = marginalPieces.filter { it.box.bottom >= 0.5f * h }.sortedBy { it.box.top }
            fun mk(lines: List<TextLine>, isTop: Boolean): List<ParagraphBlock> {
                // Each printed line is its own candidate (headers often combine left/right items).
                val rows = ArrayList<MutableList<TextLine>>()
                for (l in lines) {
                    val last = rows.lastOrNull()
                    if (last != null && abs(last.first().baseline - l.baseline) < 0.35f * l.size) last += l else rows += mutableListOf(l)
                }
                return rows.flatMap { row ->
                    val line = if (row.size == 1) row[0] else TextLine(row.flatMap { it.glyphs }.sortedBy { it.box.x0 }).also { it.logical = LineGrouper.toLogical(it, pageRtl) }
                    pb.build(listOf(line), null, null).map { b ->
                        b.copy(props = b.props.copy(spaceBeforePt = 0f), marginalKey = marginalKey(b.text), marginalTop = isTop)
                    }
                }
            }
            mk(top, true) + mk(bottom, false)
        }

        val items = ArrayList<Item>()
        flowPieces.forEach { items += PieceItem(it) }
        tables.forEach { items += TableItem(it) }
        inlineImages.forEach { items += ImageItem(it) }
        items.sortBy { it.top }

        val parts = ArrayList<SectionPart>()
        val behindBlocks = behindImages.map { ImageBlock(ctx.id("img"), it.box.top, it, anchored = true, behindText = true) }
        var rulingCount = 0; var borderlessCount = 0
        tables.forEach { if (it.detection == "ruling") rulingCount++ else borderlessCount++ }

        if (col == null) {
            val blocks = buildRegion(items, mL, mR, content.x0, content.x1, pageRtl, bodySize, margins.top, h)
            parts += SectionPart(1, pageRtl, behindBlocks + blocks)
        } else {
            val g = col.gutter
            val leftItems = items.filter { it.box.x1 <= g + 2f }
            val rightItems = items.filter { it.box.x0 >= g - 2f }
            val bothStart = max(leftItems.minOfOrNull { it.box.top } ?: 0f, rightItems.minOfOrNull { it.box.top } ?: 0f)
            val bothEnd = min(leftItems.maxOfOrNull { it.box.bottom } ?: h, rightItems.maxOfOrNull { it.box.bottom } ?: h)
            // Items above/below the region where both columns have content span the page.
            fun crosses(b: Box) = (b.x0 < g - 2f && b.x1 > g + 2f) || b.bottom < bothStart - 1f || b.top > bothEnd + 1f
            // Split into bands of full-width vs two-column content.
            val bands = ArrayList<Pair<Boolean, MutableList<Item>>>()
            for (it in items) {
                val full = crosses(it.box) || isMarginal(it.box)
                val last = bands.lastOrNull()
                if (last != null && last.first == !full) last.second += it else bands += (!full) to mutableListOf(it)
            }
            var first = true
            var flowTop = margins.top
            for ((twoCol, bandItems) in bands) {
                val extra = if (first) behindBlocks else emptyList()
                first = false
                if (!twoCol || bandItems.size < 2) {
                    val blocks = buildRegion(bandItems, mL, mR, content.x0, content.x1, pageRtl, bodySize, flowTop, h)
                    parts += SectionPart(1, pageRtl, extra + blocks)
                } else {
                    val left = bandItems.filter { it.box.cx < g }
                    val right = bandItems.filter { it.box.cx >= g }
                    val gap = ((right.minOfOrNull { it.box.x0 } ?: (g + 9f)) - (left.maxOfOrNull { it.box.x1 } ?: (g - 9f))).coerceIn(12f, 72f)
                    val colW = (mR - mL - gap) / 2f
                    val lBlocks = buildRegion(left, mL, mL + colW, content.x0, left.maxOfOrNull { it.box.x1 } ?: g, pageRtl, bodySize, flowTop, h)
                    val rBlocks = buildRegion(right, mR - colW, mR, right.minOfOrNull { it.box.x0 } ?: g, content.x1, pageRtl, bodySize, flowTop, h)
                    val firstCol = if (pageRtl) rBlocks else lBlocks
                    val secondCol = if (pageRtl) lBlocks else rBlocks
                    val blocks = ArrayList<Block>()
                    blocks += extra
                    blocks += firstCol
                    blocks += ColumnBreakBlock(ctx.id("cb"), g)
                    blocks += secondCol
                    parts += SectionPart(2, pageRtl, blocks, gap)
                }
                flowTop = bandItems.maxOf { it.box.bottom }
            }
        }

        // Header/footer candidates go to the start / end of the page's content.
        if (parts.isEmpty()) parts += SectionPart(1, pageRtl, emptyList())
        val topBlocks = marginalBlocks.filter { it.marginalTop }
        val bottomBlocks = marginalBlocks.filter { !it.marginalTop }
        parts[0] = parts[0].copy(blocks = topBlocks + parts[0].blocks)
        parts[parts.size - 1] = parts.last().copy(blocks = parts.last().blocks + bottomBlocks)
        val marked = parts.toList()

        val reviewCount = marked.sumOf { p -> p.blocks.count { it is ParagraphBlock && it.needsReview } } +
            marked.sumOf { p -> p.blocks.filterIsInstance<TableBlock>().sumOf { t -> t.cells.sumOf { c -> c.paragraphs.count { it.needsReview } } } }
        val reasons = ArrayList<String>()
        if (page.ocrApplied) reasons += "OCR"
        if (page.textQuality < 0.85f && !page.ocrApplied) reasons += "low text-layer quality"
        if (col != null) reasons += "two-column layout"
        if (borderlessCount > 0) reasons += "borderless table inferred from alignment"
        if (behindImages.isNotEmpty()) reasons += "text over images"
        if (page.rotatedGlyphsDropped > 0) reasons += "rotated text omitted (${page.rotatedGlyphsDropped} chars)"

        val layout = PageLayout(page.index, w, h, margins, marked, pageRtl)
        val stats = PageStats(
            pageNumber = page.index + 1, kind = page.kind.name, ocrApplied = page.ocrApplied, ocrConfidence = page.ocrMeanConfidence,
            textQuality = page.textQuality, rulingTables = rulingCount, borderlessTables = borderlessCount,
            images = images.count { !it.first.fromVectorFigure }, figuresRasterized = images.count { it.first.fromVectorFigure },
            twoColumns = col != null, reviewParagraphs = reviewCount, uncertainReasons = reasons, warnings = page.warnings,
        )
        return Result(layout, stats)
    }

    private fun buildRegion(
        items: List<Item>, marginLeft: Float, marginRight: Float, contentLeft: Float, contentRight: Float,
        pageRtl: Boolean, bodySize: Float, flowTop: Float, pageH: Float,
    ): List<Block> {
        val sorted = items.sortedBy { it.top }
        // Re-join pieces that share a row (e.g. "Name: ...    Date: ...") into one tabbed line.
        val merged = ArrayList<Item>()
        for (it in sorted) {
            val last = merged.lastOrNull()
            if (it is PieceItem && last is PieceItem &&
                abs(it.line.baseline - last.line.baseline) < 0.35f * max(it.line.size, last.line.size) &&
                it.line.box.overlapX(last.line.box) < 1f
            ) {
                val joined = TextLine((last.line.glyphs + it.line.glyphs).sortedBy { g -> g.box.x0 })
                joined.logical = LineGrouper.toLogical(joined, pageRtl)
                merged[merged.size - 1] = PieceItem(joined)
            } else merged += it
        }
        val pb = ParagraphBuilder(ctx, bodySize, marginLeft, marginRight, contentLeft, contentRight)
        val blocks = ArrayList<Block>()
        var pending = ArrayList<TextLine>()
        var prevBaseline: Float? = null
        var prevBottom: Float? = flowTop
        fun flush() {
            if (pending.isEmpty()) return
            val ps = pb.build(pending, prevBottom.takeIf { prevBaseline == null }, prevBaseline)
            blocks += ps
            prevBaseline = pending.last().baseline
            prevBottom = pending.last().box.bottom
            pending = ArrayList()
        }
        for (it in merged) {
            when (it) {
                is PieceItem -> pending += it.line
                is TableItem -> {
                    flush()
                    padLastParagraph(blocks, it.table.box.top)
                    addSpacerIfNeeded(blocks, prevBottom, it.table.box.top, pageRtl)
                    blocks += TableBuilder.build(it.table, ctx, bodySize, pageRtl, marginLeft, marginRight, floating = false)
                    prevBaseline = null; prevBottom = it.table.box.bottom
                }
                is ImageItem -> {
                    flush()
                    padLastParagraph(blocks, it.image.box.top)
                    addSpacerIfNeeded(blocks, prevBottom, it.image.box.top, pageRtl)
                    val b = it.image.box
                    val gl = b.x0 - marginLeft; val gr = marginRight - b.x1
                    val align = when {
                        abs(gl - gr) < 0.1f * (marginRight - marginLeft) -> Align.CENTER
                        gl < gr -> if (pageRtl) Align.END else Align.START
                        else -> if (pageRtl) Align.START else Align.END
                    }
                    blocks += ImageBlock(ctx.id("img"), b.top, it.image, anchored = false, behindText = false, align = align)
                    prevBaseline = null; prevBottom = b.bottom
                }
            }
        }
        flush()
        return blocks
    }

    /** Between two tables/images an empty spacer paragraph carries the vertical gap. */
    private fun addSpacerIfNeeded(blocks: MutableList<Block>, prevBottom: Float?, nextTop: Float, rtl: Boolean) {
        val last = blocks.lastOrNull() ?: return
        if (last is ParagraphBlock) return
        val gap = nextTop - (prevBottom ?: return)
        blocks += ParagraphBlock(ctx.id("sp"), emptyList(), ParaProps(rtl = rtl, spaceBeforePt = Math.round(gap.coerceIn(0f, 144f) * 2f) / 2f, spacer = true), nextTop)
    }

    /** Tables and inline images cannot carry space-before, so the gap goes after the previous paragraph. */
    private fun padLastParagraph(blocks: MutableList<Block>, nextTop: Float) {
        val i = blocks.indexOfLast { true }
        if (i < 0) return
        val p = blocks[i] as? ParagraphBlock ?: return
        val box = p.box ?: return
        val gap = nextTop - box.bottom - 0.2f * p.fontSize
        if (gap > 1f) blocks[i] = p.copy(props = p.props.copy(spaceAfterPt = Math.round(gap.coerceAtMost(144f) * 2f) / 2f))
    }

    // ------------------------------------------------------------------ layout preservation

    private fun layoutPreserve(
        page: PageInput, pieces: List<TextLine>, tables: List<DetectedTable>,
        images: List<Pair<ImageInput, Boolean>>, pageRtl: Boolean, bodySize: Float,
    ): Result {
        val w = page.width; val h = page.height
        val margins = Margins(18f, 18f, 18f, 18f)
        val blocks = ArrayList<Block>()
        for ((im, _) in images) blocks += ImageBlock(ctx.id("img"), im.box.top, im, anchored = true, behindText = true)
        for (t in tables) blocks += TableBuilder.build(t, ctx, bodySize, pageRtl, margins.left, w - margins.right, floating = true)
        for (p in pieces.sortedBy { it.box.top }) {
            val ll = p.logical ?: continue
            val runs = ParagraphBuilder.mergeRuns(ll.spans.map { ctx.runFor(it) })
            val isOcr = p.glyphs.any { it.isWord }
            blocks += ParagraphBlock(
                id = ctx.id("p"), runs = runs,
                props = ParaProps(rtl = ll.rtl, align = Align.START),
                top = p.box.top, box = p.box, frame = Placement(p.box),
                confidence = if (isOcr) ll.minConfidence else null,
                needsReview = isOcr && ll.minConfidence < ctx.options.reviewConfidenceThreshold,
            )
        }
        val layout = PageLayout(page.index, w, h, margins, listOf(SectionPart(1, pageRtl, blocks)), pageRtl)
        val stats = PageStats(
            pageNumber = page.index + 1, kind = page.kind.name, ocrApplied = page.ocrApplied, ocrConfidence = page.ocrMeanConfidence,
            textQuality = page.textQuality, rulingTables = tables.size, borderlessTables = 0,
            images = images.count { !it.first.fromVectorFigure }, figuresRasterized = images.count { it.first.fromVectorFigure },
            twoColumns = false, reviewParagraphs = blocks.count { it is ParagraphBlock && it.needsReview },
            uncertainReasons = buildList { if (page.ocrApplied) add("OCR"); add("positioned layout (less convenient to edit)") },
            warnings = page.warnings,
        )
        return Result(layout, stats)
    }

    companion object {
        private val digitRun = Regex("[0-9\\u0660-\\u0669\\u06F0-\\u06F9]+")
        fun marginalKey(text: String) = digitRun.replace(text.trim(), "#").replace(Regex("\\s+"), " ")
    }
}
