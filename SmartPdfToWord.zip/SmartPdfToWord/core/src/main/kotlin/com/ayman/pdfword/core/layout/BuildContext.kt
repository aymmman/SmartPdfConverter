package com.ayman.pdfword.core.layout

import com.ayman.pdfword.core.ConversionOptions
import com.ayman.pdfword.core.doc.NumberingDef
import com.ayman.pdfword.core.doc.Run
import com.ayman.pdfword.core.font.FontMapper

/** Shared, document-wide state while pages are laid out. */
class BuildContext(val options: ConversionOptions) {
    val fontMapper = FontMapper(options.defaultLatinFont, options.defaultArabicFont, options.fontRules)
    private var nextId = 0
    fun id(prefix: String) = "$prefix${nextId++}"

    val numbering = ArrayList<NumberingDef>()
    private var bulletLtr: Int? = null
    private var bulletRtl: Int? = null
    private var nextNumId = 1

    fun bulletNumId(rtl: Boolean): Int {
        val existing = if (rtl) bulletRtl else bulletLtr
        if (existing != null) return existing
        val id = nextNumId++
        numbering += NumberingDef(id, bullet = true, format = "bullet", suffix = "", start = 1, rtl = rtl)
        if (rtl) bulletRtl = id else bulletLtr = id
        return id
    }

    fun newNumbered(format: String, suffix: String, start: Int, rtl: Boolean): Int {
        val id = nextNumId++
        numbering += NumberingDef(id, bullet = false, format = format, suffix = suffix, start = start, rtl = rtl)
        return id
    }

    /** Font usage for the report: source raw name → resolution. */
    val fontUsage = LinkedHashMap<String, FontMapper.Resolved>()

    fun runFor(span: Span, textOverride: String? = null): Run {
        val st = span.style
        val r = fontMapper.resolve(st.fontName, st.estimated)
        if (st.fontName.isNotBlank() || st.estimated) fontUsage.putIfAbsent(st.fontName.ifBlank { "(OCR)" }, r)
        val size = if (span.vertAlign != 0) st.size / 0.65f else st.size
        return Run(
            text = textOverride ?: span.text,
            latinFont = r.family,
            csFont = fontMapper.csFontFor(r),
            sizePt = (Math.round(size.coerceIn(1f, 1600f) * 2f) / 2f),
            bold = st.bold || r.boldHint || span.fakeBold,
            italic = st.italic || r.italicHint,
            color = st.color,
            rtl = span.rtl,
            underline = span.underline,
            highlight = span.highlight,
            vertAlign = span.vertAlign,
        )
    }
}
