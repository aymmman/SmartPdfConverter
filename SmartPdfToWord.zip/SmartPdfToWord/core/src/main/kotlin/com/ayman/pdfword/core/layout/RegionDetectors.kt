package com.ayman.pdfword.core.layout

import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.GraphicElement
import com.ayman.pdfword.core.model.GraphicKind
import com.ayman.pdfword.core.model.Glyph
import kotlin.math.max
import kotlin.math.min

/** Finds a single vertical gutter that splits body text into two columns. */
object ColumnDetector {

    data class Result(val gutter: Float)

    fun detect(pieces: List<TextLine>, contentLeft: Float, contentRight: Float): Result? {
        if (pieces.size < 12) return null
        val w = contentRight - contentLeft
        if (w < 200f) return null
        var best: Float? = null
        var bestScore = Int.MAX_VALUE
        var x = contentLeft + 0.3f * w
        while (x <= contentLeft + 0.7f * w) {
            val crossing = pieces.count { it.box.x0 < x - 2f && it.box.x1 > x + 2f }
            if (crossing < bestScore) { bestScore = crossing; best = x }
            x += 2f
        }
        val g = best ?: return null
        // Widen to the empty band center.
        var a = g; var b = g
        while (a > contentLeft && pieces.count { it.box.x0 < a - 2f && it.box.x1 > a + 2f } <= bestScore) a -= 2f
        while (b < contentRight && pieces.count { it.box.x0 < b - 2f && it.box.x1 > b + 2f } <= bestScore) b += 2f
        val gutter = (a + b) / 2f
        if (b - a < 8f) return null
        val left = pieces.filter { it.box.x1 <= gutter + 2f }
        val right = pieces.filter { it.box.x0 >= gutter - 2f }
        if (bestScore > 0.12f * pieces.size) return null
        if (left.size < 5 || right.size < 5) return null
        if (left.size < 0.25f * pieces.size || right.size < 0.25f * pieces.size) return null
        // Columns must contain prose-width lines and overlap vertically.
        val leftWide = left.count { it.box.width > 0.25f * w }
        val rightWide = right.count { it.box.width > 0.25f * w }
        if (leftWide < 3 || rightWide < 3) return null
        // Real text columns are mostly filled with full-width lines (tables are not).
        fun dense(side: List<TextLine>): Boolean {
            val maxW = side.maxOf { it.box.width }
            return side.count { it.box.width >= 0.7f * maxW } * 2 >= side.size && side.count { it.box.width >= 0.7f * maxW } >= 4
        }
        if (!dense(left) || !dense(right)) return null
        val lTop = left.minOf { it.box.top }; val lBot = left.maxOf { it.box.bottom }
        val rTop = right.minOf { it.box.top }; val rBot = right.maxOf { it.box.bottom }
        val overlap = min(lBot, rBot) - max(lTop, rTop)
        if (overlap < 0.4f * min(lBot - lTop, rBot - rTop)) return null
        return Result(gutter)
    }
}

/** Finds clusters of vector graphics (charts, diagrams) worth rasterising as images. */
object FigureDetector {

    fun detect(
        graphics: List<GraphicElement>,
        glyphs: List<Glyph>,
        tableBoxes: List<Box>,
        pageW: Float,
        pageH: Float,
    ): List<Box> {
        val pageArea = pageW * pageH
        val items = graphics.filter { g ->
            g.box.area < 0.9f * pageArea && tableBoxes.none { it.expand(2f).containsBox(g.box) }
        }.take(6000)
        if (items.size < 4) return emptyList()
        val n = items.size
        val parent = IntArray(n) { it }
        fun find(a: Int): Int { var x = a; while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x] }; return x }
        val order = (0 until n).sortedBy { items[it].box.x0 }
        val pad = 6f
        for (oi in 0 until n) {
            val i = order[oi]
            val bi = items[i].box.expand(pad)
            var oj = oi + 1
            while (oj < n && items[order[oj]].box.x0 <= bi.x1) {
                val j = order[oj]
                if (bi.overlapY(items[j].box) > 0f || (items[j].box.top <= bi.bottom && items[j].box.bottom >= bi.top)) {
                    val a = find(i); val b = find(j); if (a != b) parent[a] = b
                }
                oj++
            }
        }
        val clusters = HashMap<Int, MutableList<GraphicElement>>()
        for (i in 0 until n) clusters.getOrPut(find(i)) { mutableListOf() } += items[i]
        val out = ArrayList<Box>()
        for (c in clusters.values) {
            if (c.size < 4) continue
            val box = Box.of(c.map { it.box })!!
            if (box.width < 40f || box.height < 40f) continue
            if (box.area < 0.02f * pageArea || box.area > 0.85f * pageArea) continue
            if (tableBoxes.any { it.intersectionArea(box) > 0.4f * box.area }) continue
            val curves = c.count { it.kind == GraphicKind.CURVE }
            val fills = c.count { it.kind == GraphicKind.FILL }
            val lines = c.count { it.kind == GraphicKind.LINE }
            if (curves < 3 && fills < 3 && lines < 8) continue
            if (c.size < 6 && curves < 3) continue
            val inside = glyphs.filter { box.contains(it.box.cx, it.box.cy) }
            val textArea = inside.sumOf { it.box.area.toDouble() }.toFloat()
            if (textArea > 0.22f * box.area) continue
            // Long sentences inside indicate a text box, not a chart.
            if (inside.size > 400) continue
            // Absorb nearby short labels (axis ticks, legends) that belong to the figure.
            var fb = box
            val labelLines = glyphs.groupBy { Math.round(it.baseline / 2f) }.values.map { g -> Box.of(g.map { it.box })!! }
            repeat(2) {
                val near = fb.expand(16f)
                for (lb in labelLines) {
                    if (near.intersectionArea(lb) <= 0f) continue
                    val outside = lb.width - lb.overlapX(fb)
                    if (outside <= 0.3f * fb.width && lb.width < 0.9f * fb.width + 40f) fb = fb.union(lb)
                }
            }
            out += Box(max(0f, fb.x0 - 2f), max(0f, fb.top - 2f), min(pageW, fb.x1 + 2f), min(pageH, fb.bottom + 2f))
        }
        return out
    }
}
