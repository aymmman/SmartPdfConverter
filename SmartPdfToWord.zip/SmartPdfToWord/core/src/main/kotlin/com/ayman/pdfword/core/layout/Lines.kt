package com.ayman.pdfword.core.layout

import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.FillRect
import com.ayman.pdfword.core.model.Glyph
import com.ayman.pdfword.core.model.Segment
import com.ayman.pdfword.core.model.TextStyle
import com.ayman.pdfword.core.model.medianOr
import com.ayman.pdfword.core.text.BidiClass
import com.ayman.pdfword.core.text.UnicodeText
import com.ayman.pdfword.core.text.VisualToLogical
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** A horizontal run of glyphs in visual order (one "piece" of a printed line). */
class TextLine(val glyphs: List<Glyph>) {
    val box: Box = Box.of(glyphs.map { it.box })!!
    val baseline: Float = glyphs.map { it.baseline }.medianOr(box.bottom)
    val size: Float = dominantSize(glyphs)
    var logical: LogicalLine? = null

    companion object {
        fun dominantSize(gs: List<Glyph>): Float {
            val counts = HashMap<Int, Int>()
            for (g in gs) if (g.vertAlign == 0) counts.merge((g.style.size * 2).toInt(), g.text.length, Int::plus)
            val best = counts.maxByOrNull { it.value }?.key ?: return gs.map { it.style.size }.medianOr(10f)
            return best / 2f
        }
    }
}

/** A styled fragment of logical text. */
class Span(val text: String, val style: TextStyle, val rtl: Boolean, val underline: Boolean, val highlight: Int?, val vertAlign: Int, val fakeBold: Boolean)

class LogicalLine(
    val text: String,
    val spans: List<Span>,
    val rtl: Boolean,
    /** Line has at least one strong letter (otherwise direction came from context). */
    val hasLetters: Boolean,
    val minConfidence: Float,
    val boldFraction: Float,
)

object LineGrouper {

    /** Normalise glyph text, drop whitespace, dedupe fake-bold overprints, attach Arabic marks. */
    fun prepare(raw: List<Glyph>): List<Glyph> {
        val cleaned = ArrayList<Glyph>(raw.size)
        for (g in raw) {
            val t = if (g.isWord) g.text.trim() else UnicodeText.normalizeGlyphText(g.text)
            if (t.isBlank()) continue
            if (g.box.width <= 0f && g.box.height <= 0f) continue
            cleaned += if (t == g.text) g else Glyph(t, g.box, g.baseline, g.style, g.isWord, g.confidence)
        }
        // Dedupe overprinted glyphs (fake bold / shadows).
        val sorted = cleaned.sortedWith(compareBy({ it.baseline }, { it.box.x0 }))
        val out = ArrayList<Glyph>(sorted.size)
        val recent = ArrayDeque<Glyph>()
        for (g in sorted) {
            var dup: Glyph? = null
            for (r in recent) {
                if (r.text == g.text && abs(r.box.x0 - g.box.x0) < 0.12f * g.style.size + 0.3f && abs(r.baseline - g.baseline) < 0.12f * g.style.size + 0.3f) { dup = r; break }
            }
            if (dup != null) { dup.fakeBold = true; continue }
            out += g
            recent.addLast(g)
            if (recent.size > 24) recent.removeFirst()
        }
        // Zero-advance glyphs sitting on Arabic letters are diacritics whose Unicode
        // mapping is broken in the PDF (they often decode as "-" or "t"): drop them.
        val zeroWidth = out.filter { g ->
            !g.isWord && g.text.length == 1 && g.box.width < 0.04f * max(g.style.size, 3f) &&
                UnicodeText.bidiClassOf(g.text) != BidiClass.NSM && !g.text[0].isDigit()
        }
        if (zeroWidth.isNotEmpty()) {
            val drop = HashSet<Glyph>()
            for (z in zeroWidth) {
                val s = max(z.style.size, 3f)
                val onArabic = out.any { o ->
                    o !== z && o.text.any { UnicodeText.isArabicLetter(it.code) } &&
                        z.box.cx >= o.box.x0 - 0.25f * s && z.box.cx <= o.box.x1 + 0.25f * s && abs(o.baseline - z.baseline) < 0.8f * s
                }
                if (onArabic) drop += z
            }
            if (drop.isNotEmpty()) out.removeAll(drop)
        }
        // Attach combining marks (harakat) to their base glyph.
        val marks = out.filter { !it.isWord && UnicodeText.bidiClassOf(it.text) == BidiClass.NSM }
        if (marks.isEmpty()) return out
        val markSet = marks.toHashSet()
        val bases = out.filter { it !in markSet }
        val extra = HashMap<Glyph, StringBuilder>()
        val unattached = ArrayList<Glyph>()
        for (m in marks) {
            val c = m.box.cx
            val tol = 0.6f * m.style.size
            val base = bases.asSequence()
                .filter { abs(it.baseline - m.baseline) < tol && c >= it.box.x0 - 0.5f && c <= it.box.x1 + 0.5f }
                .minByOrNull { abs(it.box.cx - c) }
            if (base != null) extra.getOrPut(base) { StringBuilder() }.append(m.text) else unattached += m
        }
        val result = ArrayList<Glyph>(bases.size + unattached.size)
        for (b in bases) {
            val add = extra[b]
            result += if (add == null) b else Glyph(b.text + add, b.box, b.baseline, b.style, b.isWord, b.confidence).also { it.fakeBold = b.fakeBold }
        }
        // Unattached marks are dropped only if they would be meaningless alone.
        return result
    }

    /** Group glyphs into full-width visual lines by baseline. */
    fun groupLines(glyphs: List<Glyph>): List<List<Glyph>> {
        if (glyphs.isEmpty()) return emptyList()
        val sorted = glyphs.sortedWith(compareBy({ it.baseline }, { it.box.x0 }))
        class L(var baseline: Float, var size: Float, val items: MutableList<Glyph>, var top: Float, var bottom: Float)
        val lines = ArrayList<L>()
        for (g in sorted) {
            var best: L? = null
            var bestD = Float.MAX_VALUE
            for (k in lines.indices.reversed()) {
                val l = lines[k]
                if (g.baseline - l.baseline > 2f * max(l.size, g.style.size)) break
                val tol = 0.32f * max(min(l.size, g.style.size), 3f)
                val d = abs(g.baseline - l.baseline)
                if (d <= tol && d < bestD) { best = l; bestD = d }
            }
            if (best == null) lines += L(g.baseline, g.style.size, mutableListOf(g), g.box.top, g.box.bottom)
            else {
                best.items += g
                best.size = max(best.size, g.style.size)
                best.top = min(best.top, g.box.top); best.bottom = max(best.bottom, g.box.bottom)
            }
        }
        // Merge superscript / subscript fragments into the line they decorate.
        val merged = ArrayList<L>()
        val absorbed = HashSet<L>()
        for (l in lines) {
            val maxSize = l.items.maxOf { it.style.size }
            if (l.items.size <= 6) {
                val host = lines.filter { it !== l && it !in absorbed && it.items.size > l.items.size }
                    .filter { h ->
                        val hs = TextLine.dominantSize(h.items)
                        maxSize <= 0.82f * hs &&
                            l.bottom > h.top && l.top < h.bottom &&
                            l.items.minOf { it.box.x0 } < h.items.maxOf { it.box.x1 } + hs &&
                            l.items.maxOf { it.box.x1 } > h.items.minOf { it.box.x0 } - hs
                    }
                    .minByOrNull { abs(it.baseline - l.baseline) }
                if (host != null) {
                    val hs = TextLine.dominantSize(host.items)
                    for (g in l.items) g.vertAlign = if (g.baseline < host.baseline - 0.15f * hs) 1 else if (g.baseline > host.baseline + 0.1f * hs) -1 else 0
                    host.items += l.items
                    absorbed += l
                    continue
                }
            }
        }
        for (l in lines) if (l !in absorbed) merged += l
        return merged.map { cleanArtifacts(it.items.sortedBy { g -> g.box.x0 }) }.filter { it.isNotEmpty() }
            .sortedBy { it.map { g -> g.baseline }.medianOr(0f) }
    }

    /**
     * Removes extraction artefacts common in Arabic PDFs: justification kashidas
     * (tatweel, or glyphs without a Unicode mapping that decode as "?") and
     * zero-advance mark glyphs that were mis-mapped to ASCII characters.
     */
    fun cleanArtifacts(line: List<Glyph>): List<Glyph> {
        if (line.none { UnicodeText.hasArabic(it.text) }) return line
        fun arabicAt(i: Int) = i in line.indices && line[i].text.any { UnicodeText.isArabicLetter(it.code) }
        val out = ArrayList<Glyph>(line.size)
        // Dropping a kashida must not leave a visual gap (which would become a space).
        fun absorb(g: Glyph) {
            val last = out.lastOrNull() ?: return
            if (g.box.x1 > last.box.x1) {
                out[out.size - 1] = Glyph(last.text, Box(last.box.x0, last.box.top, g.box.x1, last.box.bottom), last.baseline, last.style, last.isWord, last.confidence)
                    .also { it.fakeBold = last.fakeBold; it.underline = last.underline; it.highlight = last.highlight; it.vertAlign = last.vertAlign }
            }
        }
        for ((i, g) in line.withIndex()) {
            if (g.isWord) { out += g; continue }
            val t = g.text
            if (t == "\u0640") { absorb(g); continue }
            val size = max(g.style.size, 3f)
            if (g.box.width < 0.04f * size && t.length == 1 && UnicodeText.bidiClassOf(t) != BidiClass.NSM && !t[0].isDigit()) {
                val overlapsArabic = line.any { o -> o !== g && UnicodeText.hasArabic(o.text) && g.box.cx >= o.box.x0 - 1f && g.box.cx <= o.box.x1 + 1f }
                if (overlapsArabic) continue
            }
            if (t == "?") {
                var a = i - 1; while (a >= 0 && line[a].text == "?") a--
                var b = i + 1; while (b < line.size && line[b].text == "?") b++
                if (arabicAt(a) && arabicAt(b) && line[b].box.x0 - line[a].box.x1 < 2.5f * size) { absorb(g); continue }
            }
            out += g
        }
        return out
    }

    /** Split a visual line into pieces at large horizontal gaps. */
    fun splitPieces(line: List<Glyph>, gapFactor: Float = 1.6f): List<TextLine> {
        if (line.isEmpty()) return emptyList()
        val size = TextLine.dominantSize(line)
        val pieces = ArrayList<TextLine>()
        var cur = ArrayList<Glyph>()
        var lastX1 = Float.NEGATIVE_INFINITY
        for (g in line) {
            val gap = g.box.x0 - lastX1
            if (cur.isNotEmpty() && gap > gapFactor * max(size, 4f)) {
                pieces += TextLine(cur); cur = ArrayList()
            }
            cur += g
            lastX1 = max(lastX1, g.box.x1)
        }
        if (cur.isNotEmpty()) pieces += TextLine(cur)
        if (pieces.size < 2) return pieces
        // Re-attach list markers (bullets / "1." / "أ)") that sit apart from their text.
        val merged = ArrayList<TextLine>()
        for (p in pieces) {
            val last = merged.lastOrNull()
            if (last != null && (isMarkerPiece(last) || isMarkerPiece(p)) && p.box.x0 - last.box.x1 < 4f * max(size, 4f)) {
                merged[merged.size - 1] = TextLine(last.glyphs + p.glyphs)
            } else merged += p
        }
        return merged
    }

    private val markerText = Regex("^([\\u2022\\u25CF\\u25CB\\u25E6\\u25AA\\u25A0\\u2023\\u27A2\\u27A4\\u25BA\\u2713\\u2714\\u00B7\\u2219\\uF0B7\\uF0A7\\uF076\\uF0D8\\uF0FC\\uF0A8\\uF06E]|\\([0-9\\u0660-\\u0669]{1,3}\\)|[0-9\\u0660-\\u0669]{1,3}[.)\\-]|\\(?[a-zA-Z\\u0621-\\u064A][.)])$")

    fun isMarkerPiece(p: TextLine): Boolean {
        val t = p.glyphs.joinToString("") { it.text }.trim()
        if (t.isEmpty() || t.length > 5) return false
        if (t.length == 1 && UnicodeText.bulletChars.contains(t[0].code)) return true
        // Numeric/letter markers may be visually reversed at this stage, so test both orders.
        return markerText.matches(t) || markerText.matches(t.reversed().map { UnicodeText.mirror(it.toString()) }.joinToString(""))
    }

    /** Mark underlines and highlights using nearby vector graphics. */
    fun decorate(glyphs: List<Glyph>, segments: List<Segment>, fills: List<FillRect>, excluded: List<Box>) {
        val hsegs = segments.filter { it.isHorizontal && excluded.none { b -> b.contains(it.box.cx, it.box.cy, 1f) } }
        if (hsegs.isNotEmpty()) {
            for (g in glyphs) {
                val s = g.style.size
                for (seg in hsegs) {
                    val y = (seg.y0 + seg.y1) / 2
                    if (y >= g.baseline - 0.05f * s && y <= g.baseline + 0.3f * s &&
                        min(seg.x0, seg.x1) <= g.box.x0 + 0.3f * g.box.width && max(seg.x0, seg.x1) >= g.box.x1 - 0.3f * g.box.width
                    ) { g.underline = true; break }
                }
            }
        }
        val hl = fills.filter { f -> !isWhite(f.color) && excluded.none { it.intersectionArea(f.box) > 0.5f * f.box.area } }
        if (hl.isNotEmpty()) {
            for (g in glyphs) {
                val s = g.style.size
                for (f in hl) {
                    if (f.box.height < 2.6f * s && f.box.contains(g.box.cx, (g.box.top + g.baseline) / 2)) { g.highlight = f.color; break }
                }
            }
        }
    }

    fun isWhite(c: Int): Boolean = ((c shr 16) and 0xFF) > 245 && ((c shr 8) and 0xFF) > 245 && (c and 0xFF) > 245

    /** Text-unit used for bidi reordering. */
    private class Unit(val text: String, val glyph: Glyph?, val style: TextStyle, val cls: BidiClass)

    /** Converts a visual line to logical text with styled spans. */
    fun toLogical(line: TextLine, contextRtl: Boolean): LogicalLine {
        val gs = line.glyphs
        val size = line.size
        val units = ArrayList<Unit>(gs.size * 2)
        var prev: Glyph? = null
        for (g in gs) {
            if (prev != null) {
                val gap = g.box.x0 - prev.box.x1
                val threshold = if (g.isWord || prev.isWord) -0.15f * size else 0.17f * max(min(prev.style.size, g.style.size), 3f)
                val st = if (g.style.size >= prev.style.size) g.style else prev.style
                if (gap > 1.5f * max(size, 4f)) units += Unit("\t", null, st, BidiClass.WS)
                else if (gap > threshold) units += Unit(" ", null, st, BidiClass.WS)
            }
            units += Unit(g.text, g, g.style, UnicodeText.bidiClassOf(g.text))
            prev = g
        }
        val text0 = gs.joinToString("") { it.text }
        val counts = UnicodeText.countLetters(text0)
        val hasLetters = counts.arabic + counts.latin > 0
        val rtl = if (hasLetters) counts.arabic > counts.latin else contextRtl

        val placed = VisualToLogical.reorder(units, { it.cls }, { it.text }, rtl)
        val spans = ArrayList<Span>()
        val sb = StringBuilder()
        var minConf = 100f
        var boldChars = 0; var totalChars = 0
        // Build spans: merge consecutive units with same formatting and direction.
        var curText = StringBuilder()
        var curKey: SpanKey? = null
        var curUnit: Unit? = null
        fun flush() {
            val k = curKey ?: return
            val u = curUnit!!
            spans += Span(curText.toString(), u.style, k.rtl, k.underline, k.highlight, k.vert, k.fakeBold)
            curText = StringBuilder(); curKey = null
        }
        for (p in placed) {
            val u = p.item
            val t = if (p.mirrored) UnicodeText.mirror(u.text) else u.text
            sb.append(t)
            val g = u.glyph
            if (g != null) {
                minConf = min(minConf, g.confidence)
                val n = t.length
                totalChars += n
                if (g.style.bold || g.fakeBold) boldChars += n
            }
            val isRtlRun = p.level % 2 == 1
            val key = SpanKey(
                styleKey(u.style), isRtlRun, g?.underline ?: (curKey?.underline ?: false), g?.highlight ?: curKey?.highlight,
                g?.vertAlign ?: 0, g?.fakeBold ?: (curKey?.fakeBold ?: false)
            )
            // Spaces join the current span if the direction matches, to avoid run explosion.
            if (g == null && curKey != null && curKey!!.rtl == isRtlRun) { curText.append(t); continue }
            if (curKey != key) { flush(); curKey = key; curUnit = u }
            curText.append(t)
        }
        flush()
        return LogicalLine(sb.toString(), spans, rtl, hasLetters, minConf, if (totalChars == 0) 0f else boldChars.toFloat() / totalChars)
    }

    private data class SpanKey(val style: String, val rtl: Boolean, val underline: Boolean, val highlight: Int?, val vert: Int, val fakeBold: Boolean)

    private fun styleKey(s: TextStyle) = "${s.fontName}|${(s.size * 2).toInt()}|${s.bold}|${s.italic}|${s.color}"
}
