package com.ayman.pdfword.core.raster

import com.ayman.pdfword.core.model.Segment

/**
 * Pure-Kotlin raster helpers for scanned pages: Otsu binarisation and detection
 * of long horizontal/vertical strokes (table rulings) so scanned tables can be
 * rebuilt with the same pipeline as digital ones.
 */
object RasterAnalysis {

    /** Otsu threshold for an 8-bit grayscale buffer. */
    fun otsu(gray: ByteArray): Int {
        val hist = IntArray(256)
        for (b in gray) hist[b.toInt() and 0xFF]++
        val total = gray.size
        var sum = 0.0
        for (i in 0 until 256) sum += i * hist[i].toDouble()
        var sumB = 0.0; var wB = 0; var best = 0.0; var threshold = 128
        for (t in 0 until 256) {
            wB += hist[t]
            if (wB == 0) continue
            val wF = total - wB
            if (wF == 0) break
            sumB += t * hist[t].toDouble()
            val mB = sumB / wB
            val mF = (sum - sumB) / wF
            val between = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (between > best) { best = between; threshold = t }
        }
        return threshold
    }

    /**
     * Finds ruling lines in a grayscale image. Coordinates of returned segments are
     * converted to page points using [scale] (points per pixel).
     */
    fun detectRulings(gray: ByteArray, width: Int, height: Int, scale: Float): List<Segment> {
        if (width <= 0 || height <= 0) return emptyList()
        val th = otsu(gray).coerceIn(60, 200)
        val dark = BooleanArray(gray.size) { (gray[it].toInt() and 0xFF) < th }
        val out = ArrayList<Segment>()
        val minH = maxOf(30, (width * 0.04).toInt())
        val minV = maxOf(20, (height * 0.025).toInt())

        // Horizontal runs per row, then merge vertically adjacent rows (thick lines).
        data class Run(val y: Int, val x0: Int, val x1: Int)
        val hRuns = ArrayList<Run>()
        for (y in 0 until height) {
            var x = 0
            val row = y * width
            while (x < width) {
                if (dark[row + x]) {
                    var e = x; var gaps = 0
                    while (e + 1 < width && (dark[row + e + 1] || (gaps < 2 && e + 2 < width && dark[row + e + 2]))) {
                        if (!dark[row + e + 1]) gaps++ else gaps = 0
                        e++
                    }
                    if (e - x + 1 >= minH) hRuns += Run(y, x, e)
                    x = e + 1
                } else x++
            }
        }
        out += mergeRuns(hRuns.map { Triple(it.y, it.x0, it.x1) }, scale, horizontal = true)

        val vRuns = ArrayList<Triple<Int, Int, Int>>()
        for (x in 0 until width) {
            var y = 0
            while (y < height) {
                if (dark[y * width + x]) {
                    var e = y; var gaps = 0
                    while (e + 1 < height && (dark[(e + 1) * width + x] || (gaps < 2 && e + 2 < height && dark[(e + 2) * width + x]))) {
                        if (!dark[(e + 1) * width + x]) gaps++ else gaps = 0
                        e++
                    }
                    if (e - y + 1 >= minV) vRuns += Triple(x, y, e)
                    y = e + 1
                } else y++
            }
        }
        out += mergeRuns(vRuns, scale, horizontal = false)
        return out
    }

    /** Merge parallel runs at adjacent positions into single (possibly thick) segments. */
    private fun mergeRuns(runs: List<Triple<Int, Int, Int>>, scale: Float, horizontal: Boolean): List<Segment> {
        val sorted = runs.sortedWith(compareBy({ it.first }, { it.second }))
        class Acc(var p0: Int, var p1: Int, var a: Int, var b: Int)
        val accs = ArrayList<Acc>()
        val out = ArrayList<Segment>()
        for ((p, a, b) in sorted) {
            val m = accs.firstOrNull { p - it.p1 <= 1 && a <= it.b + 3 && b >= it.a - 3 }
            if (m != null) { m.p1 = p; m.a = minOf(m.a, a); m.b = maxOf(m.b, b) } else accs += Acc(p, p, a, b)
        }
        for (acc in accs) {
            val thick = acc.p1 - acc.p0 + 1
            // Very thick dark bands are filled shapes or images, not rulings.
            if (thick * scale > 4f) continue
            val mid = (acc.p0 + acc.p1) / 2f * scale
            out += if (horizontal) Segment(acc.a * scale, mid, acc.b * scale, mid, thick * scale, 0)
            else Segment(mid, acc.a * scale, mid, acc.b * scale, thick * scale, 0)
        }
        return out
    }
}
