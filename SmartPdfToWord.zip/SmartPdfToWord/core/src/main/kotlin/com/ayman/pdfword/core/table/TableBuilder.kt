package com.ayman.pdfword.core.table

import com.ayman.pdfword.core.doc.ParagraphBlock
import com.ayman.pdfword.core.doc.TableBlock
import com.ayman.pdfword.core.doc.TableCell
import com.ayman.pdfword.core.layout.BuildContext
import com.ayman.pdfword.core.layout.LineGrouper
import com.ayman.pdfword.core.layout.ParagraphBuilder
import com.ayman.pdfword.core.layout.TextLine
import com.ayman.pdfword.core.text.UnicodeText
import kotlin.math.abs
import kotlin.math.max

/** Turns a detected table (with assigned glyphs/lines) into an editable table block. */
object TableBuilder {


    fun build(t: DetectedTable, ctx: BuildContext, bodySize: Float, pageRtl: Boolean, marginLeft: Float, marginRight: Float, floating: Boolean): TableBlock {
        // Word's default cell padding for ruled tables; borderless tables need tight cells.
        val CELL_PAD = if (t.bordered) 5.4f else 1.5f
        // Lines per cell.
        val cellLines = HashMap<DetectedCell, List<TextLine>>()
        var arabic = 0; var latin = 0
        for (cell in t.cells) {
            val lines: List<TextLine> = if (cell.lines.isNotEmpty()) {
                // Alignment tables: merge pieces sharing a baseline.
                cell.lines.sortedBy { it.baseline }
            } else {
                LineGrouper.groupLines(cell.glyphs).flatMap { LineGrouper.splitPieces(it, gapFactor = 1000f) }
            }
            val text = lines.joinToString(" ") { l -> l.glyphs.joinToString("") { it.text } }
            val c = UnicodeText.countLetters(text)
            arabic += c.arabic; latin += c.latin
            cellLines[cell] = lines
        }
        val rtl = if (arabic + latin == 0) pageRtl else arabic > latin

        val cells = ArrayList<TableCell>()
        for (cell in t.cells) {
            val lines = cellLines[cell] ?: emptyList()
            for (l in lines) l.logical = LineGrouper.toLogical(l, rtl)
            val b = cell.box
            val pb = ParagraphBuilder(
                ctx, bodySize,
                marginLeft = b.x0 + CELL_PAD, marginRight = b.x1 - CELL_PAD,
                contentLeft = b.x0 + CELL_PAD, contentRight = b.x1 - CELL_PAD,
                allowHeadings = false, allowLists = true,
            )
            val paras: List<ParagraphBlock> = pb.build(lines, null, null).mapIndexed { i, p ->
                if (i == 0) p.copy(props = p.props.copy(spaceBeforePt = 0f, keepNext = false)) else p.copy(props = p.props.copy(keepNext = false))
            }
            var vCenter = false
            if (lines.isNotEmpty()) {
                val top = lines.minOf { it.box.top } - b.top
                val bottom = b.bottom - lines.maxOf { it.box.bottom }
                val textH = lines.maxOf { it.box.bottom } - lines.minOf { it.box.top }
                vCenter = b.height > 1.8f * textH && abs(top - bottom) < max(3f, 0.25f * b.height) && top > 3f
            }
            cells += TableCell(cell.r, cell.c, cell.rs, cell.cs, paras, cell.shading, cell.borders, vCenter)
        }
        val colWidths = (0 until t.cols).map { t.xs[it + 1] - t.xs[it] }
        val rowHeights = (0 until t.rows).map { t.ys[it + 1] - t.ys[it] }
        return TableBlock(
            id = ctx.id("t"),
            top = t.box.top,
            box = t.box,
            colWidths = colWidths,
            rowHeights = rowHeights,
            cells = cells,
            rtl = rtl,
            bordered = t.bordered,
            borderColor = t.borderColor,
            indentPt = if (rtl) marginRight - t.box.x1 else t.box.x0 - marginLeft,
            floating = floating,
            detection = t.detection,
            cellMarginPt = CELL_PAD,
        )
    }
}
