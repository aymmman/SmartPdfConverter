package com.ayman.pdfword.core

import com.ayman.pdfword.core.doc.DocModel
import com.ayman.pdfword.core.doc.PageLayout
import com.ayman.pdfword.core.doc.ParagraphBlock
import com.ayman.pdfword.core.doc.Run
import com.ayman.pdfword.core.doc.TableBlock
import com.ayman.pdfword.core.layout.BuildContext
import com.ayman.pdfword.core.layout.PageLayoutEngine
import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.ImageInput
import com.ayman.pdfword.core.model.PageInput
import com.ayman.pdfword.core.report.ConversionReport
import com.ayman.pdfword.core.report.FontEntry
import com.ayman.pdfword.core.report.PageStats
import kotlin.math.ceil

/**
 * Accumulates page layouts one page at a time (so callers can stream large PDFs)
 * and produces the final [DocModel] and [ConversionReport].
 */
class DocumentAssembler(val options: ConversionOptions, private val sourceName: String, private val totalPages: Int) {
    private val ctx = BuildContext(options)
    private val engine = PageLayoutEngine(ctx)
    private val pages = ArrayList<PageLayout>()
    private val stats = ArrayList<PageStats>()
    private val extraWarnings = ArrayList<String>()
    private val startedAt = System.currentTimeMillis()

    fun figureRegions(page: PageInput): List<Box> = engine.detectFigureRegions(page)

    fun addPage(page: PageInput, figureImages: List<ImageInput> = emptyList()) {
        val r = engine.layout(page, figureImages)
        pages += r.layout
        stats += r.stats
    }

    /** Records a page that could not be processed; a visible placeholder is inserted. */
    fun addFailedPage(index: Int, width: Float, height: Float, reason: String) {
        val p = ParagraphBlock(
            id = ctx.id("p"),
            runs = listOf(Run("[Page ${index + 1} could not be converted: $reason]", ctx.fontMapper.defaultLatinFont, ctx.fontMapper.defaultArabicFont, 11f, true, false, 0xC00000, false)),
            props = com.ayman.pdfword.core.doc.ParaProps(rtl = false),
            top = 72f,
        )
        pages += PageLayout(index, width, height, com.ayman.pdfword.core.doc.Margins(72f, 72f, 72f, 72f), listOf(com.ayman.pdfword.core.doc.SectionPart(1, false, listOf(p))), false)
        stats += PageStats(index + 1, "FAILED", false, null, 0f, 0, 0, 0, 0, false, 0, listOf("conversion failed"), listOf(reason), failed = true)
    }

    fun warn(message: String) { extraWarnings += message }

    val pageCount: Int get() = pages.size

    fun finish(): Pair<DocModel, ConversionReport> {
        var header = emptyList<ParagraphBlock>()
        var footer = emptyList<ParagraphBlock>()
        var finalPages: List<PageLayout> = pages
        if (options.detectHeadersFooters && options.mode == ConversionMode.EDITABLE && pages.size >= 2) {
            val result = extractHeaderFooter(pages)
            header = result.first; footer = result.second; finalPages = result.third
        } else {
            finalPages = pages.map { stripMarginalKeys(it) }
        }
        finalPages = rankHeadings(finalPages).map { pinMarginals(it) }
        var rtlChars = 0; var pagesRtl = 0
        for (p in finalPages) if (p.rtlDominant) pagesRtl++ else rtlChars++
        val docRtl = pagesRtl > finalPages.size / 2

        val model = DocModel(
            pages = finalPages,
            header = header,
            footer = footer,
            numbering = ctx.numbering.toList(),
            defaultLatinFont = options.defaultLatinFont,
            defaultCsFont = options.defaultArabicFont,
            title = sourceName.substringBeforeLast('.'),
            rtlDominant = docRtl,
        )
        return model to buildReport(finalPages)
    }

    private fun stripMarginalKeys(p: PageLayout) = p

    private fun extractHeaderFooter(pages: List<PageLayout>): Triple<List<ParagraphBlock>, List<ParagraphBlock>, List<PageLayout>> {
        val topCounts = HashMap<String, Int>()
        val bottomCounts = HashMap<String, Int>()
        for (p in pages) {
            val seen = HashSet<String>()
            for (part in p.parts) for (b in part.blocks) {
                if (b is ParagraphBlock && b.marginalKey != null) {
                    val k = (if (b.marginalTop) "T|" else "B|") + b.marginalKey
                    if (seen.add(k)) (if (b.marginalTop) topCounts else bottomCounts).merge(b.marginalKey, 1, Int::plus)
                }
            }
        }
        val need = maxOf(2, ceil(pages.size * 0.5).toInt())
        val topKeys = topCounts.filter { it.value >= need }.keys
        val bottomKeys = bottomCounts.filter { it.value >= need }.keys
        if (topKeys.isEmpty() && bottomKeys.isEmpty()) return Triple(emptyList(), emptyList(), pages)

        // Collect occurrences per key to decide which numbers vary (page numbers).
        val occurrences = HashMap<String, MutableList<Pair<Int, ParagraphBlock>>>()
        for (p in pages) for (part in p.parts) for (b in part.blocks) {
            if (b is ParagraphBlock && b.marginalKey != null) {
                val inSet = if (b.marginalTop) b.marginalKey in topKeys else b.marginalKey in bottomKeys
                if (inSet) occurrences.getOrPut((if (b.marginalTop) "T|" else "B|") + b.marginalKey) { mutableListOf() } += p.pageIndex to b
            }
        }
        fun template(key: String): ParagraphBlock {
            val occ = occurrences[key]!!
            val first = occ.first().second
            val numberSets = occ.map { (_, b) -> digitRegex.findAll(b.text).map { it.value }.toList() }
            val groups = numberSets.first().size
            val fields = (0 until groups).map { gi ->
                val values = numberSets.mapNotNull { it.getOrNull(gi)?.let { v -> parseNum(v) } }
                when {
                    values.toSet().size > 1 -> "PAGE"
                    values.isNotEmpty() && values.first() == pages.size && pages.size > 1 -> "NUMPAGES"
                    else -> null
                }
            }
            val runs = replaceNumbersWithFields(first.runs, fields)
            return first.copy(runs = runs, props = first.props.copy(spaceBeforePt = 0f, keepNext = false), marginalKey = null)
        }
        val headerParas = occurrences.keys.filter { it.startsWith("T|") }
            .map { it to occurrences[it]!!.first().second.top }.sortedBy { it.second }.map { template(it.first) }
        val footerParas = occurrences.keys.filter { it.startsWith("B|") }
            .map { it to occurrences[it]!!.first().second.top }.sortedBy { it.second }.map { template(it.first) }

        val cleaned = pages.map { p ->
            p.copy(parts = p.parts.map { part ->
                part.copy(blocks = part.blocks.filterNot { b ->
                    b is ParagraphBlock && b.marginalKey != null &&
                        (if (b.marginalTop) b.marginalKey in topKeys else b.marginalKey in bottomKeys)
                })
            })
        }
        return Triple(headerParas, footerParas, cleaned)
    }

    /** Margin-zone lines that did not become header/footer keep their exact position as frames. */
    private fun pinMarginals(p: PageLayout): PageLayout = p.copy(parts = p.parts.map { part ->
        part.copy(blocks = part.blocks.map { b ->
            if (b is ParagraphBlock && b.marginalKey != null && b.box != null) b.copy(frame = com.ayman.pdfword.core.doc.Placement(b.box), marginalKey = null) else b
        })
    })

    /** Assigns Heading 1/2/3 by ranking the distinct heading sizes found in the whole document. */
    private fun rankHeadings(pages: List<PageLayout>): List<PageLayout> {
        val sizes = pages.flatMap { p -> p.parts.flatMap { it.blocks } }
            .filterIsInstance<ParagraphBlock>().filter { it.props.headingLevel > 0 }
            .map { Math.round(it.fontSize) }.toSortedSet().reversed()
        if (sizes.isEmpty()) return pages
        val levelOf = sizes.withIndex().associate { (i, s) -> s to minOf(i + 1, 3) }
        return pages.map { p ->
            p.copy(parts = p.parts.map { part ->
                part.copy(blocks = part.blocks.map { b ->
                    if (b is ParagraphBlock && b.props.headingLevel > 0) b.copy(props = b.props.copy(headingLevel = levelOf[Math.round(b.fontSize)] ?: 3)) else b
                })
            })
        }
    }

    private fun parseNum(s: String): Int? {
        var v = 0
        for (c in s) { val d = Character.digit(c, 10); if (d < 0) return null; v = v * 10 + d; if (v > 1_000_000) return null }
        return v
    }

    private fun replaceNumbersWithFields(runs: List<Run>, fields: List<String?>): List<Run> {
        if (fields.all { it == null }) return runs
        val out = ArrayList<Run>()
        var group = 0
        for (r in runs) {
            var last = 0
            for (m in digitRegex.findAll(r.text)) {
                val f = fields.getOrNull(group++)
                if (f == null) continue
                if (m.range.first > last) out += r.copy(text = r.text.substring(last, m.range.first))
                out += r.copy(text = m.value, field = f, rtl = false)
                last = m.range.last + 1
            }
            if (last < r.text.length) out += r.copy(text = r.text.substring(last))
        }
        return out
    }

    private fun buildReport(finalPages: List<PageLayout>): ConversionReport {
        val ocrPages = stats.filter { it.ocrApplied }.map { it.pageNumber }
        val confs = stats.mapNotNull { it.ocrConfidence }
        val textQ = stats.filter { !it.ocrApplied && !it.failed && it.kind != "EMPTY" }.map { it.textQuality }
        val fonts = ctx.fontUsage.map { (src, r) -> FontEntry(src, r.family, r.status.name) }
        val uncertain = stats.flatMap { s -> s.uncertainReasons.map { s.pageNumber to it } }
        val ocrWarnings = ArrayList<String>()
        for (s in stats) {
            val c = s.ocrConfidence
            if (s.ocrApplied && c != null && c < 75f) ocrWarnings += "Page ${s.pageNumber}: low OCR confidence (${c.toInt()}%)"
        }
        val review = ArrayList<String>()
        for (p in finalPages) for (part in p.parts) for (b in part.blocks) {
            when (b) {
                is ParagraphBlock -> if (b.needsReview) review += "Page ${p.pageIndex + 1}: \"${b.text.take(60)}\""
                is TableBlock -> if (b.cells.any { c -> c.paragraphs.any { it.needsReview } }) review += "Page ${p.pageIndex + 1}: table cells with uncertain OCR text"
                else -> {}
            }
        }
        val warnings = ArrayList<String>()
        warnings += extraWarnings
        stats.forEach { s -> s.warnings.forEach { warnings += "Page ${s.pageNumber}: $it" } }
        if (fonts.any { it.status == "KEPT_UNVERIFIED" }) warnings += "Some original fonts were kept by name; if they are not installed on the viewing device, Word will display a substitute."
        if (fonts.any { it.status == "SUBSTITUTED" }) warnings += "Some fonts were substituted because the original font could not be identified or is not a standard Word font."
        return ConversionReport(
            sourceName = sourceName,
            mode = options.mode.name,
            totalPages = totalPages,
            pagesProcessed = stats.count { !it.failed },
            pagesFailed = stats.filter { it.failed }.map { it.pageNumber },
            ocrPages = ocrPages,
            averageOcrConfidence = if (confs.isEmpty()) null else confs.average().toFloat(),
            textLayerQuality = if (textQ.isEmpty()) null else textQ.average().toFloat(),
            fonts = fonts,
            tablesDetected = stats.sumOf { it.rulingTables + it.borderlessTables },
            borderlessTables = stats.sumOf { it.borderlessTables },
            imagesDetected = stats.sumOf { it.images },
            figuresRasterized = stats.sumOf { it.figuresRasterized },
            uncertainPages = uncertain,
            ocrWarnings = ocrWarnings,
            reviewItems = review,
            warnings = warnings,
            durationMs = System.currentTimeMillis() - startedAt,
        )
    }

    companion object {
        private val digitRegex = Regex("[0-9\\u0660-\\u0669\\u06F0-\\u06F9]+")
    }
}
