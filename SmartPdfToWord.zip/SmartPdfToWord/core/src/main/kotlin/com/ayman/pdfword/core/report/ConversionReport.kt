package com.ayman.pdfword.core.report

/** Per-page facts gathered during layout. */
data class PageStats(
    val pageNumber: Int,
    val kind: String,
    val ocrApplied: Boolean,
    val ocrConfidence: Float?,
    val textQuality: Float,
    val rulingTables: Int,
    val borderlessTables: Int,
    val images: Int,
    val figuresRasterized: Int,
    val twoColumns: Boolean,
    val reviewParagraphs: Int,
    val uncertainReasons: List<String>,
    val warnings: List<String>,
    val failed: Boolean = false,
)

data class FontEntry(val source: String, val used: String, val status: String)

data class ConversionReport(
    val sourceName: String,
    val mode: String,
    val totalPages: Int,
    val pagesProcessed: Int,
    val pagesFailed: List<Int>,
    val ocrPages: List<Int>,
    val averageOcrConfidence: Float?,
    val textLayerQuality: Float?,
    val fonts: List<FontEntry>,
    val tablesDetected: Int,
    val borderlessTables: Int,
    val imagesDetected: Int,
    val figuresRasterized: Int,
    val uncertainPages: List<Pair<Int, String>>,
    val ocrWarnings: List<String>,
    val reviewItems: List<String>,
    val warnings: List<String>,
    val durationMs: Long,
) {
    val fontsPreserved get() = fonts.filter { it.status == "PRESERVED" || it.status == "USER_RULE" }
    val fontsSubstituted get() = fonts.filter { it.status == "SUBSTITUTED" || it.status == "ESTIMATED" }
    val fontsUnverified get() = fonts.filter { it.status == "KEPT_UNVERIFIED" }

    /** Minimal JSON writer (no external dependency). */
    fun toJson(): String {
        val sb = StringBuilder()
        sb.append('{')
        fun k(name: String) { if (sb.length > 1) sb.append(','); sb.append(q(name)).append(':') }
        k("sourceName"); sb.append(q(sourceName))
        k("mode"); sb.append(q(mode))
        k("totalPages"); sb.append(totalPages)
        k("pagesProcessed"); sb.append(pagesProcessed)
        k("pagesFailed"); sb.append(pagesFailed.joinToString(",", "[", "]"))
        k("ocrPages"); sb.append(ocrPages.joinToString(",", "[", "]"))
        k("averageOcrConfidence"); sb.append(averageOcrConfidence?.let { fmt(it) } ?: "null")
        k("textLayerQuality"); sb.append(textLayerQuality?.let { fmt(it) } ?: "null")
        k("fonts"); sb.append(fonts.joinToString(",", "[", "]") { "{\"source\":${q(it.source)},\"used\":${q(it.used)},\"status\":${q(it.status)}}" })
        k("tablesDetected"); sb.append(tablesDetected)
        k("borderlessTables"); sb.append(borderlessTables)
        k("imagesDetected"); sb.append(imagesDetected)
        k("figuresRasterized"); sb.append(figuresRasterized)
        k("uncertainPages"); sb.append(uncertainPages.joinToString(",", "[", "]") { "{\"page\":${it.first},\"reason\":${q(it.second)}}" })
        k("ocrWarnings"); sb.append(ocrWarnings.joinToString(",", "[", "]") { q(it) })
        k("reviewItems"); sb.append(reviewItems.joinToString(",", "[", "]") { q(it) })
        k("warnings"); sb.append(warnings.joinToString(",", "[", "]") { q(it) })
        k("durationMs"); sb.append(durationMs)
        sb.append('}')
        return sb.toString()
    }

    companion object {
        private fun fmt(f: Float) = String.format(java.util.Locale.US, "%.3f", f)
        fun q(s: String): String {
            val sb = StringBuilder("\"")
            for (c in s) when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append(String.format("\\u%04x", c.code))
                else -> sb.append(c)
            }
            return sb.append('"').toString()
        }
    }
}
