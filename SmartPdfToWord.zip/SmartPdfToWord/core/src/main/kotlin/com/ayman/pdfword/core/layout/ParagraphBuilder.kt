package com.ayman.pdfword.core.layout

import com.ayman.pdfword.core.doc.Align
import com.ayman.pdfword.core.doc.ListRef
import com.ayman.pdfword.core.doc.ParaProps
import com.ayman.pdfword.core.doc.ParagraphBlock
import com.ayman.pdfword.core.doc.Run
import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.text.UnicodeText
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Groups logical lines of one flow region (a column, a cell, the page body) into
 * paragraphs and infers alignment, indentation, spacing, headings and lists.
 */
class ParagraphBuilder(
    private val ctx: BuildContext,
    /** Size of normal body text on this page (for heading detection). */
    private val bodySize: Float,
    /** Margin edges used for indent computation. */
    private val marginLeft: Float,
    private val marginRight: Float,
    /** Content edges of the region used for alignment detection. */
    private val contentLeft: Float,
    private val contentRight: Float,
    private val allowHeadings: Boolean = true,
    private val allowLists: Boolean = true,
) {
    private var listState: ListState? = null

    private data class ListState(val numId: Int, val next: Int, val bullet: Boolean, val rtl: Boolean)

    private data class Marker(val length: Int, val bullet: Boolean, val number: Int?, val format: String, val suffix: String, val literal: Boolean)

    fun build(lines: List<TextLine>, prevBottomInFlow: Float?, prevBaseline: Float?): List<ParagraphBlock> {
        if (lines.isEmpty()) return emptyList()
        val groups = group(lines)
        val out = ArrayList<ParagraphBlock>()
        var prevB = prevBaseline
        var prevBottom = prevBottomInFlow
        for (g in groups) {
            val p = makeParagraph(g, prevB, prevBottom)
            out += p
            prevB = g.last().baseline
            prevBottom = g.last().box.bottom
        }
        return out
    }

    private fun typicalGap(lines: List<TextLine>): Float {
        val gaps = ArrayList<Float>()
        for (i in 1 until lines.size) {
            val a = lines[i - 1]; val b = lines[i]
            if (abs(a.size - b.size) < 0.6f) {
                val g = b.baseline - a.baseline
                if (g > 0.8f * a.size && g < 3f * a.size) gaps += g
            }
        }
        if (gaps.isEmpty()) return lines.first().size * 1.2f
        gaps.sort()
        // Lower quartile = normal leading (paragraph gaps are the larger ones).
        return gaps[gaps.size / 4]
    }

    private fun group(lines: List<TextLine>): List<List<TextLine>> {
        val L = typicalGap(lines)
        val result = ArrayList<MutableList<TextLine>>()
        var cur = mutableListOf(lines.first())
        for (i in 1 until lines.size) {
            val prev = lines[i - 1]
            val line = lines[i]
            if (startsNewParagraph(prev, line, cur, L)) { result += cur; cur = mutableListOf() }
            cur += line
        }
        result += cur
        return result
    }

    private fun startsNewParagraph(prev: TextLine, line: TextLine, cur: List<TextLine>, typical: Float): Boolean {
        val pl = prev.logical!!; val ll = line.logical!!
        val gap = line.baseline - prev.baseline
        val size = max(prev.size, line.size)
        if (gap > 1.3f * typical + 0.5f && gap > 1.12f * size) return true
        if (gap < 0) return true
        if (abs(prev.size - line.size) > 0.15f * size) return true
        if ((pl.boldFraction > 0.8f) != (ll.boldFraction > 0.8f) && (pl.boldFraction > 0.8f && pl.text.length < 120)) return true
        if (pl.rtl != ll.rtl && pl.hasLetters && ll.hasLetters) return true
        // A change of the dominant text colour (e.g. a coloured heading) starts a new paragraph.
        if (dominantColor(prev) != dominantColor(line)) return true
        if (detectMarker(ll.text) != null) return true
        // Alignment edges.
        val rtl = pl.rtl
        val startOf = { t: TextLine -> if (rtl) contentRight - t.box.x1 else t.box.x0 - contentLeft }
        val endGapOf = { t: TextLine -> if (rtl) t.box.x0 - contentLeft else contentRight - t.box.x1 }
        val prevEndGap = endGapOf(prev)
        val lastChar = pl.text.trimEnd().lastOrNull()
        val prevShort = prevEndGap > 3.5f * size
        if (prevShort && lastChar != null && UnicodeText.isSentenceEnd(lastChar)) return true
        val curStart = startOf(line); val prevStart = startOf(prev)
        // Indented first line after a full line → new paragraph.
        if (curStart - prevStart > 1.2f * size && prevEndGap < 2f * size && cur.size >= 2) return true
        // Centered blocks: keep together only if both look centered.
        val centered = { t: TextLine -> val a = t.box.x0 - contentLeft; val b = contentRight - t.box.x1; abs(a - b) < max(6f, 1.2f * t.size) && min(a, b) > 2f * t.size }
        if (centered(prev) != centered(line) && prevShort) return true
        if (prevShort && !centered(prev) && abs(curStart - prevStart) > 1.5f * size) return true
        return false
    }

    private fun dominantColor(t: TextLine): Int {
        val counts = HashMap<Int, Int>()
        for (g in t.glyphs) counts.merge(g.style.color, g.text.length, Int::plus)
        return counts.maxByOrNull { it.value }?.key ?: 0
    }

    private val bulletRegex = Regex("^\\s*([\\u2022\\u25CF\\u25CB\\u25E6\\u25AA\\u25AB\\u25A0\\u25A1\\u2023\\u2043\\u27A2\\u27A4\\u25BA\\u25B6\\u2713\\u2714\\u00B7\\u2219\\u25C6\\u2756\\uF0B7\\uF0A7\\uF076\\uF0D8\\uF0FC\\uF0A8\\uF06E\\uF0E0\\uF0D9\\uF075*\\-–])\\s+")
    private val numRegex = Regex("^\\s*(\\d{1,3}|[\\u0660-\\u0669]{1,3}|[\\u06F0-\\u06F9]{1,3})([.)\\-–])\\s+")
    private val parenNumRegex = Regex("^\\s*\\((\\d{1,3}|[\\u0660-\\u0669]{1,3})\\)\\s+")
    private val letterRegex = Regex("^\\s*([a-zA-Z]|[\\u0623\\u0628\\u062C\\u062F\\u0647\\u0648\\u0632\\u062D\\u0637\\u064A])([.)])\\s+")

    private fun detectMarker(text: String): Marker? {
        bulletRegex.find(text)?.let { m ->
            val sym = m.groupValues[1]
            // A lone "-" or "*" needs following text to count.
            if ((sym == "-" || sym == "*" || sym == "–") && text.length < m.value.length + 2) return null
            return Marker(m.value.length, true, null, "bullet", "", false)
        }
        numRegex.find(text)?.let { m ->
            val digits = m.groupValues[1]
            val n = parseDigits(digits) ?: return null
            if (n > 300) return null
            val fmt = if (digits[0] in '٠'..'٩') "hindiNumbers" else "decimal"
            val suffix = m.groupValues[2].let { if (it == "–") "-" else it }
            return Marker(m.value.length, false, n, fmt, suffix, false)
        }
        parenNumRegex.find(text)?.let { m ->
            val n = parseDigits(m.groupValues[1]) ?: return null
            val fmt = if (m.groupValues[1][0] in '٠'..'٩') "hindiNumbers" else "decimal"
            return Marker(m.value.length, false, n, fmt, "()", false)
        }
        letterRegex.find(text)?.let { m -> return Marker(m.value.length, false, null, "letter", m.groupValues[2], true) }
        return null
    }

    private fun parseDigits(s: String): Int? {
        var v = 0
        for (c in s) {
            val d = Character.digit(c, 10)
            if (d < 0) return null
            v = v * 10 + d
        }
        return v
    }

    private fun makeParagraph(lines: List<TextLine>, prevBaseline: Float?, prevBottom: Float?): ParagraphBlock {
        val first = lines.first()
        val logicals = lines.map { it.logical!! }
        val withLetters = logicals.filter { it.hasLetters }
        val rtl = if (withLetters.isNotEmpty()) withLetters.count { it.rtl } * 2 >= withLetters.size else logicals.first().rtl
        val size = TextLine.dominantSize(lines.flatMap { it.glyphs })
        val box = Box.of(lines.map { it.box })!!

        // --- runs ---
        val runs = ArrayList<Run>()
        for ((i, ll) in logicals.withIndex()) {
            if (i > 0) {
                val prevText = runs.lastOrNull()?.text ?: ""
                val hyphenJoin = !rtl && prevText.endsWith("-") && prevText.length > 1 && prevText[prevText.length - 2].isLetter() &&
                    ll.text.firstOrNull()?.isLowerCase() == true
                if (hyphenJoin) {
                    val last = runs.removeAt(runs.size - 1)
                    runs += last.copy(text = last.text.dropLast(1))
                } else if (!prevText.endsWith(" ")) {
                    val last = runs.removeAt(runs.size - 1)
                    runs += last.copy(text = last.text + " ")
                }
            }
            for (s in ll.spans) runs += ctx.runFor(s)
        }
        var merged = mergeRuns(runs)

        // --- list marker ---
        var listRef: ListRef? = null
        var literalList = false
        if (allowLists) {
            val marker = detectMarker(logicals.first().text)
            if (marker != null && !marker.literal) {
                merged = stripPrefix(merged, marker.length)
                listRef = if (marker.bullet) {
                    listState = null
                    ListRef(ctx.bulletNumId(rtl), 0)
                } else {
                    val st = listState
                    val numId = if (st != null && !st.bullet && st.next == marker.number && st.rtl == rtl) st.numId
                    else ctx.newNumbered(marker.format, marker.suffix, marker.number ?: 1, rtl)
                    listState = ListState(numId, (marker.number ?: 1) + 1, false, rtl)
                    ListRef(numId, 0)
                }
            } else if (marker != null) {
                literalList = true
                listState = null
            } else listState = null
        }

        // --- alignment ---
        val tol = max(2.5f, 0.7f * size)
        val gapsL = lines.map { it.box.x0 - contentLeft }
        val gapsR = lines.map { contentRight - it.box.x1 }
        val physical: Char = run {
            val n = lines.size
            if (n >= 2) {
                val nonLast = (0 until n - 1)
                val startGaps = if (rtl) gapsR else gapsL
                val endGaps = if (rtl) gapsL else gapsR
                val justified = nonLast.all { i -> endGaps[i] < tol && (startGaps[i] < tol || (i == 0 && startGaps[i] < 4f * size)) }
                if (justified) return@run 'J'
            }
            val centered = lines.indices.all { i -> abs(gapsL[i] - gapsR[i]) < max(6f, 1.3f * size) } && lines.indices.all { i -> min(gapsL[i], gapsR[i]) > 1.5f * size }
            if (centered) return@run 'C'
            val rightFlush = gapsR.all { it < tol } && gapsL.any { it > 3f * size }
            val leftFlush = gapsL.all { it < tol } && gapsR.any { it > 3f * size }
            when {
                rightFlush && !leftFlush -> 'R'
                leftFlush -> 'L'
                rtl -> 'R'
                else -> 'L'
            }
        }
        val align = when (physical) {
            'J' -> Align.JUSTIFY
            'C' -> Align.CENTER
            'R' -> if (rtl) Align.START else Align.END
            else -> if (rtl) Align.END else Align.START
        }

        // --- indents (relative to margins, logical start = right for RTL) ---
        var indStart = 0f
        var firstLine = 0f
        var indEnd = 0f
        if (align == Align.START || align == Align.JUSTIFY) {
            val startEdge = { t: TextLine -> if (rtl) marginRight - t.box.x1 else t.box.x0 - marginLeft }
            val body = if (lines.size > 1) lines.drop(1) else lines
            indStart = body.minOf { startEdge(it) }
            firstLine = startEdge(first) - indStart
            if (listRef != null || literalList) {
                // Hanging indent: text aligned after the marker.
                val markerWidth = max(12f, 1.4f * size)
                if (lines.size == 1) { indStart = startEdge(first) + markerWidth; firstLine = -markerWidth }
                else { firstLine = -(indStart - startEdge(first)).coerceAtLeast(markerWidth) }
            }
            if (abs(firstLine) < 1.5f) firstLine = 0f
            if (indStart < 1.5f && indStart > -1.5f) indStart = 0f
        } else if (align == Align.END) {
            val endEdge = { t: TextLine -> if (rtl) t.box.x0 - marginLeft else marginRight - t.box.x1 }
            indEnd = lines.minOf { endEdge(it) }.let { if (abs(it) < 1.5f) 0f else it }
        }

        // --- spacing ---
        val gaps = (1 until lines.size).map { lines[it].baseline - lines[it - 1].baseline }
        var mult = if (gaps.isNotEmpty()) (gaps.average().toFloat() / (1.15f * size)) else 1f
        mult = mult.coerceIn(0.8f, 3f)
        if (abs(mult - 1f) < 0.08f) mult = 1f
        val lineH = 1.15f * size * mult
        var before = when {
            prevBaseline != null -> first.baseline - prevBaseline - lineH
            prevBottom != null -> first.box.top - prevBottom - 0.25f * size
            else -> 0f
        }
        before = (Math.round(before.coerceIn(0f, 200f) * 2f) / 2f)

        // --- heading ---
        var heading = 0
        val textLen = logicals.sumOf { it.text.length }
        if (allowHeadings && listRef == null && lines.size <= 3 && textLen in 1..200 && bodySize > 0f) {
            val ratio = size / bodySize
            heading = when {
                ratio >= 1.7f -> 1
                ratio >= 1.35f -> 2
                ratio >= 1.15f && (logicals.all { it.boldFraction > 0.5f } || ratio >= 1.25f) -> 3
                else -> 0
            }
        }
        val minConf = logicals.minOf { it.minConfidence }
        val isOcr = lines.any { l -> l.glyphs.any { it.isWord } }
        return ParagraphBlock(
            id = ctx.id("p"),
            runs = merged,
            props = ParaProps(
                rtl = rtl, align = align, indStartPt = indStart, indEndPt = indEnd, firstLinePt = firstLine,
                spaceBeforePt = before, lineMultiple = mult, headingLevel = heading, list = listRef,
                keepNext = heading > 0,
            ),
            top = box.top,
            box = box,
            confidence = if (isOcr) minConf else null,
            needsReview = isOcr && minConf < ctx.options.reviewConfidenceThreshold,
            fontSize = size,
        )
    }

    companion object {
        fun mergeRuns(runs: List<Run>): List<Run> {
            val out = ArrayList<Run>()
            for (r in runs) {
                if (r.text.isEmpty() && r.field == null) continue
                val last = out.lastOrNull()
                if (last != null && last.field == null && r.field == null && last.copy(text = r.text) == r) {
                    out[out.size - 1] = last.copy(text = last.text + r.text)
                } else out += r
            }
            return out
        }

        fun stripPrefix(runs: List<Run>, count: Int): List<Run> {
            var remaining = count
            val out = ArrayList<Run>()
            for (r in runs) {
                if (remaining <= 0) { out += r; continue }
                if (r.text.length <= remaining) { remaining -= r.text.length; continue }
                out += r.copy(text = r.text.substring(remaining))
                remaining = 0
            }
            return out
        }
    }
}
