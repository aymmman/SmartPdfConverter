package com.ayman.pdfword.core.text

import java.text.Normalizer

/** Simplified Unicode bidi classes used by the visual→logical reorderer. */
enum class BidiClass { L, R, EN, AN, CS, ES, NSM, WS, ON }

object UnicodeText {

    fun bidiClassOf(cp: Int): BidiClass {
        if (isPrivateUse(cp)) return BidiClass.ON
        return when (Character.getDirectionality(cp)) {
            Character.DIRECTIONALITY_LEFT_TO_RIGHT,
            Character.DIRECTIONALITY_LEFT_TO_RIGHT_EMBEDDING,
            Character.DIRECTIONALITY_LEFT_TO_RIGHT_OVERRIDE -> BidiClass.L
            Character.DIRECTIONALITY_RIGHT_TO_LEFT,
            Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC,
            Character.DIRECTIONALITY_RIGHT_TO_LEFT_EMBEDDING,
            Character.DIRECTIONALITY_RIGHT_TO_LEFT_OVERRIDE -> BidiClass.R
            Character.DIRECTIONALITY_EUROPEAN_NUMBER -> BidiClass.EN
            Character.DIRECTIONALITY_ARABIC_NUMBER -> BidiClass.AN
            Character.DIRECTIONALITY_COMMON_NUMBER_SEPARATOR -> BidiClass.CS
            Character.DIRECTIONALITY_EUROPEAN_NUMBER_SEPARATOR,
            Character.DIRECTIONALITY_EUROPEAN_NUMBER_TERMINATOR -> BidiClass.ES
            Character.DIRECTIONALITY_NONSPACING_MARK -> BidiClass.NSM
            Character.DIRECTIONALITY_WHITESPACE,
            Character.DIRECTIONALITY_SEGMENT_SEPARATOR -> BidiClass.WS
            else -> BidiClass.ON
        }
    }

    /** Class of an atomic text unit: first strong class wins, then numbers. */
    fun bidiClassOf(text: String): BidiClass {
        var sawEn = false
        var sawAn = false
        var sawCs = false
        var sawEs = false
        var allNsm = text.isNotEmpty()
        var allWs = text.isNotEmpty()
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            when (val c = bidiClassOf(cp)) {
                BidiClass.L, BidiClass.R -> return c
                BidiClass.EN -> sawEn = true
                BidiClass.AN -> sawAn = true
                BidiClass.CS -> sawCs = true
                BidiClass.ES -> sawEs = true
                else -> {}
            }
            if (bidiClassOf(cp) != BidiClass.NSM) allNsm = false
            if (bidiClassOf(cp) != BidiClass.WS) allWs = false
            i += Character.charCount(cp)
        }
        return when {
            sawAn -> BidiClass.AN
            sawEn -> BidiClass.EN
            allNsm -> BidiClass.NSM
            allWs -> BidiClass.WS
            text.length == 1 && sawCs -> BidiClass.CS
            text.length == 1 && sawEs -> BidiClass.ES
            else -> BidiClass.ON
        }
    }

    fun isPrivateUse(cp: Int) = cp in 0xE000..0xF8FF || cp in 0xF0000..0x10FFFF

    fun isArabicLetter(cp: Int): Boolean =
        Character.isLetter(cp) && Character.UnicodeScript.of(cp) == Character.UnicodeScript.ARABIC

    fun isLatinLetter(cp: Int): Boolean =
        Character.isLetter(cp) && Character.UnicodeScript.of(cp) == Character.UnicodeScript.LATIN

    data class LetterCounts(val arabic: Int, val latin: Int, val other: Int, val digits: Int)

    fun countLetters(text: CharSequence): LetterCounts {
        var a = 0; var l = 0; var o = 0; var d = 0
        var i = 0
        val s = text.toString()
        while (i < s.length) {
            val cp = s.codePointAt(i)
            when {
                isArabicLetter(cp) -> a++
                isLatinLetter(cp) -> l++
                Character.isDigit(cp) -> d++
                Character.isLetter(cp) -> o++
            }
            i += Character.charCount(cp)
        }
        return LetterCounts(a, l, o, d)
    }

    fun hasArabic(text: CharSequence): Boolean {
        val s = text.toString()
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            if (Character.UnicodeScript.of(cp) == Character.UnicodeScript.ARABIC && !Character.isWhitespace(cp)) return true
            i += Character.charCount(cp)
        }
        return false
    }

    /**
     * Converts Arabic presentation forms (contextual glyph code points that many
     * PDF producers emit) and Latin ligatures to their canonical letters. The
     * result is in the same order as the input – no reversal happens here.
     */
    fun normalizeGlyphText(text: String): String {
        var needs = false
        for (ch in text) {
            val c = ch.code
            if (c in 0xFB00..0xFB06 || c in 0xFB50..0xFDFF || c in 0xFE70..0xFEFF) { needs = true; break }
        }
        val base = if (needs) {
            val sb = StringBuilder()
            for (ch in text) {
                val c = ch.code
                if (c == 0xFEFF) continue // zero width no-break space / BOM
                if (c in 0xFB00..0xFB06 || c in 0xFB50..0xFDFF || c in 0xFE70..0xFEFC) {
                    sb.append(Normalizer.normalize(ch.toString(), Normalizer.Form.NFKC))
                } else sb.append(ch)
            }
            sb.toString()
        } else text
        // Symbol/Wingdings bullets live in the Private Use Area; use real Unicode bullets.
        val mapped = if (base.any { it.code in 0xF000..0xF0FF }) buildString {
            for (ch in base) append(PUA_BULLETS[ch.code] ?: ch)
        } else base
        // Strip control characters and replacement noise but keep everything else.
        return mapped.filter { it == '\t' || !Character.isISOControl(it) }
            .replace("­", "") // soft hyphen
    }

    private val PUA_BULLETS = mapOf(
        0xF0B7 to '\u2022', 0xF0A7 to '\u25AA', 0xF0FC to '\u2713', 0xF0D8 to '\u27A2', 0xF076 to '\u2756',
        0xF06E to '\u25A0', 0xF0A8 to '\u25A1', 0xF0E0 to '\u27A4', 0xF0D9 to '\u25C4', 0xF075 to '\u25C6',
    )

    /** True if the code point is a meaningful text character (used for extraction quality). */
    fun isMeaningful(cp: Int): Boolean {
        if (cp == 0xFFFD || isPrivateUse(cp)) return false
        if (Character.isISOControl(cp)) return false
        val t = Character.getType(cp)
        return t != Character.UNASSIGNED.toInt() && t != Character.SURROGATE.toInt()
    }

    private val mirrorPairs = mapOf(
        '(' to ')', ')' to '(', '[' to ']', ']' to '[', '{' to '}', '}' to '{',
        '<' to '>', '>' to '<', '«' to '»', '»' to '«', '‹' to '›', '›' to '‹',
    )

    fun isMirrorable(text: String) = text.length == 1 && mirrorPairs.containsKey(text[0])
    fun mirror(text: String): String = if (text.length == 1) (mirrorPairs[text[0]]?.toString() ?: text) else text

    /** Bullet glyphs including common Symbol/Wingdings private-use mappings. */
    val bulletChars: Set<Int> = setOf(
        0x2022, 0x25CF, 0x25CB, 0x25E6, 0x25AA, 0x25AB, 0x25A0, 0x25A1, 0x2023, 0x2043,
        0x27A2, 0x27A4, 0x25BA, 0x25B6, 0x2713, 0x2714, 0x00B7, 0x2219, 0x25C6, 0x2756,
        0xF0B7, 0xF0A7, 0xF076, 0xF0D8, 0xF0FC, 0xF0A8, 0xF06E, 0xF0E0, 0xF0D9, 0xF075,
    )

    fun isSentenceEnd(c: Char) = c == '.' || c == '!' || c == '?' || c == ':' || c == '؟' || c == '۔' || c == '؛' || c == '…'
}
