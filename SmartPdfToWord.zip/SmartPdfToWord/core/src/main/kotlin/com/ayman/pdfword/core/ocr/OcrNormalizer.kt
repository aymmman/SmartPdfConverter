package com.ayman.pdfword.core.ocr

import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.Glyph
import com.ayman.pdfword.core.model.TextStyle
import kotlin.math.max
import kotlin.math.roundToInt

/** A word recognised by an OCR engine, in page points (display space). */
data class OcrWord(
    val text: String,
    val box: Box,
    /** 0..100 */
    val confidence: Float,
    /** Words with the same id were recognised on the same text line. */
    val lineId: Int,
    /** Estimated ink colour 0xRRGGBB (0 = black / unknown). */
    val color: Int = 0,
    val bold: Boolean = false,
)

/**
 * Converts OCR words into glyphs with a consistent baseline and font size per
 * line. Word boxes alone vary with ascenders/descenders, which would otherwise
 * break lines apart and create false headings.
 */
object OcrNormalizer {

    private val bulletLike = setOf("e", "o", "©", "°", "«", "»", "•", "*", "·", "@", "®", "¢", "+", ">", "»")

    fun toGlyphs(words: List<OcrWord>): List<Glyph> {
        val out = ArrayList<Glyph>(words.size)
        val lines = words.filter { it.text.isNotBlank() }.groupBy { it.lineId }
        // Size from ascender height (baseline to the top of tall letters ≈ 0.72 em): unlike the
        // full word height this does not depend on whether a line happens to contain descenders.
        fun baselineOf(lw: List<OcrWord>): Float {
            val bottoms = lw.map { it.box.bottom }.sorted()
            return bottoms[(bottoms.size * 0.3f).toInt().coerceAtMost(bottoms.size - 1)]
        }
        val rawSize = lines.mapValues { (_, lw) ->
            val tops = lw.map { it.box.top }.sorted()
            val asc = baselineOf(lw) - tops[(tops.size / 4).coerceAtMost(tops.size - 1)]
            max(4f, asc / 0.72f)
        }
        // Body text lines vary only because of letter shapes: snap them to the page median.
        val median = rawSize.values.sorted().let { if (it.isEmpty()) 11f else it[it.size / 2] }
        for ((lineId, lw) in lines) {
            val heights = lw.map { it.box.height }.sorted()
            val medianH = heights[heights.size / 2]
            val baseline = baselineOf(lw)
            val r = rawSize[lineId] ?: median
            val sized = if (kotlin.math.abs(r - median) <= 0.1f * median) median else r
            val size = (sized * 2f).roundToInt() / 2f
            val sorted = lw.sortedBy { it.box.x0 }
            for ((i, w) in sorted.withIndex()) {
                var text = w.text.trim()
                // Typical OCR misreadings of list bullets ("e", "©", "°") at the line start.
                val isEdge = i == 0 || i == sorted.size - 1
                if (isEdge && text in bulletLike && w.box.height < 0.8f * medianH) {
                    val neighbour = if (i == 0) sorted.getOrNull(1) else sorted.getOrNull(i - 1)
                    val gap = if (neighbour == null) 0f else if (i == 0) neighbour.box.x0 - w.box.x1 else w.box.x0 - neighbour.box.x1
                    if (gap > 0.3f * size) text = "•"
                }
                val style = TextStyle("", size, w.bold, false, w.color, embedded = false, estimated = true)
                out += Glyph(text, w.box, baseline, style, isWord = true, confidence = w.confidence)
            }
        }
        return out
    }
}
