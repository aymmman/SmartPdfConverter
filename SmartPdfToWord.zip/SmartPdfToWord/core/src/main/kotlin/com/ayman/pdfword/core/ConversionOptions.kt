package com.ayman.pdfword.core

enum class ConversionMode { EDITABLE, LAYOUT }

data class ConversionOptions(
    val mode: ConversionMode = ConversionMode.EDITABLE,
    val defaultLatinFont: String = "Calibri",
    val defaultArabicFont: String = "Arial",
    /** "Source=Target" rules keyed by normalised source family. */
    val fontRules: Map<String, String> = emptyMap(),
    val detectTables: Boolean = true,
    val detectBorderlessTables: Boolean = true,
    val detectColumns: Boolean = true,
    val detectHeadersFooters: Boolean = true,
    val keepImages: Boolean = true,
    /** OCR words below this confidence mark their paragraph for review. */
    val reviewConfidenceThreshold: Float = 70f,
)
