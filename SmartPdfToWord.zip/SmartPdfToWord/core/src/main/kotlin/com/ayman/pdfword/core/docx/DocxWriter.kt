package com.ayman.pdfword.core.docx

import com.ayman.pdfword.core.doc.Align
import com.ayman.pdfword.core.doc.Block
import com.ayman.pdfword.core.doc.ColumnBreakBlock
import com.ayman.pdfword.core.doc.DocModel
import com.ayman.pdfword.core.doc.ImageBlock
import com.ayman.pdfword.core.doc.NumberingDef
import com.ayman.pdfword.core.doc.PageLayout
import com.ayman.pdfword.core.doc.ParagraphBlock
import com.ayman.pdfword.core.doc.Run
import com.ayman.pdfword.core.doc.SectionPart
import com.ayman.pdfword.core.doc.TableBlock
import com.ayman.pdfword.core.doc.TableCell
import com.ayman.pdfword.core.text.UnicodeText
import java.io.File
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.io.Writer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Writes a [DocModel] as an Office Open XML (WordprocessingML) package.
 *
 * Bidi conventions follow Microsoft Word's interpretation of the transitional
 * schema: inside a `w:bidi` paragraph, `jc=left` / `ind@left` refer to the
 * paragraph's *start* (the right edge), and in `w:bidiVisual` tables the first
 * cell of a row is the rightmost one.
 */
class DocxWriter(
    private val model: DocModel,
    /** Paragraph id → corrected text (from the OCR review screen). */
    private val overrides: Map<String, String> = emptyMap(),
) {
    private class Media(val relId: String, val path: String, val ext: String, val zipName: String)

    private val media = LinkedHashMap<String, Media>()
    private var drawingId = 1
    private var relCounter = 100
    private var progress: ((Int) -> Unit)? = null

    fun write(out: OutputStream, onPage: ((Int) -> Unit)? = null) {
        progress = onPage
        val zip = ZipOutputStream(out)
        zip.setLevel(6)
        val hasHeader = model.header.isNotEmpty()
        val hasFooter = model.footer.isNotEmpty()

        // document.xml is streamed page by page.
        zip.putNextEntry(ZipEntry("word/document.xml"))
        val w = OutputStreamWriter(NonClosing(zip), Charsets.UTF_8).buffered(1 shl 16)
        writeDocument(w, hasHeader, hasFooter)
        w.flush()
        zip.closeEntry()

        if (hasHeader) entry(zip, "word/header1.xml") { it.append(hdrFtr("hdr", model.header)) }
        if (hasFooter) entry(zip, "word/footer1.xml") { it.append(hdrFtr("ftr", model.footer)) }
        entry(zip, "word/styles.xml") { it.append(stylesXml()) }
        entry(zip, "word/settings.xml") { it.append(settingsXml()) }
        entry(zip, "word/numbering.xml") { it.append(numberingXml()) }
        entry(zip, "word/fontTable.xml") { it.append(fontTableXml()) }
        entry(zip, "word/_rels/document.xml.rels") { it.append(documentRels(hasHeader, hasFooter)) }
        entry(zip, "docProps/core.xml") { it.append(coreXml()) }
        entry(zip, "docProps/app.xml") { it.append(APP_XML) }
        entry(zip, "_rels/.rels") { it.append(ROOT_RELS) }
        entry(zip, "[Content_Types].xml") { it.append(contentTypes(hasHeader, hasFooter)) }
        for (m in media.values) {
            zip.putNextEntry(ZipEntry("word/media/${m.zipName}"))
            File(m.path).inputStream().use { it.copyTo(zip) }
            zip.closeEntry()
        }
        zip.finish()
        zip.flush()
    }

    private fun entry(zip: ZipOutputStream, name: String, body: (StringBuilder) -> Unit) {
        val sb = StringBuilder()
        body(sb)
        zip.putNextEntry(ZipEntry(name))
        zip.write(sb.toString().toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private class NonClosing(private val o: OutputStream) : OutputStream() {
        override fun write(b: Int) = o.write(b)
        override fun write(b: ByteArray, off: Int, len: Int) = o.write(b, off, len)
        override fun flush() = o.flush()
        override fun close() { flush() }
    }

    // ------------------------------------------------------------------ document

    private fun writeDocument(w: Writer, hasHeader: Boolean, hasFooter: Boolean) {
        w.write(XML_DECL)
        w.write("<w:document $NS><w:body>")
        val pages = model.pages
        for ((pi, page) in pages.withIndex()) {
            val sb = StringBuilder()
            for ((partIdx, part) in page.parts.withIndex()) {
                val isLastOfDoc = pi == pages.size - 1 && partIdx == page.parts.size - 1
                val sect = sectPr(page, part, partIdx == 0, hasHeader, hasFooter)
                writePart(sb, page, part, if (isLastOfDoc) null else sect)
                if (isLastOfDoc) sb.append(sect)
            }
            if (page.parts.isEmpty()) {
                val sect = sectPr(page, SectionPart(1, page.rtlDominant, emptyList()), true, hasHeader, hasFooter)
                if (pi == pages.size - 1) sb.append(sect) else sb.append("<w:p><w:pPr>").append(sect).append("</w:pPr></w:p>")
            }
            w.write(sb.toString())
            progress?.invoke(pi)
        }
        if (pages.isEmpty()) w.write("<w:p/><w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr>")
        w.write("</w:body></w:document>")
    }

    private fun writePart(sb: StringBuilder, page: PageLayout, part: SectionPart, endSect: String?) {
        val pendingAnchors = ArrayList<ImageBlock>()
        var pendingColumnBreak = false
        var lastWasTable = false
        val textWidth = page.widthPt - page.margins.left - page.margins.right
        val colWidth = if (part.columns > 1) (textWidth - part.columnGapPt * (part.columns - 1)) / part.columns else textWidth
        val blocks = part.blocks
        val lastParaIdx = blocks.indexOfLast { it is ParagraphBlock && it.frame == null }
        val lastIsPlainPara = lastParaIdx == blocks.size - 1 && lastParaIdx >= 0

        fun prefixRuns(): String {
            val s = StringBuilder()
            if (pendingColumnBreak) { s.append("<w:r><w:br w:type=\"column\"/></w:r>"); pendingColumnBreak = false }
            for (a in pendingAnchors) s.append("<w:r>").append(drawing(a, colWidth)).append("</w:r>")
            pendingAnchors.clear()
            return s.toString()
        }

        for ((i, b) in blocks.withIndex()) {
            when (b) {
                is ParagraphBlock -> {
                    val sect = if (i == lastParaIdx && lastIsPlainPara) endSect else null
                    paragraph(sb, b, prefixRuns(), sect)
                    lastWasTable = false
                }
                is TableBlock -> {
                    if (pendingAnchors.isNotEmpty() || pendingColumnBreak || lastWasTable) tinyParagraph(sb, part.rtl, prefixRuns(), null)
                    table(sb, b)
                    lastWasTable = true
                }
                is ImageBlock -> {
                    if (b.anchored) { pendingAnchors += b; continue }
                    sb.append("<w:p><w:pPr>")
                    if (part.rtl) sb.append("<w:bidi/>")
                    sb.append("<w:spacing w:before=\"60\" w:after=\"60\"/>")
                    sb.append("<w:jc w:val=\"").append(jcVal(b.align, part.rtl)).append("\"/></w:pPr>")
                    sb.append(prefixRuns())
                    sb.append("<w:r>").append(drawing(b, colWidth)).append("</w:r></w:p>")
                    lastWasTable = false
                }
                is ColumnBreakBlock -> {
                    if (pendingColumnBreak) tinyParagraph(sb, part.rtl, prefixRuns(), null)
                    pendingColumnBreak = true
                }
            }
        }
        if (!lastIsPlainPara || pendingAnchors.isNotEmpty() || pendingColumnBreak) {
            tinyParagraph(sb, part.rtl, prefixRuns(), endSect)
        }
    }

    private fun tinyParagraph(sb: StringBuilder, rtl: Boolean, runs: String, sect: String?) {
        sb.append("<w:p><w:pPr>")
        if (rtl) sb.append("<w:bidi/>")
        sb.append("<w:spacing w:before=\"0\" w:after=\"0\" w:line=\"20\" w:lineRule=\"exact\"/><w:rPr><w:sz w:val=\"2\"/><w:szCs w:val=\"2\"/></w:rPr>")
        if (sect != null) sb.append(sect)
        sb.append("</w:pPr>").append(runs).append("</w:p>")
    }

    private fun sectPr(page: PageLayout, part: SectionPart, firstOfPage: Boolean, hasHeader: Boolean, hasFooter: Boolean): String {
        val sb = StringBuilder("<w:sectPr>")
        if (hasHeader) sb.append("<w:headerReference w:type=\"default\" r:id=\"rIdHeader1\"/>")
        if (hasFooter) sb.append("<w:footerReference w:type=\"default\" r:id=\"rIdFooter1\"/>")
        sb.append("<w:type w:val=\"").append(if (firstOfPage) "nextPage" else "continuous").append("\"/>")
        val wTw = tw(page.widthPt); val hTw = tw(page.heightPt)
        sb.append("<w:pgSz w:w=\"").append(wTw).append("\" w:h=\"").append(hTw).append('"')
        if (page.widthPt > page.heightPt) sb.append(" w:orient=\"landscape\"")
        sb.append("/>")
        val m = page.margins
        sb.append("<w:pgMar w:top=\"").append(tw(m.top)).append("\" w:right=\"").append(tw(m.right))
            .append("\" w:bottom=\"").append(tw(m.bottom)).append("\" w:left=\"").append(tw(m.left))
            .append("\" w:header=\"").append(tw(max(8f, m.top * 0.45f))).append("\" w:footer=\"").append(tw(max(8f, m.bottom * 0.45f)))
            .append("\" w:gutter=\"0\"/>")
        if (part.columns > 1) sb.append("<w:cols w:num=\"").append(part.columns).append("\" w:space=\"").append(tw(part.columnGapPt)).append("\"/>")
        else sb.append("<w:cols w:space=\"720\"/>")
        if (part.rtl) sb.append("<w:bidi/>")
        sb.append("</w:sectPr>")
        return sb.toString()
    }

    // ------------------------------------------------------------------ paragraphs

    private fun paragraph(sb: StringBuilder, p: ParagraphBlock, prefix: String, sect: String?) {
        if (p.props.spacer) {
            sb.append("<w:p><w:pPr>")
            if (p.props.rtl) sb.append("<w:bidi/>")
            sb.append("<w:spacing w:before=\"").append(tw(p.props.spaceBeforePt)).append("\" w:after=\"0\" w:line=\"20\" w:lineRule=\"exact\"/><w:rPr><w:sz w:val=\"2\"/><w:szCs w:val=\"2\"/></w:rPr>")
            if (sect != null) sb.append(sect)
            sb.append("</w:pPr>").append(prefix).append("</w:p>")
            return
        }
        val override = overrides[p.id]
        val runs = if (override != null) {
            val base = p.runs.firstOrNull()
            if (base == null) emptyList() else listOf(base.copy(text = override, rtl = UnicodeText.hasArabic(override), field = null))
        } else p.runs
        val pp = p.props
        sb.append("<w:p><w:pPr>")
        if (pp.headingLevel in 1..3) sb.append("<w:pStyle w:val=\"Heading").append(pp.headingLevel).append("\"/>")
        else if (pp.list != null) sb.append("<w:pStyle w:val=\"ListParagraph\"/>")
        if (pp.keepNext) sb.append("<w:keepNext/>")
        p.frame?.let { f ->
            val slack = max(4f, f.box.width * 0.12f)
            val width = f.box.width + slack
            val x = when {
                pp.align == Align.CENTER -> f.box.x0 - slack / 2f
                pp.rtl -> f.box.x1 - width
                else -> f.box.x0
            }
            val size = runs.maxOfOrNull { it.sizePt } ?: 11f
            sb.append("<w:framePr w:w=\"").append(tw(width)).append("\" w:wrap=\"around\" w:vAnchor=\"page\" w:hAnchor=\"page\" w:x=\"")
                .append(tw(max(0f, x))).append("\" w:y=\"").append(tw(max(0f, f.box.top - 0.12f * size))).append("\"/>")
        }
        pp.list?.let { sb.append("<w:numPr><w:ilvl w:val=\"").append(it.level).append("\"/><w:numId w:val=\"").append(it.numId).append("\"/></w:numPr>") }
        if (pp.rtl) sb.append("<w:bidi/>")
        sb.append("<w:spacing w:before=\"").append(tw(pp.spaceBeforePt)).append("\" w:after=\"").append(tw(pp.spaceAfterPt)).append('"')
        sb.append(" w:line=\"").append((240 * pp.lineMultiple).roundToInt()).append("\" w:lineRule=\"auto\"/>")
        if (p.frame == null && (pp.indStartPt != 0f || pp.indEndPt != 0f || pp.firstLinePt != 0f || pp.list != null)) {
            sb.append("<w:ind w:left=\"").append(tw(pp.indStartPt)).append("\" w:right=\"").append(tw(pp.indEndPt)).append('"')
            if (pp.firstLinePt > 0f) sb.append(" w:firstLine=\"").append(tw(pp.firstLinePt)).append('"')
            else if (pp.firstLinePt < 0f) sb.append(" w:hanging=\"").append(tw(-pp.firstLinePt)).append('"')
            sb.append("/>")
        }
        sb.append("<w:jc w:val=\"").append(jcVal(pp.align, pp.rtl)).append("\"/>")
        if (pp.headingLevel in 1..3) sb.append("<w:outlineLvl w:val=\"").append(pp.headingLevel - 1).append("\"/>")
        // Paragraph mark formatting mirrors the first run.
        runs.firstOrNull()?.let { sb.append(rPr(it.copy(underline = false, highlight = null, vertAlign = 0), true)) }
        if (sect != null) sb.append(sect)
        sb.append("</w:pPr>")
        sb.append(prefix)
        for (r in runs) run(sb, r)
        sb.append("</w:p>")
    }

    /** Word interprets left/right logically (start/end) in bidi paragraphs. */
    private fun jcVal(a: Align, rtl: Boolean) = when (a) {
        Align.START -> "left"
        Align.END -> "right"
        Align.CENTER -> "center"
        Align.JUSTIFY -> "both"
    }

    private fun run(sb: StringBuilder, r: Run) {
        if (r.field != null) {
            sb.append("<w:fldSimple w:instr=\" ").append(r.field).append(" \"><w:r>").append(rPr(r, false))
                .append("<w:t>").append(esc(r.text)).append("</w:t></w:r></w:fldSimple>")
            return
        }
        if (r.text.isEmpty()) return
        sb.append("<w:r>").append(rPr(r, false))
        var start = 0
        val t = r.text
        for (i in t.indices) {
            if (t[i] == '\t' || t[i] == '\n') {
                if (i > start) text(sb, t.substring(start, i))
                sb.append(if (t[i] == '\t') "<w:tab/>" else "<w:br/>")
                start = i + 1
            }
        }
        if (start < t.length) text(sb, t.substring(start))
        sb.append("</w:r>")
    }

    private fun text(sb: StringBuilder, s: String) {
        sb.append("<w:t xml:space=\"preserve\">").append(esc(s)).append("</w:t>")
    }

    private fun rPr(r: Run, paragraphMark: Boolean): String {
        val sb = StringBuilder("<w:rPr>")
        sb.append("<w:rFonts w:ascii=\"").append(attr(r.latinFont)).append("\" w:hAnsi=\"").append(attr(r.latinFont))
            .append("\" w:eastAsia=\"").append(attr(r.latinFont)).append("\" w:cs=\"").append(attr(r.csFont)).append("\"/>")
        if (r.bold) sb.append("<w:b/><w:bCs/>")
        if (r.italic) sb.append("<w:i/><w:iCs/>")
        if (r.color != 0) sb.append("<w:color w:val=\"").append(hex(r.color)).append("\"/>")
        val hp = (r.sizePt * 2).roundToInt().coerceIn(2, 3276)
        sb.append("<w:sz w:val=\"").append(hp).append("\"/><w:szCs w:val=\"").append(hp).append("\"/>")
        if (r.underline) sb.append("<w:u w:val=\"single\"/>")
        r.highlight?.let { sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(hex(it)).append("\"/>") }
        if (r.vertAlign == 1) sb.append("<w:vertAlign w:val=\"superscript\"/>")
        else if (r.vertAlign == -1) sb.append("<w:vertAlign w:val=\"subscript\"/>")
        if (r.rtl) sb.append("<w:rtl/>")
        if (UnicodeText.hasArabic(r.text) || r.rtl) sb.append("<w:lang w:bidi=\"ar-SA\"/>")
        sb.append("</w:rPr>")
        return sb.toString()
    }

    // ------------------------------------------------------------------ tables

    private fun table(sb: StringBuilder, t: TableBlock) {
        val cols = t.colWidths.size
        if (cols == 0) return
        val logicalWidths = if (t.rtl) t.colWidths.reversed() else t.colWidths
        val total = t.colWidths.sum()
        sb.append("<w:tbl><w:tblPr>")
        if (t.floating) {
            sb.append("<w:tblpPr w:leftFromText=\"0\" w:rightFromText=\"0\" w:vertAnchor=\"page\" w:horzAnchor=\"page\" w:tblpX=\"")
                .append(tw(t.box.x0)).append("\" w:tblpY=\"").append(tw(t.box.top)).append("\"/><w:tblOverlap w:val=\"overlap\"/>")
        }
        if (t.rtl) sb.append("<w:bidiVisual/>")
        sb.append("<w:tblW w:w=\"").append(tw(total)).append("\" w:type=\"dxa\"/>")
        // RTL (bidiVisual) indents are measured from the right margin; tiny ones are dropped.
        val ind = if (t.rtl && kotlin.math.abs(t.indentPt) < 8f) 0f else t.indentPt
        if (!t.floating && kotlin.math.abs(ind) > 0.5f) sb.append("<w:tblInd w:w=\"").append(tw(ind)).append("\" w:type=\"dxa\"/>")
        sb.append("<w:tblBorders><w:top w:val=\"nil\"/><w:left w:val=\"nil\"/><w:bottom w:val=\"nil\"/><w:right w:val=\"nil\"/><w:insideH w:val=\"nil\"/><w:insideV w:val=\"nil\"/></w:tblBorders>")
        sb.append("<w:tblLayout w:type=\"fixed\"/>")
        val cm = tw(t.cellMarginPt)
        sb.append("<w:tblCellMar><w:top w:w=\"0\" w:type=\"dxa\"/><w:left w:w=\"$cm\" w:type=\"dxa\"/><w:bottom w:w=\"0\" w:type=\"dxa\"/><w:right w:w=\"$cm\" w:type=\"dxa\"/></w:tblCellMar>")
        sb.append("<w:tblLook w:val=\"0000\" w:firstRow=\"0\" w:lastRow=\"0\" w:firstColumn=\"0\" w:lastColumn=\"0\" w:noHBand=\"1\" w:noVBand=\"1\"/>")
        sb.append("</w:tblPr><w:tblGrid>")
        for (cw in logicalWidths) sb.append("<w:gridCol w:w=\"").append(tw(cw)).append("\"/>")
        sb.append("</w:tblGrid>")
        val rows = t.rowHeights.size
        val color = hex(t.borderColor)
        for (r in 0 until rows) {
            sb.append("<w:tr><w:trPr><w:trHeight w:val=\"").append(tw(max(6f, t.rowHeights[r]))).append("\" w:hRule=\"atLeast\"/></w:trPr>")
            val rowCells = t.cells.filter { r >= it.row && r < it.row + it.rowSpan }
                .sortedBy { c -> if (t.rtl) cols - (c.col + c.colSpan) else c.col }
            for (c in rowCells) {
                val width = (c.col until c.col + c.colSpan).sumOf { t.colWidths[it].toDouble() }.toFloat()
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"").append(tw(width)).append("\" w:type=\"dxa\"/>")
                if (c.colSpan > 1) sb.append("<w:gridSpan w:val=\"").append(c.colSpan).append("\"/>")
                if (c.rowSpan > 1) sb.append(if (r == c.row) "<w:vMerge w:val=\"restart\"/>" else "<w:vMerge/>")
                cellBorders(sb, t, c, color)
                c.shading?.let { sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(hex(it)).append("\"/>") }
                if (c.vAlignCenter) sb.append("<w:vAlign w:val=\"center\"/>")
                sb.append("</w:tcPr>")
                if (r == c.row && c.paragraphs.isNotEmpty()) {
                    for (p in c.paragraphs) paragraph(sb, p, "", null)
                } else {
                    sb.append("<w:p><w:pPr>")
                    if (t.rtl) sb.append("<w:bidi/>")
                    sb.append("<w:spacing w:before=\"0\" w:after=\"0\"/></w:pPr></w:p>")
                }
                sb.append("</w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl>")
    }

    private fun cellBorders(sb: StringBuilder, t: TableBlock, c: TableCell, color: String) {
        val b = c.borders
        // Detected borders are visual (start = visual left). In a bidiVisual table Word
        // treats left/right as start/end, i.e. "left" is the visual right edge.
        val visLeft = b.start
        val visRight = b.end
        val left = if (t.rtl) visRight else visLeft
        val right = if (t.rtl) visLeft else visRight
        fun one(tag: String, on: Boolean) {
            if (on) sb.append("<w:").append(tag).append(" w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"").append(color).append("\"/>")
            else sb.append("<w:").append(tag).append(" w:val=\"nil\"/>")
        }
        sb.append("<w:tcBorders>")
        one("top", b.top); one("left", left); one("bottom", b.bottom); one("right", right)
        sb.append("</w:tcBorders>")
    }

    // ------------------------------------------------------------------ images

    private fun mediaFor(path: String, mime: String): Media = media.getOrPut(path) {
        val ext = if (mime.contains("png")) "png" else "jpeg"
        val n = media.size + 1
        Media("rIdImg$n", path, ext, "image$n.$ext")
    }

    private fun drawing(img: ImageBlock, maxWidthPt: Float): String {
        // Temporary media may have been cleaned up (privacy setting); skip rather than fail.
        if (!File(img.image.filePath).exists()) return ""
        val m = mediaFor(img.image.filePath, img.image.mime)
        var wPt = img.image.box.width
        var hPt = img.image.box.height
        if (!img.anchored && wPt > maxWidthPt) { val s = maxWidthPt / wPt; wPt *= s; hPt *= s }
        val cx = emu(wPt); val cy = emu(hPt)
        val id = drawingId++
        val graphic = "<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\"><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
            "<pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:nvPicPr><pic:cNvPr id=\"$id\" name=\"${m.zipName}\"/><pic:cNvPicPr/></pic:nvPicPr>" +
            "<pic:blipFill><a:blip r:embed=\"${m.relId}\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
            "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic>"
        return if (!img.anchored) {
            "<w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"$cx\" cy=\"$cy\"/><wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/>" +
                "<wp:docPr id=\"$id\" name=\"Picture $id\"/><wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" noChangeAspect=\"1\"/></wp:cNvGraphicFramePr>$graphic</wp:inline></w:drawing>"
        } else {
            val x = emu(img.image.box.x0); val y = emu(img.image.box.top)
            "<w:drawing><wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"${251658240 + id}\" behindDoc=\"${if (img.behindText) 1 else 0}\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\">" +
                "<wp:simplePos x=\"0\" y=\"0\"/><wp:positionH relativeFrom=\"page\"><wp:posOffset>$x</wp:posOffset></wp:positionH>" +
                "<wp:positionV relativeFrom=\"page\"><wp:posOffset>$y</wp:posOffset></wp:positionV><wp:extent cx=\"$cx\" cy=\"$cy\"/>" +
                "<wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/><wp:wrapNone/><wp:docPr id=\"$id\" name=\"Picture $id\"/><wp:cNvGraphicFramePr/>$graphic</wp:anchor></w:drawing>"
        }
    }

    // ------------------------------------------------------------------ parts

    private fun hdrFtr(tag: String, paras: List<ParagraphBlock>): String {
        val sb = StringBuilder(XML_DECL)
        sb.append("<w:").append(tag).append(' ').append(NS).append('>')
        for (p in paras) paragraph(sb, p, "", null)
        if (paras.isEmpty()) sb.append("<w:p/>")
        sb.append("</w:").append(tag).append('>')
        return sb.toString()
    }

    private fun stylesXml(): String {
        val lat = attr(model.defaultLatinFont); val cs = attr(model.defaultCsFont)
        val sb = StringBuilder(XML_DECL)
        sb.append("<w:styles xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">")
        sb.append("<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"$lat\" w:hAnsi=\"$lat\" w:eastAsia=\"$lat\" w:cs=\"$cs\"/>")
        sb.append("<w:sz w:val=\"22\"/><w:szCs w:val=\"22\"/><w:lang w:val=\"en-US\" w:eastAsia=\"en-US\" w:bidi=\"ar-SA\"/></w:rPr></w:rPrDefault>")
        sb.append("<w:pPrDefault><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>")
        sb.append("<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/><w:qFormat/></w:style>")
        for (lvl in 1..3) {
            sb.append("<w:style w:type=\"paragraph\" w:styleId=\"Heading$lvl\"><w:name w:val=\"heading $lvl\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/>")
            sb.append("<w:uiPriority w:val=\"9\"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/><w:outlineLvl w:val=\"${lvl - 1}\"/></w:pPr></w:style>")
        }
        sb.append("<w:style w:type=\"paragraph\" w:styleId=\"ListParagraph\"><w:name w:val=\"List Paragraph\"/><w:basedOn w:val=\"Normal\"/><w:uiPriority w:val=\"34\"/><w:qFormat/></w:style>")
        sb.append("<w:style w:type=\"character\" w:default=\"1\" w:styleId=\"DefaultParagraphFont\"><w:name w:val=\"Default Paragraph Font\"/><w:uiPriority w:val=\"1\"/><w:semiHidden/></w:style>")
        sb.append("<w:style w:type=\"table\" w:default=\"1\" w:styleId=\"TableNormal\"><w:name w:val=\"Normal Table\"/><w:semiHidden/><w:tblPr><w:tblInd w:w=\"0\" w:type=\"dxa\"/>")
        sb.append("<w:tblCellMar><w:top w:w=\"0\" w:type=\"dxa\"/><w:left w:w=\"108\" w:type=\"dxa\"/><w:bottom w:w=\"0\" w:type=\"dxa\"/><w:right w:w=\"108\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr></w:style>")
        sb.append("<w:style w:type=\"numbering\" w:default=\"1\" w:styleId=\"NoList\"><w:name w:val=\"No List\"/><w:semiHidden/></w:style>")
        sb.append("</w:styles>")
        return sb.toString()
    }

    private fun settingsXml(): String = XML_DECL +
        "<w:settings xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
        "<w:defaultTabStop w:val=\"720\"/><w:characterSpacingControl w:val=\"doNotCompress\"/>" +
        "<w:compat><w:compatSetting w:name=\"compatibilityMode\" w:uri=\"http://schemas.microsoft.com/office/word\" w:val=\"15\"/></w:compat>" +
        "<w:themeFontLang w:val=\"en-US\" w:bidi=\"ar-SA\"/></w:settings>"

    private fun numberingXml(): String {
        val sb = StringBuilder(XML_DECL)
        sb.append("<w:numbering xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">")
        for (n in model.numbering) abstractNum(sb, n)
        for (n in model.numbering) sb.append("<w:num w:numId=\"").append(n.numId).append("\"><w:abstractNumId w:val=\"").append(n.numId).append("\"/></w:num>")
        sb.append("</w:numbering>")
        return sb.toString()
    }

    private fun abstractNum(sb: StringBuilder, n: NumberingDef) {
        sb.append("<w:abstractNum w:abstractNumId=\"").append(n.numId).append("\"><w:multiLevelType w:val=\"hybridMultilevel\"/>")
        val bullets = listOf("•", "◦", "▪")
        for (lvl in 0..2) {
            sb.append("<w:lvl w:ilvl=\"").append(lvl).append("\"><w:start w:val=\"").append(if (lvl == 0) n.start else 1).append("\"/>")
            if (n.bullet) {
                sb.append("<w:numFmt w:val=\"bullet\"/><w:lvlText w:val=\"").append(bullets[lvl]).append("\"/>")
            } else {
                val fmt = if (lvl == 0) n.format else "decimal"
                val text = when (n.suffix) { "()" -> "(%${lvl + 1})"; ")" -> "%${lvl + 1})"; "-" -> "%${lvl + 1}-"; else -> "%${lvl + 1}." }
                sb.append("<w:numFmt w:val=\"").append(fmt).append("\"/><w:lvlText w:val=\"").append(text).append("\"/>")
            }
            sb.append("<w:lvlJc w:val=\"left\"/><w:pPr><w:ind w:left=\"").append(720 * (lvl + 1)).append("\" w:hanging=\"360\"/></w:pPr>")
            if (n.bullet) sb.append("<w:rPr><w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\" w:cs=\"Arial\"/></w:rPr>")
            sb.append("</w:lvl>")
        }
        sb.append("</w:abstractNum>")
    }

    private fun fontTableXml(): String {
        val names = LinkedHashSet<String>()
        names += model.defaultLatinFont; names += model.defaultCsFont
        for (p in model.pages) for (part in p.parts) for (b in part.blocks) collectFonts(b, names)
        val sb = StringBuilder(XML_DECL)
        sb.append("<w:fonts xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">")
        for (n in names) sb.append("<w:font w:name=\"").append(attr(n)).append("\"/>")
        sb.append("</w:fonts>")
        return sb.toString()
    }

    private fun collectFonts(b: Block, out: MutableSet<String>) {
        when (b) {
            is ParagraphBlock -> b.runs.forEach { out += it.latinFont; out += it.csFont }
            is TableBlock -> b.cells.forEach { c -> c.paragraphs.forEach { collectFonts(it, out) } }
            else -> {}
        }
    }

    private fun documentRels(hasHeader: Boolean, hasFooter: Boolean): String {
        val sb = StringBuilder(XML_DECL)
        sb.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
        val base = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        sb.append("<Relationship Id=\"rIdStyles\" Type=\"$base/styles\" Target=\"styles.xml\"/>")
        sb.append("<Relationship Id=\"rIdSettings\" Type=\"$base/settings\" Target=\"settings.xml\"/>")
        sb.append("<Relationship Id=\"rIdNumbering\" Type=\"$base/numbering\" Target=\"numbering.xml\"/>")
        sb.append("<Relationship Id=\"rIdFonts\" Type=\"$base/fontTable\" Target=\"fontTable.xml\"/>")
        if (hasHeader) sb.append("<Relationship Id=\"rIdHeader1\" Type=\"$base/header\" Target=\"header1.xml\"/>")
        if (hasFooter) sb.append("<Relationship Id=\"rIdFooter1\" Type=\"$base/footer\" Target=\"footer1.xml\"/>")
        for (m in media.values) sb.append("<Relationship Id=\"${m.relId}\" Type=\"$base/image\" Target=\"media/${m.zipName}\"/>")
        sb.append("</Relationships>")
        return sb.toString()
    }

    private fun contentTypes(hasHeader: Boolean, hasFooter: Boolean): String {
        val sb = StringBuilder(XML_DECL)
        sb.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
        sb.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
        sb.append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
        sb.append("<Default Extension=\"png\" ContentType=\"image/png\"/><Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/>")
        val wml = "application/vnd.openxmlformats-officedocument.wordprocessingml"
        sb.append("<Override PartName=\"/word/document.xml\" ContentType=\"$wml.document.main+xml\"/>")
        sb.append("<Override PartName=\"/word/styles.xml\" ContentType=\"$wml.styles+xml\"/>")
        sb.append("<Override PartName=\"/word/settings.xml\" ContentType=\"$wml.settings+xml\"/>")
        sb.append("<Override PartName=\"/word/numbering.xml\" ContentType=\"$wml.numbering+xml\"/>")
        sb.append("<Override PartName=\"/word/fontTable.xml\" ContentType=\"$wml.fontTable+xml\"/>")
        if (hasHeader) sb.append("<Override PartName=\"/word/header1.xml\" ContentType=\"$wml.header+xml\"/>")
        if (hasFooter) sb.append("<Override PartName=\"/word/footer1.xml\" ContentType=\"$wml.footer+xml\"/>")
        sb.append("<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>")
        sb.append("<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>")
        sb.append("</Types>")
        return sb.toString()
    }

    private fun coreXml(): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val now = fmt.format(Date())
        return XML_DECL + "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" " +
            "xmlns:dcmitype=\"http://purl.org/dc/dcmitype/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
            "<dc:title>${esc(model.title)}</dc:title><dc:creator>Smart PDF to Word</dc:creator>" +
            "<dcterms:created xsi:type=\"dcterms:W3CDTF\">$now</dcterms:created><dcterms:modified xsi:type=\"dcterms:W3CDTF\">$now</dcterms:modified>" +
            "</cp:coreProperties>"
    }

    companion object {
        const val XML_DECL = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
        const val NS = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
            "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
            "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\""
        const val ROOT_RELS = XML_DECL + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
            "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>" +
            "</Relationships>"
        const val APP_XML = XML_DECL + "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\" " +
            "xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\"><Application>Smart PDF to Word</Application></Properties>"

        fun tw(pt: Float): Int = (pt * 20f).roundToInt()
        fun emu(pt: Float): Long = (pt * 12700.0).roundToLong()
        fun hex(c: Int) = String.format("%06X", c and 0xFFFFFF)

        /** Escape for element text; drops characters that are illegal in XML 1.0. */
        fun esc(s: String): String {
            val sb = StringBuilder(s.length + 16)
            var i = 0
            while (i < s.length) {
                val c = s[i]
                when {
                    c == '&' -> sb.append("&amp;")
                    c == '<' -> sb.append("&lt;")
                    c == '>' -> sb.append("&gt;")
                    c == '"' -> sb.append("&quot;")
                    Character.isHighSurrogate(c) && i + 1 < s.length && Character.isLowSurrogate(s[i + 1]) -> { sb.append(c).append(s[i + 1]); i++ }
                    Character.isSurrogate(c) -> {}
                    c == '\t' || c == '\n' || c == '\r' -> sb.append(c)
                    c < ' ' || c == '￾' || c == '￿' -> {}
                    else -> sb.append(c)
                }
                i++
            }
            return sb.toString()
        }

        fun attr(s: String) = esc(s)

        @Suppress("unused")
        private fun clamp(v: Float, a: Float, b: Float) = min(max(v, a), b)
    }
}
