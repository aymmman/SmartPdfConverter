package com.ayman.pdfword.core.text

/**
 * Recovers the logical (reading/storage) order of a line of text whose units are
 * given in *visual* left-to-right order – which is how glyph positions appear in
 * every PDF regardless of how the producer stored the text.
 *
 * Approach: resolve an embedding level for every unit with a simplified version
 * of the Unicode Bidirectional Algorithm (strong types, number handling, neutral
 * resolution), then apply rule L2 (reverse runs from the highest level down to
 * the lowest odd level). For properly nested levels L2 is an involution, so
 * applying it to the visual sequence yields the logical sequence.
 *
 * This is *not* "manually reversing Arabic strings for display": the output is
 * standard logical-order Unicode; Word performs its own bidi rendering.
 */
object VisualToLogical {

    data class Placed<T>(val item: T, val level: Int, val mirrored: Boolean)

    fun <T> reorder(
        units: List<T>,
        classOf: (T) -> BidiClass,
        textOf: (T) -> String,
        baseRtl: Boolean,
    ): List<Placed<T>> {
        val n = units.size
        if (n == 0) return emptyList()
        val cls = Array(n) { classOf(units[it]) }
        for (i in 0 until n) if (cls[i] == BidiClass.NSM) cls[i] = BidiClass.ON
        val levels = IntArray(n)
        // Direction a number behaves as when resolving neutrals (true = R).
        val numActsR = BooleanArray(n)

        fun nearestStrong(from: Int, step: Int): BidiClass? {
            var j = from + step
            while (j in 0 until n) {
                val c = cls[j]
                if (c == BidiClass.L || c == BidiClass.R) return c
                j += step
            }
            return null
        }

        for (i in 0 until n) {
            when (cls[i]) {
                BidiClass.L -> levels[i] = if (baseRtl) 2 else 0
                BidiClass.R -> levels[i] = 1
                BidiClass.EN, BidiClass.AN -> {
                    if (baseRtl) {
                        // In an RTL line a number joins a Latin run when the nearest
                        // strong character on its left (its logical predecessor
                        // inside an LTR run) is Latin.
                        val left = nearestStrong(i, -1)
                        numActsR[i] = left != BidiClass.L
                        levels[i] = 2
                    } else {
                        val right = nearestStrong(i, +1)
                        val left = nearestStrong(i, -1)
                        val inR = right == BidiClass.R || (right == null && left == BidiClass.R)
                        numActsR[i] = inR
                        levels[i] = if (inR) 2 else 0
                    }
                }
                else -> levels[i] = -1 // resolve below
            }
        }

        fun neutralDirAt(j: Int): Boolean? = when (cls[j]) { // true = R
            BidiClass.L -> false
            BidiClass.R -> true
            BidiClass.EN, BidiClass.AN -> numActsR[j]
            else -> null
        }

        for (i in 0 until n) {
            if (levels[i] != -1) continue
            // Separators between two numbers take the numbers' level ("10.5", "1,000", "2024/10").
            if ((cls[i] == BidiClass.CS || cls[i] == BidiClass.ES) && i > 0 && i < n - 1) {
                val a = cls[i - 1]; val b = cls[i + 1]
                if ((a == BidiClass.EN || a == BidiClass.AN) && (b == BidiClass.EN || b == BidiClass.AN) && textOf(units[i]).length == 1) {
                    levels[i] = levels[i - 1]
                    continue
                }
            }
            var l = i - 1
            var leftDir: Boolean? = null
            while (l >= 0) { leftDir = neutralDirAt(l); if (leftDir != null) break; l-- }
            var r = i + 1
            var rightDir: Boolean? = null
            while (r < n) { rightDir = neutralDirAt(r); if (rightDir != null) break; r++ }
            val ld = leftDir ?: baseRtl
            val rd = rightDir ?: baseRtl
            val dirR = if (ld == rd) ld else baseRtl
            levels[i] = when {
                dirR -> 1
                baseRtl -> 2
                else -> 0
            }
        }

        // Rule L2 reversal (involution for these nested levels).
        val order = IntArray(n) { it }
        val maxLevel = levels.maxOrNull() ?: 0
        val minOdd = levels.filter { it % 2 == 1 }.minOrNull() ?: (maxLevel + 1)
        var lvl = maxLevel
        while (lvl >= minOdd && lvl >= 1) {
            var i = 0
            while (i < n) {
                if (levels[order[i]] >= lvl) {
                    var j = i
                    while (j + 1 < n && levels[order[j + 1]] >= lvl) j++
                    var a = i; var b = j
                    while (a < b) { val t = order[a]; order[a] = order[b]; order[b] = t; a++; b-- }
                    i = j + 1
                } else i++
            }
            lvl--
        }

        // Bracket mirroring: glyph-based extraction yields visual bracket shapes.
        val oddBrackets = (0 until n).filter { levels[it] % 2 == 1 && UnicodeText.isMirrorable(textOf(units[it])) }.toSet()
        var mirror = false
        if (oddBrackets.isNotEmpty()) {
            val plain = order.map { textOf(units[it]) }
            val mirroredSeq = order.map { if (it in oddBrackets) UnicodeText.mirror(textOf(units[it])) else textOf(units[it]) }
            mirror = bracketErrors(mirroredSeq) <= bracketErrors(plain)
        }
        return order.map { idx -> Placed(units[idx], levels[idx], mirror && idx in oddBrackets) }
    }

    private fun bracketErrors(seq: List<String>): Int {
        val stack = ArrayDeque<Char>()
        var errors = 0
        val open = "([{«‹"
        val close = ")]}»›"
        for (s in seq) {
            if (s.length != 1) continue
            val c = s[0]
            val oi = open.indexOf(c)
            val ci = close.indexOf(c)
            if (oi >= 0) stack.addLast(c)
            else if (ci >= 0) {
                if (stack.isNotEmpty() && open.indexOf(stack.last()) == ci) stack.removeLast() else errors++
            }
        }
        return errors + stack.size
    }
}
