package com.ayman.pdfword.core

import com.ayman.pdfword.core.doc.ParagraphBlock
import com.ayman.pdfword.core.doc.TableBlock
import com.ayman.pdfword.core.docx.DocxWriter
import com.ayman.pdfword.core.font.FontMapper
import com.ayman.pdfword.core.layout.LineGrouper
import com.ayman.pdfword.core.layout.TextLine
import com.ayman.pdfword.core.model.Box
import com.ayman.pdfword.core.model.Glyph
import com.ayman.pdfword.core.model.PageInput
import com.ayman.pdfword.core.model.Segment
import com.ayman.pdfword.core.model.TextStyle
import com.ayman.pdfword.core.ocr.OcrNormalizer
import com.ayman.pdfword.core.ocr.OcrWord
import com.ayman.pdfword.core.raster.RasterAnalysis
import com.ayman.pdfword.core.table.RulingTableDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Engine tests on synthetic pages. Glyphs are placed the way any PDF positions them:
 * visually, left to right — Arabic text therefore appears "reversed" in x order and
 * must be recovered in logical order without manual string reversal.
 */
class EngineTest {

    private val style = TextStyle("ABCDEF+ArialMT", 11f, false, false, 0, true)
    private val bold = style.copy(fontName = "ABCDEF+Arial-BoldMT", bold = true, size = 16f)

    /** Lays out [text] as glyphs at visual x positions (one glyph per char, width 6pt). */
    private fun visualLine(visual: String, x: Float, baseline: Float, st: TextStyle = style, spaceWidth: Float = 3f): List<Glyph> {
        val out = ArrayList<Glyph>()
        var cx = x
        for (ch in visual) {
            if (ch == ' ') { cx += spaceWidth; continue }
            out += Glyph(ch.toString(), Box(cx, baseline - 8f, cx + 6f, baseline + 2f), baseline, st)
            cx += 6f
        }
        return out
    }

    /** Visual order of a logical string for a simple RTL line (test helper only). */
    private fun rtlVisual(words: List<String>): String = words.reversed().joinToString(" ") { w ->
        if (w.any { Character.UnicodeScript.of(it.code) == Character.UnicodeScript.ARABIC }) w.reversed() else w
    }

    @Test
    fun arabicLineIsRecoveredInLogicalOrder() {
        val logical = listOf("مرحبا", "بكم", "في", "التقرير")
        val glyphs = visualLine(rtlVisual(logical), 100f, 100f)
        val line = TextLine(LineGrouper.groupLines(LineGrouper.prepare(glyphs)).single())
        val l = LineGrouper.toLogical(line, contextRtl = false)
        assertTrue(l.rtl)
        assertEquals("مرحبا بكم في التقرير", l.text)
    }

    @Test
    fun mixedArabicLatinAndNumbers() {
        // Logical: "تم إطلاق Windows 11 عام 2021"
        val logical = listOf("تم", "إطلاق", "Windows 11", "عام", "2021")
        val visual = rtlVisual(logical)
        val glyphs = visualLine(visual, 50f, 200f)
        val line = TextLine(LineGrouper.groupLines(LineGrouper.prepare(glyphs)).single())
        val l = LineGrouper.toLogical(line, contextRtl = false)
        assertEquals("تم إطلاق Windows 11 عام 2021", l.text)
    }

    @Test
    fun bracketsInArabicAreMirroredBack() {
        // Visual glyphs as a PDF shows them: "(FGD)" keeps its shape, Arabic around it.
        val visual = rtlVisual(listOf("النقاش", "(FGD)", "المركزة"))
        val glyphs = visualLine(visual, 50f, 200f)
        val line = TextLine(LineGrouper.groupLines(LineGrouper.prepare(glyphs)).single())
        assertEquals("النقاش (FGD) المركزة", LineGrouper.toLogical(line, false).text)
    }

    @Test
    fun presentationFormsAreNormalised() {
        // U+FEFB (lam-alef ligature) must become two letters in logical order.
        val g = Glyph("ﻻ", Box(0f, 0f, 6f, 10f), 8f, style)
        assertEquals("لا", LineGrouper.prepare(listOf(g)).single().text)
    }

    @Test
    fun fontMapperHandlesSubsetAndStyleSuffixes() {
        val m = FontMapper()
        val r = m.resolve("ABCDEF+TimesNewRomanPS-BoldMT")
        assertEquals("Times New Roman", r.family)
        assertTrue(r.boldHint)
        assertEquals(FontMapper.Status.PRESERVED, r.status)
        assertEquals(FontMapper.Status.SUBSTITUTED, m.resolve("F1").status)
        assertTrue(m.resolve("TraditionalArabic").arabicCapable)
    }

    private fun grid(x0: Float, y0: Float, colW: Float, rowH: Float, cols: Int, rows: Int, skipVertical: Pair<Int, Int>? = null): List<Segment> {
        val segs = ArrayList<Segment>()
        for (r in 0..rows) segs += Segment(x0, y0 + r * rowH, x0 + cols * colW, y0 + r * rowH)
        for (c in 0..cols) for (r in 0 until rows) {
            if (skipVertical != null && skipVertical.first == r && skipVertical.second == c) continue
            segs += Segment(x0 + c * colW, y0 + r * rowH, x0 + c * colW, y0 + (r + 1) * rowH)
        }
        return segs
    }

    @Test
    fun rulingTableWithMergedCell() {
        // 3x3 grid; the vertical line between columns 0 and 1 of row 2 is missing → merged cell.
        val segs = grid(50f, 100f, 100f, 20f, 3, 3, skipVertical = 2 to 1)
        val res = RulingTableDetector.detect(segs, emptyList(), 595f, 842f)
        val t = res.tables.single()
        assertEquals(3, t.rows)
        assertEquals(3, t.cols)
        val merged = t.cells.first { it.r == 2 && it.c == 0 }
        assertEquals(2, merged.cs)
    }

    @Test
    fun fullPipelineWritesValidDocxWithRtlTableAndHeading() {
        val glyphs = ArrayList<Glyph>()
        glyphs += visualLine(rtlVisual(listOf("تقرير", "المتابعة")), 380f, 80f, bold)
        glyphs += visualLine(rtlVisual(listOf("يوضح", "الجدول", "التالي", "النتائج", "حسب", "الموقع")), 280f, 120f)
        // 2x2 RTL table with Arabic headers and numbers.
        val segs = grid(300f, 140f, 100f, 20f, 2, 2)
        glyphs += visualLine("رشؤملا", 420f, 154f) // "المؤشر" (visual)
        glyphs += visualLine("فدهلا", 320f, 154f)  // "الهدف"
        glyphs += visualLine("ةيامحلا", 410f, 174f)
        glyphs += visualLine("3,000", 320f, 174f)
        glyphs += visualLine(rtlVisual(listOf("ملاحظة:", "الأرقام", "أولية")), 330f, 220f)
        val page = PageInput(0, 595f, 842f, glyphs, segs)
        val asm = DocumentAssembler(ConversionOptions(), "test.pdf", 1)
        asm.addPage(page)
        val (model, report) = asm.finish()

        val blocks = model.pages.single().parts.flatMap { it.blocks }
        val heading = blocks.filterIsInstance<ParagraphBlock>().first()
        assertEquals("تقرير المتابعة", heading.text)
        assertTrue(heading.props.rtl)
        assertEquals(1, heading.props.headingLevel)
        val table = blocks.filterIsInstance<TableBlock>().single()
        assertTrue(table.rtl)
        val texts = table.cells.map { c -> c.paragraphs.joinToString { it.text } }
        assertTrue(texts.contains("المؤشر"))
        assertTrue(texts.contains("3,000"))
        assertEquals(1, report.tablesDetected)

        val bytes = ByteArrayOutputStream().also { DocxWriter(model).write(it) }.toByteArray()
        val entries = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            while (true) { val e = z.nextEntry ?: break; entries[e.name] = z.readBytes() }
        }
        for (name in listOf("[Content_Types].xml", "_rels/.rels", "word/document.xml", "word/styles.xml", "word/numbering.xml", "word/_rels/document.xml.rels")) {
            assertNotNull("missing $name", entries[name])
            // Every part must be well-formed XML.
            DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }.newDocumentBuilder().parse(ByteArrayInputStream(entries[name]))
        }
        val xml = String(entries["word/document.xml"]!!, Charsets.UTF_8)
        assertTrue(xml.contains("<w:bidi/>"))
        assertTrue(xml.contains("<w:bidiVisual/>"))
        assertTrue(xml.contains("تقرير المتابعة"))
        assertFalse("Arabic must never be stored reversed", xml.contains("ةعباتملا"))
    }

    @Test
    fun ocrWordsGetConsistentBaselines() {
        val words = listOf(
            OcrWord("Hello", Box(10f, 100f, 40f, 109f), 95f, 1),
            OcrWord("typing", Box(45f, 100f, 80f, 112f), 90f, 1), // descender makes the box taller
            OcrWord("e", Box(0f, 103f, 4f, 107f), 60f, 2),
            OcrWord("Item", Box(14f, 100f, 40f, 109f), 95f, 2),
        )
        val glyphs = OcrNormalizer.toGlyphs(words)
        val line1 = glyphs.filter { it.text == "Hello" || it.text == "typing" }
        assertEquals(line1[0].baseline, line1[1].baseline, 0.01f)
        assertEquals("•", glyphs.first { it.box.x0 == 0f }.text)
    }

    @Test
    fun rasterRulingsAreDetected() {
        val w = 400; val h = 300
        val gray = ByteArray(w * h) { 0xFF.toByte() }
        for (x in 20 until 380) { gray[50 * w + x] = 0; gray[51 * w + x] = 0 }
        for (y in 40 until 260) { gray[y * w + 100] = 0 }
        val segs = RasterAnalysis.detectRulings(gray, w, h, 0.5f)
        assertTrue(segs.any { it.isHorizontal && it.length > 150f })
        assertTrue(segs.any { it.isVertical && it.length > 90f })
    }
}
