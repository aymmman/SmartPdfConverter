// Top-level build file. AGP 9 compiles Android Kotlin code with its built-in Kotlin
// support (the kotlin-android plugin must not be applied). The Kotlin JVM and Compose
// plugins declared here put the chosen Kotlin Gradle Plugin version on the classpath.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.jvm) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false
}
